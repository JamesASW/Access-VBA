USE [IFSLA_Gateway]
GO
-- Add
--CREATE ROLE tbl_temp
--CREATE ROLE vw_Select
--CREATE ROLE SP_EXEC
--EXEC sp_addrolemember 'tbl_Temp', 'OAAD\WG-IFSLocalApps (C)'
--EXEC sp_addrolemember 'vw_Select', 'OAAD\WG-IFSLocalApps (C)'
--EXEC sp_addrolemember 'SP_EXEC', 'OAAD\WG-IFSLocalApps (C)'
--EXEC sp_addrolemember 'tbl_Temp', 'OAAD\WG-IFS_LA_TEST (C)'
--EXEC sp_addrolemember 'vw_Select', 'OAAD\WG-IFS_LA_TEST (C)'
--EXEC sp_addrolemember 'SP_EXEC', 'OAAD\WG-IFS_LA_TEST (C)'
EXEC sp_addrolemember 'tbl_Temp', 'OAAD\WG-IFS_LA_PROD (C)'
EXEC sp_addrolemember 'vw_Select', 'OAAD\WG-IFS_LA_PROD (C)'
EXEC sp_addrolemember 'SP_EXEC', 'OAAD\WG-IFS_LA_PROD (C)'
GO

-- Views
--SELECT 'GRANT SELECT ON ' +  SCHEMA_NAME(SCHEMA_ID) + '.' + NAME + ' TO vw_Select' FROM SYS.OBJECTS WHERE TYPE = 'V'
GRANT SELECT ON dbo.vwAppCategory TO vw_Select
GRANT SELECT ON dbo.vwEnvironments TO vw_Select
GRANT SELECT ON dbo.vwBusinessUnit TO vw_Select
GRANT SELECT ON dbo.vwFileGroups TO vw_Select
GRANT SELECT ON dbo.vwUsers TO vw_Select
GRANT SELECT ON dbo.vwSYSKeys TO vw_Select
GRANT SELECT ON dbo.vwPrograms TO vw_Select
GRANT SELECT ON dbo.vwAppUsrRelationship TO vw_Select
GRANT SELECT ON dbo.vwApplications TO vw_Select
GRANT SELECT ON dbo.vwAppBsuRelationship TO vw_Select
GRANT SELECT ON dbo.vwAppEnvironments TO vw_Select
GRANT SELECT ON dbo.vwGateway TO vw_Select
GRANT SELECT ON dbo.vwAppPermissions TO vw_Select
GRANT SELECT ON dbo.vwAppIteration TO vw_Select
GRANT SELECT ON dbo.vwAppFileList TO vw_Select
GRANT SELECT ON dbo.vwAppExecutables TO vw_Select
GRANT SELECT ON dbo.vwAppDevCopy TO vw_Select
GRANT SELECT ON dbo.vwADGroups TO vw_Select
GRANT SELECT ON dbo.vwAALog TO vw_Select
GRANT SELECT ON dbo.vwERLog TO vw_Select
GRANT SELECT ON dbo.vwAULog TO vw_Select
GRANT SELECT ON dbo.vwSUPErrorLog TO vw_Select
GRANT SELECT ON dbo.vwSUPActivityLog TO vw_Select
GRANT SELECT ON dbo.vwLOGActiveUsersNowPerApp TO vw_Select
GRANT SELECT ON dbo.vwGatewayFileList TO vw_Select
GRANT SELECT ON dbo.vwAppFileDownloadList TO vw_Select


-- USPs 
-- SELECT 'GRANT EXECUTE ON ' +  SCHEMA_NAME(SCHEMA_ID) + '.' + NAME + ' TO SP_EXEC' FROM SYS.OBJECTS WHERE TYPE = 'P'
GRANT EXECUTE ON dbo.uspTMPDocumentTableStructure TO SP_EXEC
GRANT EXECUTE ON dbo.uspSYSKeySequence TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditEnvironment TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditProgramInfo TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditCategory TO SP_EXEC
GRANT EXECUTE ON dbo.uspADUpdateUsers TO SP_EXEC
GRANT EXECUTE ON dbo.uspImportActiveDirectoryUsers TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddProgramInfo TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddEnvironment TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddCategory TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddBusinessUnit TO SP_EXEC
GRANT EXECUTE ON dbo.uspDecomApplication TO SP_EXEC
GRANT EXECUTE ON dbo.uspMIActiveApplicationUsers TO SP_EXEC
GRANT EXECUTE ON dbo.uspManageUsrBsuRelationship TO SP_EXEC
GRANT EXECUTE ON dbo.uspManageAppBsuRelationship TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditApplication TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddAppEnvironment TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddApplication TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddAppPermissions TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddAppIteration TO SP_EXEC
GRANT EXECUTE ON dbo.uspAddAppEnvFile TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditPID TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAdminAppSetup TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditIteration TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAdminAppIterations TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditFileList TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAdminAppIterationPRODandTEST TO SP_EXEC
GRANT EXECUTE ON dbo.uspDelAppFiles TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAdminSelectIteration TO SP_EXEC
GRANT EXECUTE ON dbo.uspChangeFavourites TO SP_EXEC
GRANT EXECUTE ON dbo.uspCleanUpFiles TO SP_EXEC
GRANT EXECUTE ON dbo.uspLogCopyDateTime TO SP_EXEC
GRANT EXECUTE ON dbo.uspChangeAppGWIcon TO SP_EXEC
GRANT EXECUTE ON dbo.uspEditCurrentAction TO SP_EXEC
GRANT EXECUTE ON dbo.uspGatewayExecuteAppCheck TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAdminAppSelectedFile TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnUserSpecificAppList TO SP_EXEC
GRANT EXECUTE ON dbo.uspRemAppPermissions TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnCanUserOpenApp TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAppPromotionDetails TO SP_EXEC
GRANT EXECUTE ON dbo.uspSetUserDefaultApps TO SP_EXEC
GRANT EXECUTE ON dbo.uspGTYSendEmail TO SP_EXEC
GRANT EXECUTE ON dbo.uspGatewayErrorLog TO SP_EXEC
GRANT EXECUTE ON dbo.uspPromoteApplicationAPISetup TO SP_EXEC
GRANT EXECUTE ON dbo.uspGatewayActiveDeactiveUsers TO SP_EXEC
GRANT EXECUTE ON dbo.uspPromoteApplicationFileSetup TO SP_EXEC
GRANT EXECUTE ON dbo.uspReturnAdminAppFilesTreeview TO SP_EXEC
GRANT EXECUTE ON dbo.uspGatewayUserLog TO SP_EXEC
GRANT EXECUTE ON dbo.uspGatewayLogInOut TO SP_EXEC
GRANT EXECUTE ON dbo.uspGetUserPermissionsFromAD TO SP_EXEC


-- Tables
GRANT SELECT ON dbo.tblSYSVarGlobal TO tbl_Temp
GRANT SELECT ON dbo.tblSYSKey TO tbl_Temp
GRANT SELECT ON dbo.tblGTY140 TO tbl_Temp
GRANT INSERT ON dbo.tblGTY140 TO tbl_Temp