USE [IFSLA_Gateway]
GO
/****** Object:  ForeignKey [FK_GTY020To060_1]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_1]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] DROP CONSTRAINT [FK_GTY020To060_1]
GO
/****** Object:  ForeignKey [FK_GTY020To060_2]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_2]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] DROP CONSTRAINT [FK_GTY020To060_2]
GO
/****** Object:  ForeignKey [FK_GTY020To110]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To110]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] DROP CONSTRAINT [FK_GTY020To110]
GO
/****** Object:  ForeignKey [FK_GTY120To060]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120] DROP CONSTRAINT [FK_GTY120To060]
GO
/****** Object:  ForeignKey [FK_GTY120To080]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120] DROP CONSTRAINT [FK_GTY120To080]
GO
/****** Object:  ForeignKey [FK_GTY030To020]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030] DROP CONSTRAINT [FK_GTY030To020]
GO
/****** Object:  ForeignKey [FK_GTY030To040]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To040]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030] DROP CONSTRAINT [FK_GTY030To040]
GO
/****** Object:  ForeignKey [FK_GTY010To020]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010] DROP CONSTRAINT [FK_GTY010To020]
GO
/****** Object:  ForeignKey [FK_GTY010To080]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010] DROP CONSTRAINT [FK_GTY010To080]
GO
/****** Object:  ForeignKey [FK_GTY090To030]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] DROP CONSTRAINT [FK_GTY090To030]
GO
/****** Object:  ForeignKey [FK_GTY090To100]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To100]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] DROP CONSTRAINT [FK_GTY090To100]
GO
/****** Object:  ForeignKey [FK_GTY090To130]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To130]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] DROP CONSTRAINT [FK_GTY090To130]
GO
/****** Object:  ForeignKey [FK_GTY050To030]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050] DROP CONSTRAINT [FK_GTY050To030]
GO
/****** Object:  ForeignKey [FK_GTY050To060]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050] DROP CONSTRAINT [FK_GTY050To060]
GO
/****** Object:  ForeignKey [FK_GTY070To030]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY070To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY070]'))
ALTER TABLE [dbo].[tblGTY070] DROP CONSTRAINT [FK_GTY070To030]
GO
/****** Object:  ForeignKey [FK_GTY920To060]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920] DROP CONSTRAINT [FK_GTY920To060]
GO
/****** Object:  ForeignKey [FK_GTY920To070]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920] DROP CONSTRAINT [FK_GTY920To070]
GO
/****** Object:  ForeignKey [FK_GTY910To060]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910] DROP CONSTRAINT [FK_GTY910To060]
GO
/****** Object:  ForeignKey [FK_GTY910To070]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910] DROP CONSTRAINT [FK_GTY910To070]
GO
/****** Object:  ForeignKey [FK_GTY900To060]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900] DROP CONSTRAINT [FK_GTY900To060]
GO
/****** Object:  ForeignKey [FK_GTY900To070]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900] DROP CONSTRAINT [FK_GTY900To070]
GO
/****** Object:  View [dbo].[vwSUPActivityLog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwSUPActivityLog]'))
DROP VIEW [dbo].[vwSUPActivityLog]
GO
/****** Object:  View [dbo].[vwSUPErrorLog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwSUPErrorLog]'))
DROP VIEW [dbo].[vwSUPErrorLog]
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayLogInOut]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayLogInOut]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspGatewayLogInOut]
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayUserLog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayUserLog]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspGatewayUserLog]
GO
/****** Object:  View [dbo].[vwAULog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAULog]'))
DROP VIEW [dbo].[vwAULog]
GO
/****** Object:  View [dbo].[vwERLog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwERLog]'))
DROP VIEW [dbo].[vwERLog]
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayActiveDeactiveUsers]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayActiveDeactiveUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspGatewayActiveDeactiveUsers]
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayErrorLog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayErrorLog]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspGatewayErrorLog]
GO
/****** Object:  StoredProcedure [dbo].[uspSetUserDefaultApps]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspSetUserDefaultApps]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspSetUserDefaultApps]
GO
/****** Object:  View [dbo].[vwAALog]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAALog]'))
DROP VIEW [dbo].[vwAALog]
GO
/****** Object:  StoredProcedure [dbo].[uspRemAppPermissions]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspRemAppPermissions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspRemAppPermissions]
GO
/****** Object:  StoredProcedure [dbo].[uspReturnUserSpecificAppList]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnUserSpecificAppList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspReturnUserSpecificAppList]
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayExecuteAppCheck]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayExecuteAppCheck]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspGatewayExecuteAppCheck]
GO
/****** Object:  StoredProcedure [dbo].[uspEditCurrentAction]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditCurrentAction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditCurrentAction]
GO
/****** Object:  StoredProcedure [dbo].[uspLogCopyDateTime]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspLogCopyDateTime]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspLogCopyDateTime]
GO
/****** Object:  StoredProcedure [dbo].[uspChangeFavourites]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspChangeFavourites]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspChangeFavourites]
GO
/****** Object:  StoredProcedure [dbo].[uspDelAppFiles]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspDelAppFiles]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspDelAppFiles]
GO
/****** Object:  StoredProcedure [dbo].[uspEditFileList]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditFileList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditFileList]
GO
/****** Object:  StoredProcedure [dbo].[uspEditIteration]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditIteration]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditIteration]
GO
/****** Object:  StoredProcedure [dbo].[uspEditPID]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditPID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditPID]
GO
/****** Object:  Table [dbo].[tblGTY900]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900] DROP CONSTRAINT [FK_GTY900To060]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900] DROP CONSTRAINT [FK_GTY900To070]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY900]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY900]
GO
/****** Object:  Table [dbo].[tblGTY910]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910] DROP CONSTRAINT [FK_GTY910To060]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910] DROP CONSTRAINT [FK_GTY910To070]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY910]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY910]
GO
/****** Object:  Table [dbo].[tblGTY920]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920] DROP CONSTRAINT [FK_GTY920To060]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920] DROP CONSTRAINT [FK_GTY920To070]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY920]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY920]
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppEnvFile]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppEnvFile]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddAppEnvFile]
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppIteration]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppIteration]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddAppIteration]
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppPermissions]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppPermissions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddAppPermissions]
GO
/****** Object:  View [dbo].[vwAppFileList]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppFileList]'))
DROP VIEW [dbo].[vwAppFileList]
GO
/****** Object:  View [dbo].[vwAppIteration]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppIteration]'))
DROP VIEW [dbo].[vwAppIteration]
GO
/****** Object:  View [dbo].[vwAppPermissions]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppPermissions]'))
DROP VIEW [dbo].[vwAppPermissions]
GO
/****** Object:  View [dbo].[vwGateway]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwGateway]'))
DROP VIEW [dbo].[vwGateway]
GO
/****** Object:  View [dbo].[vwAppEnvironments]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppEnvironments]'))
DROP VIEW [dbo].[vwAppEnvironments]
GO
/****** Object:  StoredProcedure [dbo].[uspAddApplication]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddApplication]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddApplication]
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppEnvironment]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppEnvironment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddAppEnvironment]
GO
/****** Object:  Table [dbo].[tblGTY070]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY070To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY070]'))
ALTER TABLE [dbo].[tblGTY070] DROP CONSTRAINT [FK_GTY070To030]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY070]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY070]
GO
/****** Object:  StoredProcedure [dbo].[uspEditApplication]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditApplication]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditApplication]
GO
/****** Object:  StoredProcedure [dbo].[uspManageAppBsuRelationship]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspManageAppBsuRelationship]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspManageAppBsuRelationship]
GO
/****** Object:  View [dbo].[vwAppBsuRelationship]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppBsuRelationship]'))
DROP VIEW [dbo].[vwAppBsuRelationship]
GO
/****** Object:  Table [dbo].[tblGTY050]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050] DROP CONSTRAINT [FK_GTY050To030]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050] DROP CONSTRAINT [FK_GTY050To060]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY050]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY050]
GO
/****** Object:  Table [dbo].[tblGTY090]    Script Date: 07/19/2016 14:43:42 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] DROP CONSTRAINT [FK_GTY090To030]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To100]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] DROP CONSTRAINT [FK_GTY090To100]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To130]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] DROP CONSTRAINT [FK_GTY090To130]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY090]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY090]
GO
/****** Object:  Table [dbo].[tblGTY010]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010] DROP CONSTRAINT [FK_GTY010To020]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010] DROP CONSTRAINT [FK_GTY010To080]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY010]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY010]
GO
/****** Object:  Table [dbo].[tblGTY030]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030] DROP CONSTRAINT [FK_GTY030To020]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To040]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030] DROP CONSTRAINT [FK_GTY030To040]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY030]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY030]
GO
/****** Object:  StoredProcedure [dbo].[uspManageUsrBsuRelationship]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspManageUsrBsuRelationship]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspManageUsrBsuRelationship]
GO
/****** Object:  StoredProcedure [dbo].[uspMIActiveApplicationUsers]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspMIActiveApplicationUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspMIActiveApplicationUsers]
GO
/****** Object:  StoredProcedure [dbo].[uspDecomApplication]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspDecomApplication]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspDecomApplication]
GO
/****** Object:  StoredProcedure [dbo].[uspAddBusinessUnit]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddBusinessUnit]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddBusinessUnit]
GO
/****** Object:  StoredProcedure [dbo].[uspAddCategory]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddCategory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddCategory]
GO
/****** Object:  StoredProcedure [dbo].[uspAddEnvironment]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddEnvironment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddEnvironment]
GO
/****** Object:  StoredProcedure [dbo].[uspAddProgramInfo]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddProgramInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspAddProgramInfo]
GO
/****** Object:  View [dbo].[vwApplications]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwApplications]'))
DROP VIEW [dbo].[vwApplications]
GO
/****** Object:  View [dbo].[vwAppUsrRelationship]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppUsrRelationship]'))
DROP VIEW [dbo].[vwAppUsrRelationship]
GO
/****** Object:  View [dbo].[vwPrograms]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwPrograms]'))
DROP VIEW [dbo].[vwPrograms]
GO
/****** Object:  View [dbo].[vwSYSKeys]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwSYSKeys]'))
DROP VIEW [dbo].[vwSYSKeys]
GO
/****** Object:  View [dbo].[vwUsers]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwUsers]'))
DROP VIEW [dbo].[vwUsers]
GO
/****** Object:  StoredProcedure [dbo].[uspImportActiveDirectoryUsers]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspImportActiveDirectoryUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspImportActiveDirectoryUsers]
GO
/****** Object:  View [dbo].[vwFileGroups]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFileGroups]'))
DROP VIEW [dbo].[vwFileGroups]
GO
/****** Object:  View [dbo].[vwFood]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFood]'))
DROP VIEW [dbo].[vwFood]
GO
/****** Object:  View [dbo].[vwFoodOrders]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFoodOrders]'))
DROP VIEW [dbo].[vwFoodOrders]
GO
/****** Object:  View [dbo].[vwBusinessUnit]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwBusinessUnit]'))
DROP VIEW [dbo].[vwBusinessUnit]
GO
/****** Object:  View [dbo].[vwEnvironments]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwEnvironments]'))
DROP VIEW [dbo].[vwEnvironments]
GO
/****** Object:  StoredProcedure [dbo].[uspADUpdateUsers]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspADUpdateUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspADUpdateUsers]
GO
/****** Object:  Table [dbo].[tblGTY120]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120] DROP CONSTRAINT [FK_GTY120To060]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120] DROP CONSTRAINT [FK_GTY120To080]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY120]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY120]
GO
/****** Object:  StoredProcedure [dbo].[uspEditCategory]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditCategory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditCategory]
GO
/****** Object:  StoredProcedure [dbo].[uspEditProgramInfo]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditProgramInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditProgramInfo]
GO
/****** Object:  StoredProcedure [dbo].[uspEditEnvironment]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditEnvironment]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspEditEnvironment]
GO
/****** Object:  View [dbo].[vwAppCategory]    Script Date: 07/19/2016 14:43:41 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppCategory]'))
DROP VIEW [dbo].[vwAppCategory]
GO
/****** Object:  StoredProcedure [dbo].[uspSYSKeySequence]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspSYSKeySequence]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspSYSKeySequence]
GO
/****** Object:  Table [dbo].[tblGTY020]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_1]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] DROP CONSTRAINT [FK_GTY020To060_1]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_2]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] DROP CONSTRAINT [FK_GTY020To060_2]
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To110]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] DROP CONSTRAINT [FK_GTY020To110]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY020]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY020]
GO
/****** Object:  Table [dbo].[tblADImport]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblADImport]') AND type in (N'U'))
DROP TABLE [dbo].[tblADImport]
GO
/****** Object:  Table [dbo].[tblBOFood]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblBOFood]') AND type in (N'U'))
DROP TABLE [dbo].[tblBOFood]
GO
/****** Object:  Table [dbo].[tblBOOrder]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblBOOrder]') AND type in (N'U'))
DROP TABLE [dbo].[tblBOOrder]
GO
/****** Object:  Table [dbo].[tblGTY040]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY040]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY040]
GO
/****** Object:  Table [dbo].[tblGTY100]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY100]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY100]
GO
/****** Object:  Table [dbo].[tblGTY110]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY110]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY110]
GO
/****** Object:  Table [dbo].[tblGTY060]    Script Date: 07/19/2016 14:43:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY060]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY060]
GO
/****** Object:  StoredProcedure [dbo].[uspTMPDocumentTableStructure]    Script Date: 07/19/2016 14:43:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspTMPDocumentTableStructure]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspTMPDocumentTableStructure]
GO
/****** Object:  Table [dbo].[tblGTY130]    Script Date: 07/19/2016 14:43:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY130]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY130]
GO
/****** Object:  Table [dbo].[tblGTY080]    Script Date: 07/19/2016 14:43:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY080]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTY080]
GO
/****** Object:  Table [dbo].[tblGTYImages]    Script Date: 07/19/2016 14:43:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTYImages]') AND type in (N'U'))
DROP TABLE [dbo].[tblGTYImages]
GO
/****** Object:  Table [dbo].[tblSYSKey]    Script Date: 07/19/2016 14:43:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblSYSKey]') AND type in (N'U'))
DROP TABLE [dbo].[tblSYSKey]
GO
/****** Object:  Table [dbo].[tblSYSVarGlobal]    Script Date: 07/19/2016 14:43:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblSYSVarGlobal]') AND type in (N'U'))
DROP TABLE [dbo].[tblSYSVarGlobal]
GO
/****** Object:  Role [sp_Exec]    Script Date: 07/19/2016 14:43:35 ******/
DECLARE @RoleName sysname
set @RoleName = N'sp_Exec'
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = @RoleName AND type = 'R')
Begin
	DECLARE @RoleMemberName sysname
	DECLARE Member_Cursor CURSOR FOR
	select [name]
	from sys.database_principals 
	where principal_id in ( 
		select member_principal_id 
		from sys.database_role_members 
		where role_principal_id in (
			select principal_id
			FROM sys.database_principals where [name] = @RoleName  AND type = 'R' ))

	OPEN Member_Cursor;

	FETCH NEXT FROM Member_Cursor
	into @RoleMemberName

	WHILE @@FETCH_STATUS = 0
	BEGIN

		exec sp_droprolemember @rolename=@RoleName, @membername= @RoleMemberName

		FETCH NEXT FROM Member_Cursor
		into @RoleMemberName
	END;

	CLOSE Member_Cursor;
	DEALLOCATE Member_Cursor;
End
GO
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'sp_Exec' AND type = 'R')
DROP ROLE [sp_Exec]
GO
/*
/****** Object:  User [OAAD\#IFSLocalApps]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\#IFSLocalApps')
DROP USER [OAAD\#IFSLocalApps]
GO
/****** Object:  User [OAAD\JL790]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\JL790')
DROP USER [OAAD\JL790]
GO
/****** Object:  User [OAAD\MF303]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\MF303')
DROP USER [OAAD\MF303]
GO
/****** Object:  User [OAAD\OK835]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\OK835')
DROP USER [OAAD\OK835]
GO
/****** Object:  User [OAAD\OT538]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\OT538')
DROP USER [OAAD\OT538]
GO
/****** Object:  User [OAAD\PB306]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\PB306')
DROP USER [OAAD\PB306]
GO
/****** Object:  User [OAAD\WG-IFSLocalApps (C)]    Script Date: 07/19/2016 14:43:35 ******/
--IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\WG-IFSLocalApps (C)')
--DROP USER [OAAD\WG-IFSLocalApps (C)]
--GO
/****** Object:  User [OAAD\XC815]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\XC815')
DROP USER [OAAD\XC815]
GO
/****** Object:  User [usrCRTSAdmin]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'usrCRTSAdmin')
DROP USER [usrCRTSAdmin]
GO
/****** Object:  User [usrGateway]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'usrGateway')
DROP USER [usrGateway]
GO
/****** Object:  User [usrIFSLARelocation]    Script Date: 07/19/2016 14:43:35 ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'usrIFSLARelocation')
DROP USER [usrIFSLARelocation]
GO
/****** Object:  User [usrIFSLARelocation]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'usrIFSLARelocation')
CREATE USER [usrIFSLARelocation] FOR LOGIN [usrIFSLARelocation] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [usrGateway]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'usrGateway')
CREATE USER [usrGateway] FOR LOGIN [usrGateway] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [usrCRTSAdmin]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'usrCRTSAdmin')
CREATE USER [usrCRTSAdmin] FOR LOGIN [usrCRTSAdmin] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\XC815]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\XC815')
CREATE USER [OAAD\XC815] FOR LOGIN [OAAD\XC815] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\WG-IFSLocalApps (C)]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\WG-IFSLocalApps (C)')
CREATE USER [OAAD\WG-IFSLocalApps (C)] FOR LOGIN [OAAD\WG-IFSLocalApps (C)]
GO
/****** Object:  User [OAAD\PB306]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\PB306')
CREATE USER [OAAD\PB306] FOR LOGIN [OAAD\PB306] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\OT538]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\OT538')
CREATE USER [OAAD\OT538] FOR LOGIN [OAAD\OT538] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\OK835]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\OK835')
CREATE USER [OAAD\OK835] FOR LOGIN [OAAD\OK835] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\MF303]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\MF303')
CREATE USER [OAAD\MF303] FOR LOGIN [OAAD\MF303] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\JL790]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\JL790')
CREATE USER [OAAD\JL790] FOR LOGIN [OAAD\JL790] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [OAAD\#IFSLocalApps]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'OAAD\#IFSLocalApps')
CREATE USER [OAAD\#IFSLocalApps] FOR LOGIN [OAAD\#IFSLocalApps] WITH DEFAULT_SCHEMA=[dbo]
GO
*/
/****** Object:  Role [sp_Exec]    Script Date: 07/19/2016 14:43:35 ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'sp_Exec' AND type = 'R')
CREATE ROLE [sp_Exec] AUTHORIZATION [dbo]
GO
/****** Object:  Table [dbo].[tblSYSVarGlobal]    Script Date: 07/19/2016 14:43:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblSYSVarGlobal]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblSYSVarGlobal](
	[VAR_NME] [varchar](255) NOT NULL,
	[VAR_TYP] [char](3) NOT NULL,
	[VAR_TXT] [varchar](255) NULL,
	[VAR_MEM] [text] NULL,
	[VAR_DEC] [decimal](18, 10) NULL,
	[VAR_LNG] [int] NULL,
	[VAR_DTE] [datetime] NULL,
	[VAR_CUR] [money] NULL,
	[VAR_BYT] [tinyint] NULL,
 CONSTRAINT [PK_SYSVarGlobal] PRIMARY KEY CLUSTERED 
(
	[VAR_NME] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblSYSKey]    Script Date: 07/19/2016 14:43:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblSYSKey]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblSYSKey](
	[TBL_KEY_ID] [char](3) NOT NULL,
	[TBL_NME] [char](9) NOT NULL,
	[TBL_KEY_LEN] [int] NOT NULL,
	[KEY_SEQ_NBR] [int] NOT NULL,
 CONSTRAINT [PK_SYSKey] PRIMARY KEY CLUSTERED 
(
	[TBL_KEY_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTYImages]    Script Date: 07/19/2016 14:43:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTYImages]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTYImages](
	[FLE_ID] [int] IDENTITY(1,1) NOT NULL,
	[IMG_NME] [varchar](256) NOT NULL,
	[FLE_NME] [varchar](256) NOT NULL,
	[FLE_PTH] [varchar](1024) NOT NULL,
	[FLE_EXT] [varchar](10) NOT NULL,
	[FLE_DATA] [varbinary](max) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY080]    Script Date: 07/19/2016 14:43:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY080]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY080](
	[BSU_ID] [char](5) NOT NULL,
	[BSU_NME] [varchar](255) NOT NULL,
 CONSTRAINT [PK_GTY080] PRIMARY KEY CLUSTERED 
(
	[BSU_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY130]    Script Date: 07/19/2016 14:43:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY130]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY130](
	[FLE_GRP_ID] [char](5) NOT NULL,
	[FLE_GRP_NME] [varchar](25) NOT NULL,
	[CPY_ACT] [bit] NOT NULL,
 CONSTRAINT [PK_GTY130] PRIMARY KEY CLUSTERED 
(
	[FLE_GRP_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[uspTMPDocumentTableStructure]    Script Date: 07/19/2016 14:43:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspTMPDocumentTableStructure]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[uspTMPDocumentTableStructure] @strInputTableName VARCHAR(255)
                                                 ,@strOutputTableSQL VARCHAR(4000) OUTPUT
                                                 ,@strOutputConstraintSQL VARCHAR(4000) OUTPUT
                                                 ,@strOutputCheckConstraintSQL VARCHAR(4000) OUTPUT
                                                 ,@strOutputRuleConstraintSQL VARCHAR(4000) OUTPUT
                                                 ,@strOutputFKConstraintSQL VARCHAR(4000) OUTPUT
                                                 ,@strOutputTriggerSQL VARCHAR(4000) OUTPUT AS 
--/ -----------------------------------------------------------------------------------------------------
--/ TABLE DOCUMENT SCRIPLET
--/ -----------------------------------------------------------------------------------------------------
--/ Created By     : James Cronshaw 
--/ Creation Date  : 18/08/2012
--/ Acknowledgments: Heavily modified from original version by Lowell Izaquirre
--/                  copyright 2004-2009 by Lowell Izaguirre scripts*at*stormrage.com all rights reserved. 
--/                  http://www.stormrage.com/Portals/0/SSC/sp_GetDDL2005_V304.txt
--/ Further Reading: http://www.sqlservercentral.com/scripts/SQL+Server+2005/67515/
--/ -----------------------------------------------------------------------------------------------------
--/ Declarations
    --DECLARE @strInputTableName VARCHAR(255) 
    DECLARE @strTableName VARCHAR(200)
    DECLARE @strSchemaName VARCHAR(255)
    DECLARE @strCharLength INT
    DECLARE @intTableID INT
    DECLARE @strTableSQL VARCHAR(MAX)
    DECLARE @strContraintSQL VARCHAR(MAX)
    DECLARE @strCheckConstraintSQL VARCHAR(MAX)
    DECLARE @strRuleConstraintSQL VARCHAR(MAX)
    DECLARE @strFKConstraintSQL VARCHAR(MAX)
    DECLARE @strTriggerSQL VARCHAR(MAX)
    DECLARE @strExtendedProps VARCHAR(MAX) 
    DECLARE @strIndexSQL VARCHAR(MAX)
    DECLARE @vbCrLf CHAR(2) 
    DECLARE @strPrimaryKey VARCHAR(1000)
    DECLARE @strUniqueKey VARCHAR(1000)
    SET NOCOUNT ON 
--/ Set initial values
    SET @strPrimaryKey = ''''
    SET @strUniqueKey = ''''
    --SET @strInputTableName = ''tblGTY050''
--/ ***************************************************************************************************************** 
--/ INITIALISE 
--/ ***************************************************************************************************************** 
--/ Does the tablename contain a schema? 
    SET @vbCrLf = CHAR(13) + CHAR(10) 
    SELECT @strSchemaName = ISNULL(PARSENAME(@strInputTableName,2),''dbo'')
          ,@strTableName = PARSENAME(@strInputTableName,1) 
    SELECT @intTableID = [object_id] 
    FROM   sys.objects 
    WHERE  [type] = ''U'' 
    AND    [name] <> ''dtproperties'' 
    AND    [name] = @strTableName 
    AND    [schema_id] = schema_id(@strSchemaName)
--/ ***************************************************************************************************************** 
--/ Check If TableName is Valid 
--/ ***************************************************************************************************************** 
    IF ISNULL(@intTableID,0) = 0 
        BEGIN 
            SET @strTableSQL = ''Table object ['' + @strSchemaName + ''].['' + UPPER(@strTableName) + ''] does not exist in Database ['' + db_name() + '']'' 
            SELECT @strTableSQL; 
            --RETURN 0 
        END 
--/ ***************************************************************************************************************** 
--/ Valid Table, Continue Processing 
--/ ***************************************************************************************************************** 
    SET @strTableSQL = ''CREATE TABLE ['' + @strSchemaName + ''].['' + @strTableName + '']'' + @vbCrLf + ''   ('' 
    SET @intTableID = OBJECT_ID(@strTableName) 
    SELECT @strCharLength = MAX(LEN(sys.columns.[name])) + 1 
    FROM   sys.objects 
      INNER JOIN sys.columns ON sys.objects.[object_id] = sys.columns.[object_id] 
                            AND sys.objects.[object_id] = @intTableID; 
--/ ***************************************************************************************************************** 
--/ Get the columns, their definitions and defaults. 
--/ ***************************************************************************************************************** 
    SELECT @strTableSQL = @strTableSQL 
         + CASE 
               WHEN sys.columns.[is_computed] = 1 
                   THEN @vbCrLf 
                      + SPACE(3) + ''['' 
                      + sys.columns.[name]
                      + ''] '' 
                      + SPACE(@strCharLength - LEN(sys.columns.[name])) 
                      + ''AS '' + UPPER(sys.columns.[name]) 
                   ELSE @vbCrLf 
                      + SPACE(3) + '',['' 
                      + UPPER(sys.columns.[name]) 
                      + ''] '' 
                      + SPACE(@strCharLength - LEN(sys.columns.[name])) 
                      + UPPER(TYPE_NAME(sys.columns.[system_type_id])) 
         + CASE 
           --/ Numeric(precision, scale) 
               WHEN TYPE_NAME(sys.columns.[system_type_id]) IN (''decimal'',''numeric'') 
                   THEN ''('' 
                      + CONVERT(VARCHAR,sys.columns.[precision]) 
                      + '','' 
                      + CONVERT(VARCHAR,sys.columns.[scale]) 
                      + '') '' 
                      + SPACE(6 - LEN(CONVERT(VARCHAR,sys.columns.[precision]) 
                      + '','' 
                      + CONVERT(VARCHAR,sys.columns.[scale]))) 
                      + SPACE(7) 
                      + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
         + CASE 
               WHEN sys.columns.[is_nullable] = 0 
                   THEN '' NOT NULL'' 
                   ELSE '' NULL'' 
               END 
           --/ Float(53) 
               WHEN TYPE_NAME(sys.columns.[system_type_id]) IN (''float'',''real'') 
               THEN 
                --/ addition: if 53, no need to specifically say (53), otherwise display it 
                   CASE 
                       WHEN sys.columns.[precision] = 53 
                           THEN SPACE(11 - LEN(CONVERT(VARCHAR,sys.columns.[precision]))) 
                              + SPACE(7) 
                              + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                              + CASE 
                                    WHEN sys.columns.[is_nullable] = 0 
                                        THEN '' NOT NULL'' 
                                        ELSE '' NULL'' 
                                END 
                       ELSE ''('' 
                          + CONVERT(VARCHAR,sys.columns.[precision]) 
                          + '') '' 
                          + SPACE(6 - LEN(CONVERT(VARCHAR,sys.columns.[precision]))) 
                          + SPACE(7) + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                          + CASE 
                                WHEN sys.columns.[is_nullable] = 0 
                                    THEN '' NOT NULL'' 
                                    ELSE '' NULL'' 
                            END 
                  END 
        --/ Varchar
            WHEN TYPE_NAME(sys.columns.[system_type_id]) IN (''char'',''varchar'') 
                THEN CASE 
            WHEN sys.columns.[max_length] = -1 
                THEN ''(max)'' 
                   + SPACE(6 - LEN(CONVERT(VARCHAR,sys.columns.[max_length]))) 
                   + SPACE(7) + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                   + CASE WHEN sys.columns.[is_nullable] = 0 
                         THEN '' NOT NULL'' 
                         ELSE '' NULL'' 
                     END 
                     ELSE ''('' 
                       + CONVERT(VARCHAR,sys.columns.[max_length]) 
                       + '') '' 
                       + SPACE(6 - LEN(CONVERT(VARCHAR,sys.columns.[max_length]))) 
                       + SPACE(7) + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                       + CASE WHEN sys.columns.[is_nullable] = 0 
                             THEN '' NOT NULL'' 
                             ELSE '' NULL'' 
                         END 
                     END 
        --/ Nvarchar
            WHEN TYPE_NAME(sys.columns.[system_type_id]) IN (''nchar'',''nvarchar'') 
                THEN CASE WHEN sys.columns.[max_length] = -1 
                         THEN ''(max)'' 
                            + SPACE(6 - LEN(CONVERT(VARCHAR,(sys.columns.[max_length]/2)))) 
                            + SPACE(7) 
                            + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                            + CASE WHEN sys.columns.[is_nullable] = 0 
                                  THEN '' NOT NULL'' 
                                  ELSE '' NULL'' 
                              END 
                     ELSE ''('' 
                        + CONVERT(VARCHAR,(sys.columns.[max_length]/2)) 
                        + '') '' 
                        + SPACE(6 - LEN(CONVERT(VARCHAR,(sys.columns.[max_length]/2)))) 
                        + SPACE(7) 
                        + SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                        + CASE WHEN sys.columns.[is_nullable] = 0 
                              THEN '' NOT NULL'' 
                              ELSE '' NULL'' 
                          END 
                     END 
        --/ Datetime 
            WHEN TYPE_NAME(sys.columns.[system_type_id]) IN (''datetime'',''money'',''text'',''image'') 
                THEN SPACE(18 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                   + '' '' 
                   + CASE WHEN sys.columns.[is_nullable] = 0 
                         THEN '' NOT NULL'' 
                         ELSE '' NULL'' 
                     END 
        --/ Integer
                ELSE SPACE(16 - LEN(TYPE_NAME(sys.columns.[system_type_id]))) 
                   + CASE WHEN COLUMNPROPERTY ( @intTableID , sys.columns.[name] , ''IsIdentity'' ) = 0 
                         THEN '' '' 
                         ELSE '' IDENTITY('' 
                            + CONVERT(VARCHAR,ISNULL(IDENT_SEED(@strTableName),1) ) 
                            + '','' 
                            + CONVERT(VARCHAR,ISNULL(IDENT_INCR(@strTableName),1) ) 
                            + '')'' 
                         END 
                   + SPACE(2) 
                   + CASE WHEN sys.columns.[is_nullable] = 0 
                         THEN '' NOT NULL'' 
                         ELSE '' NULL'' 
                     END 
                 END 
          + CASE WHEN sys.columns.[default_object_id] = 0 
                THEN '''' 
                ELSE '' DEFAULT '' + ISNULL(def.[definition] ,'''') 
            END
        END --iscomputed 
    FROM  sys.columns 
      LEFT OUTER JOIN sys.default_constraints DEF ON sys.columns.[default_object_id] = DEF.[object_id] 
    WHERE sys.columns.[object_id] = @intTableID 
    ORDER BY 
          sys.columns.[column_id] 
--/ ***************************************************************************************************************** 
--/ USED FOR FORMATTING THE REST OF THE CONSTRAINTS: 
--/ ***************************************************************************************************************** 
    SELECT @strCharLength = MAX(LEN([name])) + 1 
    FROM   sys.objects 
--/ ***************************************************************************************************************** 
--/ PK/Unique Constraints and Indexes, using the 2005/08 INCLUDE syntax 
--/ ***************************************************************************************************************** 
--/ Table variable to store the necessary information
    DECLARE @Results TABLE 
       ( 
        [schema_id] int
       ,[schema_name] varchar(255)
       ,[object_id] int
       ,[object_name] varchar(255)
       ,[index_id] int
       ,[index_name] varchar(255)
       ,[Rows] int
       ,[SizeMB] decimal(19,3)
       ,[IndexDepth] int
       ,[type] int
       ,[type_desc] varchar(30)
       ,[fill_factor] int
       ,[is_unique] int
       ,[is_primary_key] int
       ,[is_unique_constraint] int
       ,[index_columns_key] varchar(max) 
       ,[index_columns_include] varchar(max)
        ) 
--/ Get require index/constraint data        
    INSERT INTO @Results 
    SELECT sys.schemas.schema_id, sys.schemas.[name] AS schema_name
          ,sys.objects.[object_id], sys.objects.[name] AS object_name
          ,sys.indexes.index_id, ISNULL(sys.indexes.[name], ''---'') AS index_name
          ,partitions.Rows, partitions.SizeMB, IndexProperty(sys.objects.[object_id], sys.indexes.[name], ''IndexDepth'') AS IndexDepth
          ,sys.indexes.type, sys.indexes.type_desc, sys.indexes.fill_factor
          ,sys.indexes.is_unique, sys.indexes.is_primary_key, sys.indexes.is_unique_constraint
          ,ISNULL(Index_Columns.index_columns_key, ''---'') AS index_columns_key
          ,ISNULL(Index_Columns.index_columns_include, ''---'') AS index_columns_include 
    FROM sys.objects 
      INNER JOIN sys.schemas ON sys.objects.schema_id=sys.schemas.schema_id 
      INNER JOIN sys.indexes ON sys.objects.[object_id]=sys.indexes.[object_id] 
      INNER JOIN (SELECT [object_id]
                        ,index_id
                        ,SUM(row_count) AS Rows 
                        ,CONVERT(numeric(19,3), CONVERT(numeric(19,3), SUM(in_row_reserved_page_count+lob_reserved_page_count+row_overflow_reserved_page_count))
                           /CONVERT(numeric(19,3), 128)) AS SizeMB 
                  FROM sys.dm_db_partition_stats 
                  GROUP BY 
                         [object_id]
                        ,index_id 
                 ) AS partitions ON sys.indexes.[object_id]=partitions.[object_id] 
                                AND sys.indexes.index_id=partitions.index_id 
      CROSS APPLY (SELECT LEFT(index_columns_key, LEN(index_columns_key)-1) AS index_columns_key
                         ,LEFT(index_columns_include, LEN(index_columns_include)-1) AS index_columns_include 
                   FROM  (SELECT( 
                                 SELECT sys.columns.[name] + '','' + '' '' 
                                 FROM   sys.index_columns 
                                   INNER JOIN sys.columns ON sys.index_columns.column_id=sys.columns.column_id 
                                                         AND sys.index_columns.[object_id]=sys.columns.[object_id] 
                                 WHERE  sys.index_columns.is_included_column=0 
                                 AND    sys.indexes.[object_id]=sys.index_columns.[object_id] 
                                 AND    sys.indexes.index_id=sys.index_columns.index_id 
                                 ORDER BY 
                                        key_ordinal 
                                 FOR XML PATH('''') 
                                ) AS index_columns_key
                               ,(
                                 SELECT sys.columns.[name] + '','' + '' '' 
                                 FROM   sys.index_columns 
                                   INNER JOIN sys.columns ON sys.index_columns.column_id=sys.columns.column_id 
                                                         AND sys.index_columns.[object_id]=sys.columns.[object_id] 
                                 WHERE  sys.index_columns.is_included_column=1 
                                 AND    sys.indexes.[object_id]=sys.index_columns.[object_id] 
                                 AND    sys.indexes.index_id=sys.index_columns.index_id 
                                 ORDER BY 
                                        index_column_id 
                                 FOR XML PATH('''') 
                                ) AS index_columns_include 
                             ) AS Index_Columns 
                         ) AS Index_Columns 
                    WHERE sys.schemas.[name] LIKE CASE WHEN @strSchemaName='''' THEN sys.schemas.[name] ELSE @strSchemaName END 
                    AND   sys.objects.[name] LIKE CASE WHEN @strTableName='''' THEN sys.objects.[name] ELSE @strTableName END 
                    ORDER BY 
                          sys.schemas.[name]
                         ,sys.objects.[name]
                         ,sys.indexes.[name] 
--/ @Results table has both PK,s Uniques and indexes in thme...pull them out for adding to funal results: 
    SET @strContraintSQL = '''' 
    SET @strIndexSQL = '''' 
--/ ***************************************************************************************************************** 
--/ CONSTRAINTS 
--/ ***************************************************************************************************************** 
    SELECT @strContraintSQL = @strContraintSQL + 
           CASE WHEN is_primary_key = 1 or is_unique = 1 
               THEN @vbCrLf
                  + ''ALTER TABLE ['' + @strSchemaName + ''].['' + @strTableName + '']'' + @vbCrLf 
                  + ''    ADD CONSTRAINT ['' + index_name + ''] '' 
                  + CASE WHEN is_primary_key = 1 THEN ''PRIMARY KEY '' ELSE CASE WHEN is_unique = 1 THEN ''UNIQUE '' ELSE '''' END END 
                  + type_desc  
                  + '' ('' + index_columns_key + '')'' 
                  + CASE WHEN index_columns_include <> ''---'' THEN '' INCLUDE ('' + index_columns_include + '')'' ELSE '''' END 
                  + CASE WHEN fill_factor <> 0 THEN '' WITH FILLFACTOR = '' + CONVERT(VARCHAR(30),fill_factor) ELSE '''' END 
               ELSE '''' 
           END + @vbCrLf + ''GO''
    FROM  @RESULTS 
    WHERE [type_desc] != ''HEAP'' 
    AND   (is_primary_key = 1 or is_unique = 1)
    ORDER BY 
          is_primary_key DESC
         ,is_unique desc 
--/ ***************************************************************************************************************** 
--/ INDEXES 
--/ ***************************************************************************************************************** 
    SELECT @strIndexSQL = @strIndexSQL + 
           CASE WHEN is_primary_key = 0 or is_unique = 0 
               THEN @vbCrLf 
                  + ''CREATE INDEX ['' + index_name + ''] '' 
                  + SPACE(@strCharLength - LEN(index_name)) 
                  + '' ON ['' + [object_name] + '']'' 
                  + '' ('' + index_columns_key + '')'' 
                  + CASE WHEN index_columns_include <> ''---'' THEN '' INCLUDE ('' + index_columns_include + '')'' ELSE '''' END 
                  + CASE WHEN fill_factor <> 0 THEN '' WITH FILLFACTOR = '' + CONVERT(VARCHAR(30),fill_factor) ELSE '''' END 
           END 
    FROM   @RESULTS 
    WHERE  [type_desc] != ''HEAP'' 
    AND    is_primary_key = 0 
    AND    is_unique = 0 
    ORDER BY 
           is_primary_key DESC
          ,is_unique DESC 
    IF @strIndexSQL <> ''''
        SET @strIndexSQL = @vbCrLf + ''GO'' + @vbCrLf + @strIndexSQL 
--/ ***************************************************************************************************************** 
--/ CHECK CONSTRAINTS 
--/ ***************************************************************************************************************** 
    SET @strCheckConstraintSQL = '''' 
    SELECT @strCheckConstraintSQL = @strCheckConstraintSQL 
         + @vbCrLf 
         + ISNULL(''CONSTRAINT ['' + sys.objects.[name] + ''] '' 
         + '' CHECK '' + ISNULL(sys.check_constraints.definition,'''') 
         + '','','''') 
    FROM   sys.objects 
      INNER JOIN sys.check_constraints ON sys.objects.[object_id] = sys.check_constraints.[object_id] 
    WHERE sys.objects.type = ''C'' 
    AND   sys.objects.parent_object_id = @intTableID 
--/ ***************************************************************************************************************** 
--/ FOREIGN KEYS 
--/ ***************************************************************************************************************** 
    SET @strFKConstraintSQL = ''''
    SELECT @strFKConstraintSQL=@strFKConstraintSQL 
         + @vbCrLf 
         + ''ALTER TABLE ['' + @strSchemaName + ''].['' + @strTableName + '']'' + @vbCrLf 
         + ''    ADD CONSTRAINT ['' + OBJECT_NAME(constid) +'']'' 
         + '' FOREIGN KEY ('' + COL_NAME(fkeyid,fkey) 
         + '') REFERENCES '' + OBJECT_NAME(rkeyid) 
         + ''('' + COL_NAME(rkeyid,rkey) + '')'' + @vbCrLf + ''GO''
    FROM   sysforeignkeys 
    WHERE  fkeyid = @intTableID 
--/ ***************************************************************************************************************** 
--/ RULES 
--/ ***************************************************************************************************************** 
SET @strRuleConstraintSQL = '''' 
SELECT 
 @strRuleConstraintSQL = @strRuleConstraintSQL 
 + ISNULL( 
 @vbCrLf 
 + ''if not exists(SELECT [name] FROM sys.objects WHERE TYPE=''''R'''' AND schema_id = '' + convert(varchar(30),sys.objects.schema_id) + '' AND [name] = ''''['' + object_name(sys.columns.[rule_object_id]) + '']'''')'' + @vbCrLf 
 + sys.sql_modules.definition + @vbCrLf + ''GO'' + @vbCrLf 
 + ''EXEC sp_binderule ['' + sys.objects.[name] + ''], ''''['' + OBJECT_NAME(sys.columns.[object_id]) + ''].['' + sys.columns.[name] + '']'''''' + @vbCrLf + ''GO'' ,'''') 
from sys.columns 
 inner join sys.objects 
 on sys.objects.[object_id] = sys.columns.[object_id] 
 inner join sys.sql_modules 
 on sys.columns.[rule_object_id] = sys.sql_modules.[object_id] 
WHERE sys.columns.[rule_object_id] <> 0 
 and sys.columns.[object_id] = @intTableID 
--/ ***************************************************************************************************************** 
--/ TRIGGERS 
--/ ***************************************************************************************************************** 
SET @strTriggerSQL = '''' 
SELECT 
 @strTriggerSQL = @strTriggerSQL + @vbCrLf + sys.sql_modules.[definition] + @vbCrLf + ''GO'' 
FROM sys.sql_modules 
WHERE [object_id] IN(SELECT 
 [object_id] 
 FROM sys.objects 
 WHERE type = ''TR'' 
 AND [parent_object_id] = @intTableID) 
IF @strTriggerSQL <> ''''
 SET @strTriggerSQL = @vbCrLf + ''GO'' + @vbCrLf + @strTriggerSQL 
--/ ***************************************************************************************************************** 
--/ NEW SECTION QUERY ALL EXTENDED PROPERTIES 
--/ ***************************************************************************************************************** 
SET @strExtendedProps = ''''
SELECT @strExtendedProps = 
 @strExtendedProps + @vbCrLf +
 ''EXEC sys.sp_addextendedproperty 
 @name = N'''''' + [name] + '''''', @value = N'''''' + REPLACE(convert(varchar(max),[value]),'''''''','''''''''''') + '''''', 
 @level0type = N''''SCHEMA'''', @level0name = ['' + @strSchemaName + ''], 
 @level1type = N''''TABLE'''', @level1name = ['' + @strTableName + ''];''
--SELECT objtype, objname, name, value
FROM fn_listextendedproperty (NULL, ''schema'', @strSchemaName, ''table'', @strTableName, NULL, NULL); 
IF @strExtendedProps <> '''' 
 SET @strExtendedProps = @vbCrLf + ''GO'' + @vbCrLf + @strExtendedProps
--/ ***************************************************************************************************************** 
--/ CLEANUP AND POST RESULTS TO OUTPUT PARAMETERS
--/ ***************************************************************************************************************** 
    SET @strTableSQL = @strTableSQL 
      + @vbCrLf + ''   )'' + @vbCrLf + ''GO''
--/ Output parms
    SET @strOutputTableSQL = @strTableSQL
    SET @strOutputConstraintSQL = @strContraintSQL
    SET @strOutputCheckConstraintSQL = @strCheckConstraintSQL
    SET @strOutputRuleConstraintSQL  = @strRuleConstraintSQL
    SET @strOutputFKConstraintSQL  = @strFKConstraintSQL
    SET @strOutputTriggerSQL = @strTriggerSQL
' 
END
GO
/****** Object:  Table [dbo].[tblGTY060]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY060]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY060](
	[USR_ID] [varchar](30) NOT NULL,
	[USR_FNME] [varchar](175) NOT NULL,
	[USR_SNME] [varchar](175) NOT NULL,
	[USR_EMAIL] [varchar](126) NULL,
	[USR_TEL_NO] [varchar](30) NULL,
	[USR_JOB_TTL] [varchar](50) NULL,
	[USR_PCL_NME] [varchar](255) NOT NULL,
	[USR_MGR_ID] [varchar](20) NULL,
	[USR_ACT] [bit] NOT NULL,
	[USR_ADMIN] [bit] NOT NULL,
	[USR_INACT_DT] [datetime] NULL,
 CONSTRAINT [PK_GTY060] PRIMARY KEY CLUSTERED 
(
	[USR_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY110]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY110]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY110](
	[CAT_ID] [char](5) NOT NULL,
	[CAT_NME] [varchar](50) NOT NULL,
	[PRT_CAT_ID] [varchar](5) NULL,
 CONSTRAINT [PK_GTY110] PRIMARY KEY CLUSTERED 
(
	[CAT_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY100]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY100]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY100](
	[PRG_ID] [char](5) NOT NULL,
	[PRG_NME] [varchar](25) NOT NULL,
	[PRG_EXE] [varchar](255) NOT NULL,
 CONSTRAINT [PK_GTY100] PRIMARY KEY CLUSTERED 
(
	[PRG_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_PRG_EXE] UNIQUE NONCLUSTERED 
(
	[PRG_EXE] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY040]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY040]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY040](
	[ENV_ID] [char](5) NOT NULL,
	[ENV_NME] [varchar](30) NOT NULL,
	[ENV_PTH] [varchar](500) NOT NULL,
	[ENV_ACT] [bit] NOT NULL,
 CONSTRAINT [PK_GTY040] PRIMARY KEY CLUSTERED 
(
	[ENV_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_ENV_NME] UNIQUE NONCLUSTERED 
(
	[ENV_NME] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblBOOrder]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblBOOrder]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblBOOrder](
	[ORD_SID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[FUD_SID] [int] NOT NULL,
	[USR_ID] [varchar](16) NOT NULL,
	[QTY] [int] NOT NULL,
	[ORD_DT] [datetime] NOT NULL,
	[ORD_CNC] [int] NOT NULL,
	[PLS_DEL] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ORD_SID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblBOFood]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblBOFood]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblBOFood](
	[FUD_SID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[FUD_NME] [varchar](255) NOT NULL,
	[FUD_DESC] [varchar](255) NOT NULL,
	[FUD_ICON] [varchar](255) NOT NULL,
	[FUD_PRICE] [decimal](18, 6) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[FUD_SID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblADImport]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblADImport]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblADImport](
	[sAMAccountName] [nvarchar](4000) NOT NULL,
	[givenName] [nvarchar](4000) NULL,
	[sn] [nvarchar](4000) NULL,
	[mail] [nvarchar](4000) NULL,
	[telephoneNumber] [nvarchar](4000) NULL,
	[title] [nvarchar](4000) NULL,
	[AccountExpireDate] [datetime2](7) NULL
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[tblGTY020]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY020]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY020](
	[APP_ID] [char](6) NOT NULL,
	[APP_CD] [varchar](8) NOT NULL,
	[APP_NME] [varchar](50) NOT NULL,
	[CAT_ID] [char](5) NOT NULL,
	[APP_BUS_USR_ID] [varchar](30) NOT NULL,
	[APP_TCH_USR_ID] [varchar](30) NOT NULL,
	[APP_SUB_FLD] [varchar](500) NOT NULL,
	[APP_DESC] [varchar](255) NULL,
	[APP_FROM_DT] [datetime] NOT NULL,
	[APP_TO_DT] [datetime] NULL,
	[APP_NME_LNG] [varchar](100) NULL,
 CONSTRAINT [PK_GTY020] PRIMARY KEY CLUSTERED 
(
	[APP_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_APP_CD] UNIQUE NONCLUSTERED 
(
	[APP_CD] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[uspSYSKeySequence]    Script Date: 07/19/2016 14:43:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspSYSKeySequence]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspSYSKeySequence] 
    @strKeyID CHAR(3)
   ,@strNewKey VARCHAR(15) OUTPUT
AS

--- DECLARE VARIABLES
	DECLARE @intKeyLen INTEGER
	
    SET NOCOUNT ON
    
    SET @strNewKey = ''ERROR''
        
--- GET THE NEW KEY
	SET @intKeyLen = (SELECT TBL_KEY_LEN FROM dbo.tblSYSKey WHERE TBL_KEY_ID = @strKeyID)
	
    IF @intKeyLen > 0
        BEGIN		
            -- Generate a new ID
			SELECT @strNewKey = TBL_KEY_ID + RIGHT(''000000000000'' + CONVERT(VARCHAR(12), KEY_SEQ_NBR), @intKeyLen)
			FROM   dbo.tblSYSKey
			WHERE  TBL_KEY_ID = @strKeyID
			
			-- Roll on key ID to next
			UPDATE dbo.tblSYSKey
			SET    KEY_SEQ_NBR = KEY_SEQ_NBR + 1
			WHERE  TBL_KEY_ID = @strKeyID
        END
--
' 
END
GO
/****** Object:  View [dbo].[vwAppCategory]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppCategory]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppCategory]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY110
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspEditEnvironment]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditEnvironment]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditEnvironment] 
	@strReturnCode		VARCHAR(25) OUTPUT
   ,@strEnvID			CHAR(5)
   ,@strEnvironment		VARCHAR(30) = NULL
   ,@strEnvPath			VARCHAR(500) = NULL
   ,@bitActive			BIT = NULL
AS
    
    SET NOCOUNT ON
    
--- If The supplied ID is found, then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY040 WHERE ENV_ID = @strEnvID) = 1
        BEGIN
		-- IF the environment name has been changed and does not exist, continue
		IF (SELECT COUNT(1) FROM dbo.tblGTY040 WHERE ENV_NME = @strEnvironment AND ENV_ID <> @strEnvID) = 0
            BEGIN
				UPDATE dbo.tblGTY040
				SET    ENV_NME = 
								CASE WHEN @strEnvironment IS NOT NULL AND @strEnvironment <> ''''
								  THEN @strEnvironment
								  ELSE ENV_NME
								END
					  ,ENV_PTH = 
								CASE WHEN @strEnvPath IS NOT NULL AND @strEnvPath <> ''''
								  THEN @strEnvPath
								  ELSE ENV_PTH
								END
					  ,ENV_ACT = 
								CASE WHEN @bitActive IS NOT NULL AND @bitActive <> ''''
								  THEN @bitActive
								  ELSE ENV_ACT
								END							
				WHERE ENV_ID = @strEnvID
				
				SET @strReturnCode = ''EDITED''
            END
        ELSE
			SET @strReturnCode = ''ERROR (ENVIRONMENT NAME ALREADY EXISTS)''
        END
    ELSE
		SET @strReturnCode = ''ERROR (ENVIRONMENT ID NOT FOUND)''
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspEditProgramInfo]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditProgramInfo]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditProgramInfo] 
	@strReturnCode		VARCHAR(25)
   ,@strProgramID		CHAR(5)
   ,@strProgramName		VARCHAR(25) = NULL
   ,@strProgramExe      VARCHAR(255) = NULL
AS
    
    SET NOCOUNT ON
    
--- If File type does not exists, create it
    IF (SELECT COUNT(1) FROM dbo.tblGTY100 WHERE PRG_ID = @strProgramID) = 1
        BEGIN
		-- IF program exe supplied is not in use or if supplied, hasn''t changed continue
		IF (SELECT COUNT(1) FROM dbo.tblGTY100 WHERE PRG_EXE = @strProgramExe AND PRG_ID <> @strProgramID) = 0
            BEGIN
				UPDATE dbo.tblGTY100
				SET    PRG_EXE = 
								CASE WHEN @strProgramExe IS NOT NULL AND @strProgramExe <> ''''
								  THEN @strProgramExe
								  ELSE PRG_EXE
								END
					  ,PRG_NME = 
								CASE WHEN @strProgramName IS NOT NULL AND @strProgramName <> ''''
								  THEN @strProgramName
								  ELSE PRG_NME
								END
								
				WHERE PRG_ID = @strProgramID
				
				SET @strReturnCode = ''EDITED''
            END
        ELSE
			SET @strReturnCode = ''ERROR (PROGRAM EXE ALREADY EXISTS)''
        END
    ELSE
		SET @strReturnCode = ''ERROR (PROGRAM ID NOT FOUND)''
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspEditCategory]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditCategory]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditCategory]
	@strCatID CHAR(5)
   ,@strCategory VARCHAR(255) = NULL
   ,@strParentCatID CHAR(5) = NULL
   ,@strReturnCode VARCHAR(100) OUTPUT
AS
   
    SET NOCOUNT ON
        
--- If Category does exists then edit, else stop
    IF (SELECT COUNT(1) FROM dbo.tblGTY110 CAT WHERE CAT.CAT_ID = @strCatID) = 1
        BEGIN
            UPDATE dbo.tblGTY110
            SET
              CAT_NME = 
						CASE WHEN @strCategory <> ''''
						  THEN @strCategory
						  ELSE CAT_NME
						END
             ,PRT_CAT_ID = @strParentCatID
            WHERE CAT_ID = @strCatID
            
			SET @strReturnCode = ''UPDATED''
        END
    ELSE
        BEGIN
            SET @strReturnCode = ''DOES NOT EXIST''
        END
--
' 
END
GO
/****** Object:  Table [dbo].[tblGTY120]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY120]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY120](
	[USR_ID] [varchar](30) NOT NULL,
	[BSU_ID] [char](5) NOT NULL,
 CONSTRAINT [PK_GTY120] PRIMARY KEY CLUSTERED 
(
	[USR_ID] ASC,
	[BSU_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[uspADUpdateUsers]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspADUpdateUsers]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[uspADUpdateUsers] AS 

    SET NOCOUNT ON
    
--/ Update existing users in the Gateway
    UPDATE dbo.tblGTY060
    
    SET    USR_FNME = AI.givenName
          ,USR_SNME = AI.sn
          ,USR_EMAIL = AI.mail
          ,USR_TEL_NO = AI.telephoneNumber
          ,USR_JOB_TTL = AI.title
    
    FROM   dbo.tblGTY060 GTY INNER JOIN dbo.tblADImport AI
      ON   GTY.USR_ID = AI.sAMAccountName

--/ Update deleted users (note we do not use the AccountExpireDate at this time)
    UPDATE dbo.tblGTY060
    
    SET    USR_INACT_DT = GETDATE()
    
    FROM   dbo.tblGTY060 GTY 
    
    WHERE  NOT EXISTS (SELECT 1
                       FROM   dbo.tblADImport AI
                       WHERE  AI.sAMAccountName = GTY.USR_ID)    

--/ Insert new users into the Gateway table
    INSERT INTO dbo.tblGTY060 (USR_ID
                              ,USR_FNME
                              ,USR_SNME
                              ,USR_EMAIL
                              ,USR_TEL_NO
                              ,USR_JOB_TTL
                              ,USR_MGR_ID
                              ,USR_ACT
                              ,USR_ADMIN
                              ,USR_INACT_DT
                              ,USR_PCL_NME)
                                           
    SELECT AI.sAMAccountName
          ,AI.givenName
          ,AI.sn
          ,AI.mail
          ,AI.telephoneNumber
          ,AI.title
          ,NULL
          ,0
          ,0
          ,NULL
          ,''PCL:'' + AI.sAMAccountName
          
    FROM   dbo.tblADImport AI
    
    WHERE  NOT EXISTS (SELECT 1
                       FROM   dbo.tblGTY060 GTY
                       WHERE  AI.sAMAccountName = GTY.USR_ID)
    AND    LEN(AI.sAMAccountName) = 5
    AND    AI.givenName IS NOT NULL
    AND    AI.sn IS NOT NULL        

' 
END
GO
/****** Object:  View [dbo].[vwEnvironments]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwEnvironments]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwEnvironments]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY040
--
'
GO
/****** Object:  View [dbo].[vwBusinessUnit]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwBusinessUnit]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwBusinessUnit]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY080
--
'
GO
/****** Object:  View [dbo].[vwFoodOrders]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFoodOrders]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vwFoodOrders] AS 
SELECT ORD_SID, FUD_NME, FUD_DESC, O.USR_ID, USR_FNME, USR_SNME, ORD_DT
FROM   tblBOOrder O INNER JOIN tblBOFood F ON O.FUD_SID = F.FUD_SID INNER JOIN dbo.tblGTY060 U ON O.USR_ID = U.USR_ID'
GO
/****** Object:  View [dbo].[vwFood]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFood]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vwFood] AS
SELECT * FROM dbo.tblBOFood'
GO
/****** Object:  View [dbo].[vwFileGroups]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFileGroups]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwFileGroups]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY130
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspImportActiveDirectoryUsers]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspImportActiveDirectoryUsers]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[uspImportActiveDirectoryUsers] AS 

DECLARE @intRowCount INTEGER
DECLARE @intChar INTEGER
DECLARE @strMainChar CHAR(1)
DECLARE @strNameCharStart VARCHAR(100)
DECLARE @strNameCharEnd VARCHAR(100)
DECLARE @strSQL VARCHAR(2000)
DECLARE @intSubChar INTEGER
DECLARE @strSubChar CHAR(1)
DECLARE @strSubStartChar CHAR(1)
DECLARE @strSubEndChar VARCHAR(5)
    SET NOCOUNT ON
--/ Delete previous contents of table
    TRUNCATE TABLE dbo.tblADImport    
--/ Set start character
    SET @intChar = 65
    SET @strMainChar = CHAR(@intChar)
    SET @strSubStartChar = ''#''
    SET @intRowCount = 1    
--/ Until no records are found
    WHILE @intChar <= 90
        BEGIN
        --/ Fudge to get around the 901 limitation for records returned
            IF @strSubStartChar = ''#''
                BEGIN
                    SET @strSubStartChar = '''' --/ Allows non-text characters to be picked up
                    SET @strSubEndChar = ''K''
                END 
            ELSE IF @strSubEndChar = ''K''
                BEGIN
                    SET @strSubStartChar = ''K''
                    SET @strSubEndChar = ''P''
                END
            ELSE IF @strSubEndChar = ''P''
                BEGIN
                    SET @strSubStartChar = ''P''
                    SET @strSubEndChar = ''ZZZZZ''
                END                
            ELSE 
                BEGIN
                    SET @strSubStartChar = ''#''
                    SET @strSubEndChar = ''''
                --/ Roll on the main character by one
                    SET @intChar = @intChar + 1
                    SET @strMainChar = CHAR(@intChar)
                END   
            IF @strSubStartChar <> ''#''
                BEGIN
                    SET @strNameCharStart = @strMainChar + @strSubStartChar
                    SET @strNameCharEnd = @strMainChar + @strSubEndChar                                     
                --/ Construct the query, getting data from Active Directory based upon the last name loaded
                    SET @strSQL = ''''
                    SET @strSQL = @strSQL + ''INSERT INTO dbo.tblADImport (sAMAccountName''
                    SET @strSQL = @strSQL + ''                            ,givenName''
                    SET @strSQL = @strSQL + ''                            ,sn''
                    SET @strSQL = @strSQL + ''                            ,mail''
                    SET @strSQL = @strSQL + ''                            ,telephoneNumber''
                    SET @strSQL = @strSQL + ''                            ,title''
                    SET @strSQL = @strSQL + ''                            ,AccountExpireDate)''
                    SET @strSQL = @strSQL + '' ''
                    SET @strSQL = @strSQL + ''SELECT TOP 901 sAMAccountName''
                    SET @strSQL = @strSQL + ''      ,givenName''
                    SET @strSQL = @strSQL + ''      ,sn''
                    SET @strSQL = @strSQL + ''      ,mail''
                    SET @strSQL = @strSQL + ''      ,telephoneNumber''
                    SET @strSQL = @strSQL + ''      ,title''
                    SET @strSQL = @strSQL + ''      ,CASE WHEN RIGHT(AccountExpires, 1) <> ''''0'''' THEN NULL ''
                    SET @strSQL = @strSQL + ''            WHEN AccountExpires = ''''0'''' THEN NULL''
                    SET @strSQL = @strSQL + ''            ELSE DATEADD(mi,(CONVERT(BIGINT, accountExpires) / 600000000) + DATEDIFF(Minute,GetUTCDate(),GetDate()),CAST(''''1/1/1601'''' AS DATETIME2)) ''
                    SET @strSQL = @strSQL + ''       END AS AccountExpireDate''
                    SET @strSQL = @strSQL + '' ''
                    SET @strSQL = @strSQL + ''FROM   OPENQUERY(ADSI, ''''SELECT title''
                    SET @strSQL = @strSQL + ''                               ,sAMAccountName''
                    SET @strSQL = @strSQL + ''                               ,givenName''
                    SET @strSQL = @strSQL + ''                               ,mail''
                    SET @strSQL = @strSQL + ''                               ,telephoneNumber''
                    SET @strSQL = @strSQL + ''                               ,sn''
                    SET @strSQL = @strSQL + ''                               ,accountExpires ''
                    SET @strSQL = @strSQL + ''                        FROM ''''''''LDAP://DC=oa,DC=pnrad,DC=net'''''''' ''
                    SET @strSQL = @strSQL + ''                        WHERE   objectClass = ''''''''User'''''''' AND  objectCategory=''''''''person'''''''' ''
                    SET @strSQL = @strSQL + ''                        AND     sAMAccountName >= '''''''''' + REPLACE(@strNameCharStart, '''''''', '''') + ''''''''''''
                    SET @strSQL = @strSQL + ''                        AND     sAMAccountName < '''''''''' + REPLACE(@strNameCharEnd, '''''''', '''') + ''''''''''''
                    SET @strSQL = @strSQL + ''                 '''')''        
                --/ Execute the SQL
                    EXEC (@strSQL)
                --/ Get number of records found (0 will escape the loop)            
                    SET @intRowCount = @@ROWCOUNT
                    PRINT ''Records for '' + @strNameCharStart + '' to '' + @strNameCharEnd + '' = '' + CONVERT(VARCHAR(10), @intRowCount)
                END
            END
--/ ********************************************************************************************************
--/ PREVIOUS VERSION
--/ ********************************************************************************************************
--DECLARE @intChar INTEGER
--DECLARE @strNameChar VARCHAR(100)
--DECLARE @strSQL VARCHAR(2000)
--DECLARE @intSubChar INTEGER
--DECLARE @strSubChar CHAR(1)
--DECLARE @intRowCount INTEGER
--    SET NOCOUNT ON
----/ Delete previous contents of table
--    TRUNCATE TABLE dbo.tblADImport
----/ Set start character
--    SET @strNameChar = ''A''
--    SET @intRowCount = 1    
----/ Until no records are found
--    WHILE @intRowCount <> 0
--        BEGIN
--        --/ Construct the query, getting data from Active Directory based upon the last name loaded
--            SET @strSQL = ''''
--            SET @strSQL = @strSQL + ''INSERT INTO dbo.tblADImport (sAMAccountName''
--            SET @strSQL = @strSQL + ''                            ,givenName''
--            SET @strSQL = @strSQL + ''                            ,sn''
--            SET @strSQL = @strSQL + ''                            ,mail''
--            SET @strSQL = @strSQL + ''                            ,telephoneNumber''
--            SET @strSQL = @strSQL + ''                            ,title''
--            SET @strSQL = @strSQL + ''                            ,AccountExpireDate)''
--            SET @strSQL = @strSQL + '' ''
--            SET @strSQL = @strSQL + ''SELECT TOP 901 sAMAccountName''
--            SET @strSQL = @strSQL + ''      ,givenName''
--            SET @strSQL = @strSQL + ''      ,sn''
--            SET @strSQL = @strSQL + ''      ,mail''
--            SET @strSQL = @strSQL + ''      ,telephoneNumber''
--            SET @strSQL = @strSQL + ''      ,title''
--            SET @strSQL = @strSQL + ''      ,CASE WHEN RIGHT(AccountExpires, 1) <> ''''0'''' THEN NULL ''
--            SET @strSQL = @strSQL + ''            WHEN AccountExpires = ''''0'''' THEN NULL''
--            SET @strSQL = @strSQL + ''            ELSE DATEADD(mi,(CONVERT(BIGINT, accountExpires) / 600000000) + DATEDIFF(Minute,GetUTCDate(),GetDate()),CAST(''''1/1/1601'''' AS DATETIME2)) ''
--            SET @strSQL = @strSQL + ''       END AS AccountExpireDate''
--            SET @strSQL = @strSQL + '' ''
--            SET @strSQL = @strSQL + ''FROM   OPENQUERY(ADSI, ''''SELECT title''
--            SET @strSQL = @strSQL + ''                               ,sAMAccountName''
--            SET @strSQL = @strSQL + ''                               ,givenName''
--            SET @strSQL = @strSQL + ''                               ,mail''
--            SET @strSQL = @strSQL + ''                               ,telephoneNumber''
--            SET @strSQL = @strSQL + ''                               ,sn''
--            SET @strSQL = @strSQL + ''                               ,accountExpires ''
--            SET @strSQL = @strSQL + ''                        FROM ''''''''LDAP://DC=oa,DC=pnrad,DC=net'''''''' ''
--            SET @strSQL = @strSQL + ''                        WHERE   objectClass = ''''''''User'''''''' AND  objectCategory=''''''''person'''''''' ''
--            SET @strSQL = @strSQL + ''                        AND     sn > '''''''''' + REPLACE(@strNameChar, '''''''', '''') + ''''''''''''
--            SET @strSQL = @strSQL + ''                 '''')''        
--        --/ Execute the SQL
--            EXEC (@strSQL)
--        --/ Get number of records found (0 will escape the loop)            
--            SET @intRowCount = @@ROWCOUNT
--        --/ Get latest name
--            SELECT @strNameChar = (SELECT MAX(sn) FROM dbo.tblADImport)
--            SELECT @strNameChar
--        END


' 
END
GO
/****** Object:  View [dbo].[vwUsers]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwUsers]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwUsers]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY060
--
'
GO
/****** Object:  View [dbo].[vwSYSKeys]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwSYSKeys]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwSYSKeys]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblSYSKey
--
'
GO
/****** Object:  View [dbo].[vwPrograms]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwPrograms]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwPrograms]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY100
--
'
GO
/****** Object:  View [dbo].[vwAppUsrRelationship]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppUsrRelationship]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppUsrRelationship]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY120
--
'
GO
/****** Object:  View [dbo].[vwApplications]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwApplications]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwApplications]

AS

--- Direct Select of table
	SELECT APP_ID
		  ,APP_CD
		  ,APP_NME
		  ,APP_NME_LNG
		  ,CAT_ID
		  ,APP_BUS_USR_ID
		  ,APP_TCH_USR_ID
		  ,APP_SUB_FLD
		  ,APP_DESC
		  ,CONVERT(DATETIME, APP_FROM_DT, 120) AS APP_FROM_DT
		  ,CONVERT(DATETIME, APP_TO_DT, 120) AS APP_TO_DT   
	FROM   dbo.tblGTY020
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspAddProgramInfo]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddProgramInfo]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddProgramInfo]
    @strProgramName		VARCHAR(25)
   ,@strProgramExe      VARCHAR(255)
   ,@strProgramID       CHAR(5) OUTPUT
AS
--- Define Variables
    DECLARE @strCatID CHAR(5)
    
    SET NOCOUNT ON
    
--- If File type does not exists, create it
    IF (SELECT COUNT(1) FROM dbo.tblGTY100 PRG WHERE PRG.PRG_EXE = @strProgramExe) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''PRG'', @strProgramID OUTPUT
            
            INSERT INTO dbo.tblGTY100
            VALUES
            (
              @strProgramID
             ,@strProgramName 
             ,@strProgramExe
            )
        END
    ELSE
        BEGIN
            SET @strProgramID = (SELECT PRG.PRG_ID FROM dbo.tblGTY100 PRG WHERE PRG.PRG_EXE = @strProgramExe) 
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspAddEnvironment]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddEnvironment]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddEnvironment] 
    @strEnvironment VARCHAR(30)
   ,@strEnvPath VARCHAR(500)
   ,@strEnvID CHAR(5) OUTPUT
AS
   
    SET NOCOUNT ON
        
--- If Environment doesn''t exists, create and return ID
    IF (SELECT COUNT(1) FROM dbo.tblGTY040 ENV WHERE ENV.ENV_NME = @strEnvironment) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''ENV'', @strEnvID OUTPUT
            
            INSERT INTO dbo.tblGTY040
            VALUES
            (
              @strEnvID
             ,@strEnvironment
             ,@strEnvPath
             ,0
            )
        END
    ELSE
        BEGIN
            SET @strEnvID = (SELECT ENV.ENV_ID FROM dbo.tblGTY040 ENV WHERE ENV.ENV_NME = @strEnvironment) 
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspAddCategory]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddCategory]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddCategory] 
    @strCategory VARCHAR(255)
   ,@strCatID CHAR(5) OUTPUT
AS
   
    SET NOCOUNT ON
        
--- If Category does NOT exists add a new category and then get ID
    IF (SELECT COUNT(1) FROM dbo.tblGTY110 CAT WHERE CAT.CAT_NME = @strCategory) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''CAT'', @strCatID OUTPUT
            
            INSERT INTO dbo.tblGTY110
            VALUES
            (
              @strCatID
             ,@strCategory
             ,''CAT00''
            )
        END
    ELSE
        BEGIN
            SET @strCatID = (SELECT CAT.CAT_ID FROM tblGTY110 CAT WHERE CAT.CAT_NME = @strCategory) 
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspAddBusinessUnit]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddBusinessUnit]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddBusinessUnit]
    @strBusinessUnit VARCHAR(255)
   ,@strBusID CHAR(5) OUTPUT
AS
    
    SET NOCOUNT ON
    
--- If Business Unit does NOT exist, add a new Value and then get ID
    IF (SELECT COUNT(1) FROM dbo.tblGTY080 BSU WHERE BSU.BSU_NME = @strBusinessUnit) = 0
        BEGIN
            -- Generate a new ID            
            EXEC dbo.uspSYSKeySequence ''BSU'', @strBusID OUTPUT
            
            INSERT INTO dbo.tblGTY080
            VALUES
            (
              @strBusID
             ,@strBusinessUnit
            )
        END
    ELSE
        BEGIN
            SET @strBusID = (SELECT BSU.BSU_ID FROM tblGTY080 BSU WHERE BSU.BSU_NME = @strBusinessUnit)
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspDecomApplication]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspDecomApplication]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspDecomApplication]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAppID           CHAR(6)

AS	
        
    SET NOCOUNT ON

--- If Application ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY020 APP WHERE APP.APP_ID = @strAppID) = 1
		BEGIN
			-- Edit required details table
			UPDATE dbo.tblGTY020
			SET    APP_TO_DT = GETDATE()
			WHERE  APP_ID = @strAppID
				
			SET @strReturnCode = ''DECOMMISSIONED''
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = ''ERROR (RECORD NOT FOUND)''
        END 
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspMIActiveApplicationUsers]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspMIActiveApplicationUsers]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[uspMIActiveApplicationUsers] AS 

DECLARE @strAppName VARCHAR(75)
DECLARE @strIN VARCHAR(1000)
DECLARE @strFields VARCHAR(4000)
DECLARE @strSQL NVARCHAR(4000)
    SET NOCOUNT ON
--/ Set starting values
    SET @strFields = ''SELECT UserID, '' + CHAR(13) + CHAR(10) + ''       UserName, '' + CHAR(13) + CHAR(10)
    SET @strIN = ''''
    SET @strSQL = ''''
--/ Get list of all charged currencies  
    DECLARE curData CURSOR
    FOR 
    SELECT APP_NME 
    FROM   dbo.tblGTY020 
    WHERE  APP_NME NOT IN (''TEMPLATE'', ''SQL_SVR_Class'')
    ORDER BY 
           APP_NME   
--/ Open the cursor
    OPEN curData
--/ Get first record    
    FETCH curData INTO @strAppName
--/ Loop through data    
    WHILE @@FETCH_STATUS <> -1
        BEGIN
            SET @strIN = @strIN + ''['' + @strAppName + '']'' + '',''
            SET @strFields = @strFields + ''       ISNULL(['' + @strAppName + ''],0) AS ['' + @strAppName + ''],'' + CHAR(13) + CHAR(10)
            FETCH curData INTO @strAppName
        END 
--/ Close and kill cursor        
    CLOSE curData
    DEALLOCATE curData
--/ Remove trailing commas    
    SET @strIN = LEFT(@strIN, LEN(@strIN)-1)
    SET @strFields = LEFT(@strFields, LEN(@strFields)-3)   
--/ Construct the SQL      
    SET @strSQL = @strSQL + @strFields + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''FROM ''+ CHAR(13) + CHAR(10) 
    SET @strSQL = @strSQL + ''    ('' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''     SELECT APP.APP_NME AS AppName'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''           ,UPPER(UPM.USR_ID) AS UserID'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''           ,USR.USR_FNME + '' + '''''''' + '' '' + '''''''' + '' + USR.USR_SNME AS UserName'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''           ,1 AS CNT'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''     FROM   dbo.vwApplications APP'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''       INNER JOIN dbo.vwAppEnvironments AEV ON APP.APP_ID = AEV.APP_ID'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''       INNER JOIN dbo.vwEnvironments ENV ON AEV.ENV_ID = ENV.ENV_ID'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''       INNER JOIN dbo.vwAppPermissions UPM ON AEV.AE_ID = UPM.AE_ID'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''       INNER JOIN dbo.vwUsers USR ON UPM.USR_ID = USR.USR_ID'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''     WHERE  ENV.ENV_NME = '' + '''''''' + ''Production'' + '''''''' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''     AND    APP.APP_NME NOT IN ('' + '''''''' + ''TEMPLATE'' + '''''''' + '','' + '''''''' + ''SQL_SVR_Class'' + '''''''' + '')'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''    ) ps'' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''PIVOT'' + CHAR(13) + CHAR(10)     
    SET @strSQL = @strSQL + ''    ('' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''     SUM(CNT) '' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''     FOR [AppName] IN '' + CHAR(13) + CHAR(10)
    SET @strSQL = @strSQL + ''         ('' + @strIN + '')'' + CHAR(13) + CHAR(10) 
    SET @strSQL = @strSQL + ''    ) AS pvt''

    --PRINT @strSQL
    EXEC sp_executesql @strSQL
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspManageUsrBsuRelationship]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspManageUsrBsuRelationship]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspManageUsrBsuRelationship]
	@strBsuID CHAR(6)
   ,@strUsrID VARCHAR(20)
   ,@bitActive	BIT
AS
    
    SET NOCOUNT ON

--- Add or remove relationship
	IF @bitActive = 1
		BEGIN
			IF (SELECT COUNT(1) FROM dbo.tblGTY120 UBR WHERE UBR.USR_ID = @strUsrID AND UBR.BSU_ID = @strBsuID) = 0
				BEGIN           
					INSERT INTO dbo.tblGTY120
					VALUES
					(
					  @strUsrID
					 ,@strBsuID
					)
				END
		END
	ELSE
		BEGIN
		IF (SELECT COUNT(1) FROM dbo.tblGTY120 UBR WHERE UBR.USR_ID = @strUsrID AND UBR.BSU_ID = @strBsuID) = 1
			BEGIN           
				DELETE
				FROM  dbo.tblGTY120
				WHERE USR_ID = @strUsrID
				  AND BSU_ID = @strBsuID
			END
        END
--
' 
END
GO
/****** Object:  Table [dbo].[tblGTY030]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY030]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY030](
	[AE_ID] [char](8) NOT NULL,
	[APP_ID] [char](6) NOT NULL,
	[ENV_ID] [char](5) NOT NULL,
 CONSTRAINT [PK_GTY030] PRIMARY KEY CLUSTERED 
(
	[AE_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_APP_ENV] UNIQUE NONCLUSTERED 
(
	[APP_ID] ASC,
	[ENV_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY010]    Script Date: 07/19/2016 14:43:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY010]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY010](
	[APP_ID] [char](6) NOT NULL,
	[BSU_ID] [char](5) NOT NULL,
 CONSTRAINT [PK_GTY010] PRIMARY KEY CLUSTERED 
(
	[APP_ID] ASC,
	[BSU_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY090]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY090]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY090](
	[APP_FLE_ID] [char](8) NOT NULL,
	[AE_ID] [char](8) NOT NULL,
	[FLE_PTH] [varchar](500) NULL,
	[FLE_NME] [varchar](255) NOT NULL,
	[FLE_DESC] [varchar](255) NULL,
	[FLE_GRP_ID] [char](5) NOT NULL,
	[PRG_ID] [char](5) NOT NULL,
 CONSTRAINT [PK_GTY090] PRIMARY KEY CLUSTERED 
(
	[APP_FLE_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_APP_FLE] UNIQUE NONCLUSTERED 
(
	[AE_ID] ASC,
	[FLE_PTH] ASC,
	[FLE_NME] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY050]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY050]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY050](
	[PER_ID] [char](8) NOT NULL,
	[AE_ID] [char](8) NOT NULL,
	[USR_ID] [varchar](30) NOT NULL,
	[AE_USR_ACT] [bit] NOT NULL,
	[LST_CPY] [datetime] NULL,
	[LST_LOG_IN] [datetime] NULL,
	[LST_LOG_OUT] [datetime] NULL,
	[CUR_ATN] [tinyint] NOT NULL,
	[PID] [int] NULL,
	[FAV] [bit] NOT NULL,
 CONSTRAINT [PK_GTY050] PRIMARY KEY CLUSTERED 
(
	[PER_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_AE_USR] UNIQUE NONCLUSTERED 
(
	[AE_ID] ASC,
	[USR_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  View [dbo].[vwAppBsuRelationship]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppBsuRelationship]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppBsuRelationship] 

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY010
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspManageAppBsuRelationship]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspManageAppBsuRelationship]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspManageAppBsuRelationship]
	@strBsuID CHAR(5)
   ,@strAppID CHAR(6)
   ,@bitActive	BIT
AS
    
    SET NOCOUNT ON

--- Add or remove relationship
	IF @bitActive = 1
		BEGIN
			IF (SELECT COUNT(1) FROM dbo.tblGTY010 ABR WHERE ABR.APP_ID = @strAppID AND ABR.BSU_ID = @strBsuID) = 0
				BEGIN           
					INSERT INTO dbo.tblGTY010
					VALUES
					(
					  @strAppID
					 ,@strBsuID
					)
				END
		END
	ELSE
		BEGIN
			IF (SELECT COUNT(1) FROM dbo.tblGTY010 ABR WHERE ABR.APP_ID = @strAppID AND ABR.BSU_ID = @strBsuID) = 1
			BEGIN           
				DELETE
				FROM  dbo.tblGTY010
				WHERE APP_ID = @strAppID
				  AND BSU_ID = @strBsuID
			END
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspEditApplication]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditApplication]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditApplication]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAppID           CHAR(6)
   ,@strAppCD			VARCHAR(8) = NULL
   ,@strAppName         VARCHAR(255) = NULL
   ,@strAppNameLong		VARCHAR(255) = NULL
   ,@strCategory        VARCHAR(255) = NULL
   ,@strBusiUserID      VARCHAR(20) = NULL	
   ,@strTechUserID      VARCHAR(20) = NULL
   ,@strAppSubDir       VARCHAR(500) = NULL
   ,@strAppDesc			VARCHAR(255) = NULL
   ,@dteCreate			DATETIME = NULL
   ,@dteDecom			DATETIME = NULL

AS	
--- Define Variables
    DECLARE @strCatID CHAR(5)
        
    SET NOCOUNT ON

--- Get the Category ID if needed
	IF @strCategory IS NOT NULL AND @strCategory <> ''''
		EXEC dbo.uspAddCategory @strCategory, @strCatID OUTPUT
		
--- If Application ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY020 APP WHERE APP.APP_ID = @strAppID) = 1
		BEGIN
		-- IF Application code supplied is not in use or if supplied, hasn''t changed continue
		IF (SELECT COUNT(1) FROM dbo.tblGTY020 WHERE APP_CD = @strAppCD AND APP_ID <> @strAppID) = 0 
			-- Edit required details table
			BEGIN
				UPDATE dbo.tblGTY020
				SET    APP_CD = 
								CASE WHEN @strAppCD IS NOT NULL AND @strAppCD <> ''''
								  THEN @strAppCD
								  ELSE APP_CD
								END
					  ,APP_NME = 
								CASE WHEN @strAppName IS NOT NULL AND @strAppName <> ''''
								  THEN @strAppName
								  ELSE APP_NME
								END
					  ,CAT_ID = 
								CASE WHEN @strCategory IS NOT NULL AND @strCategory <> ''''
								  THEN @strCatID
								  ELSE CAT_ID
								END
					  ,APP_BUS_USR_ID = 
								CASE WHEN @strBusiUserID IS NOT NULL AND @strBusiUserID <> ''''
								  THEN @strBusiUserID
								  ELSE APP_BUS_USR_ID
								END
					  ,APP_TCH_USR_ID = 
								CASE WHEN @strTechUserID IS NOT NULL AND @strTechUserID <> ''''
								  THEN @strTechUserID
								  ELSE APP_TCH_USR_ID
								END						
					  ,APP_SUB_FLD = 
								CASE WHEN @strAppSubDir IS NOT NULL AND @strAppSubDir <> ''''
								  THEN @strAppSubDir
								  ELSE APP_SUB_FLD
								END
					  ,APP_FROM_DT = 
								CASE WHEN @dteCreate IS NOT NULL AND @dteCreate <> ''''
								  THEN @dteCreate
								  ELSE APP_FROM_DT
								END
					  ,APP_TO_DT = 
								CASE WHEN @dteDecom IS NOT NULL AND @dteDecom <> ''''
								  THEN @dteDecom
								  ELSE APP_TO_DT
								END
					  ,APP_DESC = 
								CASE WHEN @strAppDesc IS NOT NULL AND @strAppDesc <> ''''
								  THEN @strAppDesc
								  ELSE APP_DESC
								END
					  ,APP_NME_LNG = 
								CASE WHEN @strAppNameLong IS NOT NULL AND @strAppNameLong <> ''''
								  THEN @strAppNameLong
								  ELSE ''''
								END
				WHERE  APP_ID = @strAppID
					
				SET @strReturnCode = ''EDITED''
			END
		ELSE
			BEGIN
				SET @strReturnCode = ''ERROR (APPLICATION CODE ALREADY EXISTS)''
			END
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = ''ERROR (RECORD NOT FOUND)''
        END 
--
' 
END
GO
/****** Object:  Table [dbo].[tblGTY070]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY070]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY070](
	[AI_ID] [char](8) NOT NULL,
	[AE_ID] [char](8) NOT NULL,
	[AI_VER_MAJ] [char](2) NOT NULL,
	[AI_VER_MIN] [char](2) NOT NULL,
	[AI_VER_REV] [char](2) NOT NULL,
	[AI_VER_CMT] [varchar](255) NULL,
	[AI_STS] [tinyint] NOT NULL,
	[AI_CRT_DT] [datetime] NOT NULL,
	[AI_SSD_DT] [datetime] NULL,
 CONSTRAINT [PK_GTY070] PRIMARY KEY CLUSTERED 
(
	[AI_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],
 CONSTRAINT [UQ_AE_VER] UNIQUE NONCLUSTERED 
(
	[AE_ID] ASC,
	[AI_VER_MAJ] ASC,
	[AI_VER_MIN] ASC,
	[AI_VER_REV] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppEnvironment]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppEnvironment]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddAppEnvironment] 
    @strAppID VARCHAR(8)
   ,@strEnvID CHAR(5)
   ,@strAppEnvID CHAR(8) OUTPUT
AS
   
    SET NOCOUNT ON
        
--- If application environment doesn''t exist, then create and retrieve ID
    IF (SELECT COUNT(1) FROM dbo.tblGTY030 AEV WHERE AEV.APP_ID = @strAppID AND AEV.ENV_ID = @strEnvID) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''AEV'', @strAppEnvID OUTPUT
            
            INSERT INTO dbo.tblGTY030
            VALUES
            (
              @strAppEnvID
             ,@strAppID
             ,@strEnvID
            )
        END
    ELSE
        BEGIN
            SET @strAppEnvID = (SELECT AEV.AE_ID FROM dbo.tblGTY030 AEV WHERE AEV.APP_ID = @strAppID AND AEV.ENV_ID = @strEnvID) 
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspAddApplication]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddApplication]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddApplication]
    @strAppCD           VARCHAR(8)
   ,@strAppName         VARCHAR(255)
   ,@strAppNameLong		VARCHAR(255) = NULL
   ,@strCategory        VARCHAR(255)
   ,@strBusiUserID      VARCHAR(20)
   ,@strTechUserID      VARCHAR(20)
   ,@strAppSubDir       VARCHAR(500)
   ,@strAppDesc			VARCHAR(255)
   ,@strAppID			VARCHAR(10) OUTPUT
AS
--- Define Variables
    DECLARE @strCatID CHAR(5)
    DECLARE @strAppEnvID CHAR(8)
    DECLARE @strEnvID CHAR(5)
    
    SET NOCOUNT ON
    
--- Run usp for Category that will add if it does not exist and return the ID
    EXEC dbo.uspAddCategory @strCategory, @strCatID OUTPUT

--- If Application number isn''t in use then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY020 WHERE APP_CD = @strAppCD) = 0
        -- Insert into Table
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''APP'', @strAppID OUTPUT
			
			-- Insert new Application details
            INSERT INTO dbo.tblGTY020
            VALUES
            (
			  @strAppID
             ,@strAppCD
             ,@strAppName
             ,@strCatID
             ,@strBusiUserID
             ,@strTechUserID
             ,@strAppSubDir
             ,@strAppDesc
             ,GETDATE()
             ,NULL
			 ,@strAppNameLong
            )
          
            -- Assign all environments to the application
			DECLARE curEnv CURSOR
				FOR 
				SELECT ENV_ID
				FROM   dbo.tblGTY040
				
			OPEN curEnv
				FETCH curEnv INTO @strEnvID

				WHILE @@FETCH_STATUS <> -1
					BEGIN
						EXEC dbo.uspSYSKeySequence ''AEV'', @strAppEnvID OUTPUT
						
						INSERT INTO dbo.tblGTY030
						VALUES
						(
						  @strAppEnvID
						 ,@strAppID
						 ,@strEnvID
					    )
						FETCH curEnv INTO @strEnvID
					END
			CLOSE curEnv
			DEALLOCATE curEnv
        END    
    ELSE
        BEGIN
            SET @strAppID = (SELECT APP_ID FROM dbo.tblGTY020 WHERE APP_CD = @strAppCD) 
        END 
--
' 
END
GO
/****** Object:  View [dbo].[vwAppEnvironments]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppEnvironments]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppEnvironments]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY030
--
'
GO
/****** Object:  View [dbo].[vwGateway]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwGateway]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwGateway]

AS

--- Get application details
	SELECT DISTINCT 
	       APP.APP_ID
		  ,APP.APP_CD
		  ,APP.APP_NME
		  ,APP.APP_NME_LNG
		  ,BUS_USR.USR_FNME + '' '' + BUS_USR.USR_SNME AS BUS_NME
		  ,TCH_USR.USR_FNME + '' '' + TCH_USR.USR_SNME AS TCH_NME
		  ,''IFS Business Solutions'' AS APP_BUS_NME
		  ,APP.APP_DESC
		  ,ENV.ENV_ID
		  ,AEV.AE_ID
		  ,API.AI_ID
		  ,(API.AI_VER_MAJ + ''.'' + API.AI_VER_MIN + ''.'' + API.AI_VER_REV) AS [VERSION]
		  ,ENV.ENV_NME AS [ENVIRONMENT]
		  ,ENV.ENV_PTH + APP.APP_SUB_FLD AS PATH
		  ,APE.USR_ID AS [USER]
		  ,ACT_USR.USR_FNME + '' '' + ACT_USR.USR_SNME AS [USERS_NAME]
		  ,APE.AE_USR_ACT
		  ,CASE 
			 WHEN API.AI_STS = 1 AND ENV.ENV_ACT = 1 AND APE.AE_USR_ACT = 1 THEN ''G''
			 WHEN API.AI_STS in(2,3) AND ENV.ENV_ACT = 1 AND APE.AE_USR_ACT = 1 THEN ''A''
			 ElSE ''R''
		   END AS [USR_RAG]
		  ,CASE 
			 WHEN API.AI_STS = 1 AND ENV.ENV_ACT = 1 THEN ''G''
			 WHEN API.AI_STS in(2,3) AND ENV.ENV_ACT = 1 THEN ''A''
			 ElSE ''R''
		   END AS [RAG]
		  ,API.AI_SSD_DT AS [SUPERSEEDED_DATE]
		  ,ENV.ENV_PTH + APP.APP_SUB_FLD + UG.FLE_PTH + UG.FLE_NME AS [USER_GUIDE_PATH]
	FROM   dbo.tblGTY020 AS APP INNER JOIN	
		   dbo.tblGTY030 AS AEV ON APP.APP_ID = AEV.APP_ID INNER JOIN
		   dbo.tblGTY040 AS ENV ON AEV.ENV_ID = ENV.ENV_ID INNER JOIN
		   dbo.tblGTY050 AS APE ON AEV.AE_ID = APE.AE_ID INNER JOIN
	 	   dbo.tblGTY060 AS TCH_USR ON APP.APP_TCH_USR_ID = TCH_USR.USR_ID INNER JOIN
		   dbo.tblGTY060 AS BUS_USR ON APP.APP_BUS_USR_ID = BUS_USR.USR_ID INNER JOIN
		   dbo.tblGTY060 AS ACT_USR ON APE.USR_ID = ACT_USR.USR_ID INNER JOIN
	 	   dbo.tblGTY070 AS API ON AEV.AE_ID = API.AE_ID LEFT JOIN
	 	   (SELECT AFL.* FROM dbo.tblGTY090 AS AFL WHERE FLE_GRP_ID = ''FGP02'' AND FLE_DESC = ''User Guide'') AS UG ON AEV.AE_ID = UG.AE_ID 
--
'
GO
/****** Object:  View [dbo].[vwAppPermissions]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppPermissions]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppPermissions]

AS

--- Direct Select of table
	SELECT PER_ID
		  ,AE_ID
		  ,USR_ID
		  ,AE_USR_ACT
		  ,CONVERT(DATETIME, LST_CPY, 120) AS LST_CPY
		  ,CONVERT(DATETIME, LST_LOG_IN, 120) AS LST_LOG_IN
		  ,CONVERT(DATETIME, LST_LOG_OUT, 120) AS LST_LOG_OUT
		  ,CUR_ATN
		  ,PID
		  ,FAV
	FROM   dbo.tblGTY050
--
'
GO
/****** Object:  View [dbo].[vwAppIteration]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppIteration]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppIteration]

AS

--- Direct Select of table
	SELECT AI_ID
		  ,AE_ID
		  ,AI_VER_MAJ
		  ,AI_VER_MIN
		  ,AI_VER_REV
		  ,AI_VER_CMT
		  ,AI_STS
		  ,CONVERT(DATETIME, AI_CRT_DT, 120) AS AI_CRT_DT
		  ,CONVERT(DATETIME, AI_SSD_DT, 120) AS AI_SSD_DT
	FROM   dbo.tblGTY070
--
'
GO
/****** Object:  View [dbo].[vwAppFileList]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppFileList]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAppFileList]

AS	

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY090
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppPermissions]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppPermissions]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddAppPermissions]
    @strAppEnvID	    VARCHAR(255)
   ,@strUserID	        VARCHAR(20)
   ,@strPerID			CHAR(8) OUTPUT
AS
    
    SET NOCOUNT ON

--- If Application Permission doesn''t exist, then continue
    IF (SELECT COUNT(1) FROM tblGTY050 APE WHERE APE.AE_ID = @strAppEnvID AND APE.USR_ID = @strUserID) = 0
        BEGIN
            -- Generate a new ID            
            EXEC dbo.uspSYSKeySequence ''APE'', @strPerID OUTPUT
            
            INSERT INTO dbo.tblGTY050
            VALUES
            (
			  @strPerID
             ,@strAppEnvID
             ,@strUserID
             ,1
             ,NULL
             ,NULL
             ,NULL
             ,0
             ,''''
             ,0
            )
        END
    ELSE
        BEGIN
			UPDATE dbo.tblGTY050 
			SET    AE_USR_ACT = 1
			WHERE  USR_ID = @strUserID 
			  AND  AE_ID = @strAppEnvID
            SET @strPerID = (SELECT APE.PER_ID FROM tblGTY050 APE WHERE APE.AE_ID = @strAppEnvID AND APE.USR_ID = @strUserID)
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppIteration]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppIteration]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddAppIteration] 
    @strAppEnvID CHAR(8)
   ,@strVerMaj CHAR(2)
   ,@strVerMin CHAR(2)
   ,@strVerRev CHAR(2)
   ,@strComment VARCHAR(255)
   ,@strAppIterID CHAR(8) OUTPUT
AS
	
    SET NOCOUNT ON
        
--- If Application Iteration doesn''t exists, then add and retrieve the ID
    IF (SELECT COUNT(1) 
		FROM   dbo.tblGTY070
		WHERE  AE_ID = @strAppEnvID 
		  AND  AI_VER_MAJ = @strVerMaj
		  AND  AI_VER_MIN = @strVerMin
		  AND  AI_VER_REV = @strVerRev) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''API'', @strAppIterID OUTPUT
            
            INSERT INTO dbo.tblGTY070
            VALUES
            (
              @strAppIterID
             ,@strAppEnvID
             ,@strVerMaj
             ,@strVerMin
             ,@strVerRev
             ,@strComment
             ,0
             ,GETDATE()
             ,NULL
            )
        END
    ELSE
        BEGIN
            SET @strAppIterID = (SELECT AI_ID 
								 FROM   dbo.tblGTY070 
								 WHERE  AE_ID = @strAppEnvID 
							 	   AND  AI_VER_MAJ = @strVerMaj 
							 	   AND  AI_VER_MIN = @strVerMin
							  	   AND  AI_VER_REV = @strVerRev)
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspAddAppEnvFile]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspAddAppEnvFile]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspAddAppEnvFile]
    @AppEnvID           CHAR(8)	
   ,@strFilePath        VARCHAR(255)
   ,@strFileName		VARCHAR(255)
   ,@strFileDesc        VARCHAR(255)
   ,@strProgramID       CHAR(5)
   ,@strFileGrpID		CHAR(5)
   ,@strAppEnvFileID	CHAR(8) OUTPUT
AS
    SET NOCOUNT ON

--- If file hasn''t already been added, then add and retrieve ID
    IF (SELECT COUNT(1) FROM dbo.tblGTY090 AEF WHERE AEF.AE_ID = @AppEnvID AND AEF.FLE_PTH = @strFilePath AND AEF.FLE_NME = @strFileName) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence ''AEF'', @strAppEnvFileID OUTPUT
            
            INSERT INTO dbo.tblGTY090
            VALUES
            (
              @strAppEnvFileID
             ,@AppEnvID
             ,@strFilePath
             ,@strFileName
             ,@strFileDesc
             ,@strFileGrpID
             ,@strProgramID
            )
        END
    ELSE
        BEGIN
            SET @strAppEnvFileID = (SELECT AEF.APP_FLE_ID FROM dbo.tblGTY090 AEF WHERE AEF.AE_ID = @AppEnvID AND AEF.FLE_PTH = @strFilePath AND AEF.FLE_NME = @strFileName) 
        END
--
' 
END
GO
/****** Object:  Table [dbo].[tblGTY920]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY920]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY920](
	[EL_ID] [char](11) NOT NULL,
	[AI_ID] [char](8) NOT NULL,
	[USR_ID] [varchar](30) NOT NULL,
	[EL_DT] [datetime] NOT NULL,
	[EL_CPT] [varchar](255) NOT NULL,
	[EL_FCT] [varchar](255) NOT NULL,
	[EL_ERR_NO] [int] NOT NULL,
	[EL_ERR_DESC] [varchar](8000) NOT NULL,
	[EL_ERR_LNE_NO] [int] NULL,
 CONSTRAINT [PK_GTY920] PRIMARY KEY CLUSTERED 
(
	[EL_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY910]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY910]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY910](
	[AL_ID] [char](11) NOT NULL,
	[AI_ID] [char](8) NOT NULL,
	[USR_ID] [varchar](30) NOT NULL,
	[AL_DT] [datetime] NOT NULL,
	[AL_CPT] [varchar](255) NOT NULL,
	[AL_MSG] [varchar](255) NOT NULL,
 CONSTRAINT [PK_GTY910] PRIMARY KEY CLUSTERED 
(
	[AL_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[tblGTY900]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY900]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[tblGTY900](
	[AA_ID] [char](11) NOT NULL,
	[AI_ID] [char](8) NOT NULL,
	[USR_ID] [varchar](30) NOT NULL,
	[LOG_IN] [datetime] NOT NULL,
	[LOG_OUT] [datetime] NULL,
	[LOG_OUT_MTH] [varchar](50) NULL,
	[MCE_ID] [varchar](7) NOT NULL,
 CONSTRAINT [PK_GTY900] PRIMARY KEY CLUSTERED 
(
	[AA_ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  StoredProcedure [dbo].[uspEditPID]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditPID]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditPID] 
    @strAppID CHAR(8)
   ,@strEnvID CHAR(5)
   ,@strUsrID VARCHAR(20)
   ,@intPID INTEGER
AS
   
    SET NOCOUNT ON
    DECLARE @strApeID CHAR(8)
        
--- If Category does NOT exists add a new category and then get ID
	SET @strApeID = (SELECT PER_ID
				     FROM dbo.tblGTY050 APE INNER JOIN dbo.tblGTY030 AEV ON APE.AE_ID = AEV.AE_ID 
				     WHERE AEV.APP_ID = @strAppID
				       AND AEV.ENV_ID= @strEnvID
				       AND APE.USR_ID= @strUsrID)
				  	  
    IF @strApeID IS NOT NULL
        BEGIN
            UPDATE dbo.tblGTY050
            SET	   PID = @intPID
			WHERE  PER_ID = @strApeID
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspEditIteration]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditIteration]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
CREATE PROCEDURE [dbo].[uspEditIteration]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAPIid           CHAR(8)
   ,@strVerMaj			CHAR(2) = NULL
   ,@strVerMin			CHAR(2) = NULL
   ,@strVerRev			CHAR(2) = NULL
   ,@strComment 		VARCHAR(255) = NULL
   ,@intStatusID		TINYINT = -1

AS	
--- Define Variables
    DECLARE @strAppEnvID CHAR(8)	
    
    SET NOCOUNT ON
		
--- If Iteration ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY070 WHERE AI_ID = @strAPIid) = 1
		BEGIN
			-- Update table with new values
			UPDATE dbo.tblGTY070
			SET    AI_VER_MAJ = 
						   CASE WHEN @strVerMaj IS NOT NULL AND @strVerMaj <> ''''
						     THEN @strVerMaj
							 ELSE AI_VER_MAJ
						   END
			      ,AI_VER_MIN = 
						   CASE WHEN @strVerMin IS NOT NULL AND @strVerMin <> ''''
						     THEN @strVerMin
							 ELSE AI_VER_MIN
						   END
			      ,AI_VER_REV = 
						   CASE WHEN @strVerRev IS NOT NULL AND @strVerRev <> ''''
						     THEN @strVerRev
							 ELSE AI_VER_REV
						   END
			      ,AI_VER_CMT = 
						   CASE WHEN @strComment IS NOT NULL AND @strComment <> ''''
						     THEN @strComment
							 ELSE AI_VER_CMT
						   END		
			      ,AI_STS = 
						   CASE WHEN @intStatusID IS NOT NULL AND @intStatusID <> -1
						     THEN @intStatusID
							 ELSE AI_STS
						   END
				  ,AI_SSD_DT =
						   CASE WHEN @intStatusID > 0
						     THEN NULL
							 ELSE AI_SSD_DT
						   END				   						
			WHERE  AI_ID = @strAPIid
			
			-- If this iteration has been activated, then all others for this app/env need to be disabled
			IF @intStatusID > 0
				BEGIN
					-- Get App/Env ID
					SET @strAppEnvID = (SELECT AE_ID FROM dbo.tblGTY070 WHERE AI_ID = @strAPIid)
					
					-- Change all other iterations for app/env to offline and make sure it has a superseeded date
					SET @strAppEnvID = (SELECT AE_ID FROM dbo.tblGTY070 WHERE AI_ID = @strAPIid)
					UPDATE dbo.tblGTY070
					SET    AI_STS = 0
						  ,AI_SSD_DT = GETDATE()
					
					WHERE  AE_ID = @strAppEnvID	
					  AND  AI_ID <> @strAPIid
                      AND  AI_SSD_DT IS NULL     -- Added on 16/01/2013 11:10
				END
			SET @strReturnCode = ''EDITED''
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = ''ERROR (RECORD NOT FOUND)''
        END 
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspEditFileList]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditFileList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditFileList]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAppFileID       CHAR(8)
   ,@strFilePath        VARCHAR(500) = NULL
   ,@strFileName        VARCHAR(255) = NULL
   ,@strFileDesc		VARCHAR(255) = NULL
   ,@strFileGrpID		CHAR(5) = NULL
   ,@strProgramID		CHAR(5) = NULL

AS	
--- Define Variables
    DECLARE @strAppEnvID CHAR(8)	
    
    SET NOCOUNT ON
		
--- If Iteration ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY090 WHERE APP_FLE_ID = @strAppFileID) = 1
		BEGIN
			-- Update table with new values
			UPDATE dbo.tblGTY090
			SET    FLE_PTH = 
						   CASE WHEN @strFilePath IS NOT NULL AND @strFilePath <> ''''
						     THEN @strFilePath
							 ELSE FLE_PTH
						   END			   						
			      ,FLE_NME = 
						   CASE WHEN @strFileName IS NOT NULL AND @strFileName <> ''''
						     THEN @strFileName
							 ELSE FLE_NME
						   END	
			      ,FLE_DESC = 
						   CASE WHEN @strFileDesc IS NOT NULL AND @strFileDesc <> ''''
						     THEN @strFileDesc
							 ELSE FLE_DESC
						   END	
			      ,FLE_GRP_ID = 
						   CASE WHEN @strFileGrpID IS NOT NULL AND @strFileGrpID <> ''''
						     THEN @strFileGrpID
							 ELSE FLE_GRP_ID
						   END	
			      ,PRG_ID = 
						   CASE WHEN @strProgramID IS NOT NULL AND @strProgramID <> ''''
						     THEN @strProgramID
							 ELSE PRG_ID
						   END
			WHERE  APP_FLE_ID = @strAppFileID

			SET @strReturnCode = ''EDITED''
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = ''ERROR (RECORD NOT FOUND)''
        END 
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspDelAppFiles]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspDelAppFiles]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspDelAppFiles] 
    @strReturnCode VARCHAR(10) OUTPUT
   ,@strAppFileID CHAR(8)
AS    
    SET NOCOUNT ON
    
--- If the App file exists, then delete it
    IF (SELECT COUNT(1) FROM dbo.tblGTY090 WHERE APP_FLE_ID = @strAppFileID) = 1
        BEGIN           
            DELETE
            FROM  dbo.tblGTY090
            WHERE APP_FLE_ID = @strAppFileID

            SET @strReturnCode = ''DELETED''
        END
    ELSE
        BEGIN
            SET @strReturnCode = ''DOES NOT EXISTS''
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspChangeFavourites]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspChangeFavourites]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspChangeFavourites]
    @AppEnvID	        VARCHAR(255)
   ,@strUserID	        VARCHAR(20)
   ,@bitFav				BIT
AS
    
    SET NOCOUNT ON

--- If Application Permission doesn''t exist, then continue
    IF (SELECT COUNT(1) FROM tblGTY050 APE WHERE APE.AE_ID = @AppEnvID AND APE.USR_ID = @strUserID) = 1
        BEGIN
			UPDATE dbo.tblGTY050 
			SET    FAV = @bitFav
			WHERE  USR_ID = @strUserID 
			  AND  AE_ID = @AppEnvID
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspLogCopyDateTime]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspLogCopyDateTime]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspLogCopyDateTime]
    @strAppID CHAR(8)
   ,@strEnvID CHAR(5)
   ,@strUsrID VARCHAR(20)
AS
   
    SET NOCOUNT ON
    DECLARE @strApeID CHAR(8)
        
--- If Category does NOT exists add a new category and then get ID
	SET @strApeID = (SELECT PER_ID
				     FROM dbo.tblGTY050 APE INNER JOIN dbo.tblGTY030 AEV ON APE.AE_ID = AEV.AE_ID 
				     WHERE AEV.APP_ID = @strAppID
				       AND AEV.ENV_ID= @strEnvID
				       AND APE.USR_ID= @strUsrID)
				  	  
    IF @strApeID IS NOT NULL
        BEGIN
            UPDATE dbo.tblGTY050
            SET	   LST_CPY = GETDATE()
			WHERE  PER_ID = @strApeID
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspEditCurrentAction]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspEditCurrentAction]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspEditCurrentAction] 
    @strAppID CHAR(8)
   ,@strEnvID CHAR(5)
   ,@strUsrID VARCHAR(20)
   ,@intCA INTEGER
AS
   
    SET NOCOUNT ON
    DECLARE @strApeID CHAR(8)
        
--- If Category does NOT exists add a new category and then get ID
	SET @strApeID  = (SELECT PER_ID
					  FROM dbo.tblGTY050 APE INNER JOIN dbo.tblGTY030 AEV ON APE.AE_ID = AEV.AE_ID 
					  WHERE AEV.APP_ID = @strAppID
					    AND AEV.ENV_ID= @strEnvID
					    AND APE.USR_ID= @strUsrID)
	PRINT @strApeID
    IF @strApeID IS NOT NULL
        BEGIN
            UPDATE dbo.tblGTY050
            SET	   CUR_ATN = @intCA
			WHERE  PER_ID = @strApeID
        END
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayExecuteAppCheck]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayExecuteAppCheck]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspGatewayExecuteAppCheck] 
    @strAppID CHAR(8)
   ,@strEnvID CHAR(5)
   ,@strUsrID VARCHAR(20)
AS
   
    SET NOCOUNT ON
    DECLARE @strApeID CHAR(8)
    
	SET @strApeID = (SELECT PER_ID
				     FROM dbo.tblGTY050 APE INNER JOIN dbo.tblGTY030 AEV ON APE.AE_ID = AEV.AE_ID 
				     WHERE AEV.APP_ID = @strAppID
				       AND AEV.ENV_ID = @strEnvID
				       AND APE.USR_ID = @strUsrID)
	
	IF (SELECT VAR_LNG FROM dbo.tblSYSVarGlobal WHERE VAR_NME = ''GTY_OVERRIDE'') = 1
		BEGIN
			SELECT ''YES'' AS [Result]
		END
	ELSE
		BEGIN
			IF @strApeID IS NOT NULL
				BEGIN
					SELECT CASE WHEN CUR_ATN = 2
							THEN ''YES''
							ELSE ''NO''
						   END AS [Result]
					FROM   dbo.tblGTY050
					WHERE  PER_ID = @strApeID
				END 
			ELSE
				BEGIN
					SELECT ''NO'' AS [Result]
				END 
		END

GRANT EXECUTE ON [dbo].[uspGatewayExecuteAppCheck] TO [sp_Exec]
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspReturnUserSpecificAppList]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnUserSpecificAppList]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspReturnUserSpecificAppList] 
    @strUserID VARCHAR(20)
   ,@strCatID CHAR(5) = NULL
   ,@strEnvID CHAR(5) = NULL
   ,@bitFavourites BIT = 0
AS
	
    SET NOCOUNT ON
        
--- BUILD SQL
	SELECT 
		   --APP.APP_CD AS [App Code]
		   APP.APP_NME AS [Application]
		  ,APP.APP_ID
		  ,ENV.ENV_ID
		  ,AEV.AE_ID
		  -- IF Statement if to use instead in access
		  -- IIF(API.AI_STS = 1 AND ENV.ENV_ACT = 1, ''G'', IIF((API.AI_STS = 2 OR API.AI_STS =3) AND ENV.ENV_ACT = 1,''A'', ''R''))
		  ,CASE 
			 WHEN API.AI_STS = 1 AND ENV.ENV_ACT = 1 THEN ''G''
			 WHEN API.AI_STS in(2,3) AND ENV.ENV_ACT = 1 THEN ''A''
			 ElSE ''R''
		   END AS [RAG]
		  
	FROM   dbo.tblGTY020 AS APP 
		   INNER JOIN dbo.tblGTY030 AS AEV ON APP.APP_ID = AEV.APP_ID 
		   INNER JOIN dbo.tblGTY040 AS ENV ON AEV.ENV_ID = ENV.ENV_ID 
		   INNER JOIN dbo.tblGTY050 AS APE ON AEV.AE_ID = APE.AE_ID 
		   INNER JOIN dbo.tblGTY070 AS API ON AEV.AE_ID = API.AE_ID 
		   INNER JOIN dbo.tblGTY110 AS CAT ON APP.CAT_ID = CAT.CAT_ID
		   
	WHERE  APE.AE_USR_ACT = 1
	  AND  API.AI_SSD_DT IS NULL
	  AND  APP.APP_TO_DT IS NULL
	  AND  APE.USR_ID = @strUserID
	  AND  (((APP.CAT_ID = @strCatID OR @strCatID IS NULL)
			  AND (ENV.ENV_ID = @strEnvID OR @strEnvID IS NULL)	
		      AND @bitFavourites = 0)
		    OR 
		    ((ENV.ENV_ID = @strEnvID
		      OR  @strEnvID IS NULL)
		     AND @bitFavourites = 1
		     AND APE.FAV = 1))
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspRemAppPermissions]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspRemAppPermissions]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspRemAppPermissions]
    @AppEnvID	        VARCHAR(255)
   ,@strUserID	        VARCHAR(20)
   ,@strReturnCode		VARCHAR(20) OUTPUT
AS
    DECLARE @strPerID CHAR(8)
    SET NOCOUNT ON
	
--- If Application Permission doesn''t exist, then continue
    IF (SELECT COUNT(1) FROM tblGTY050 APE WHERE APE.AE_ID = @AppEnvID AND APE.USR_ID = @strUserID) = 1
        BEGIN
			UPDATE dbo.tblGTY050 
			SET    AE_USR_ACT = 0
			WHERE  USR_ID = @strUserID
			  AND  AE_ID = @appEnvID 
			
			SET @strPerID = (SELECT PER_ID FROM tblGTY050 APE WHERE APE.AE_ID = @AppEnvID AND APE.USR_ID = @strUserID)
			SET @strReturnCode = @strPerID + '' has been disabled''
        END
    ELSE
        BEGIN
            SET @strReturnCode = ''ID NOT FOUND''
        END
--
' 
END
GO
/****** Object:  View [dbo].[vwAALog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAALog]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAALog]

AS

--- Direct Select of table
	SELECT AA_ID
		  ,AI_ID
		  ,USR_ID
		  ,CONVERT(DATETIME, LOG_IN, 120) AS LOG_IN
		  ,CONVERT(DATETIME, LOG_OUT, 120) AS LOG_OUT
		  ,LOG_OUT_MTH
		  ,MCE_ID
	FROM   dbo.tblGTY900
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspSetUserDefaultApps]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspSetUserDefaultApps]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'	/* 
SQL Statement for User Stored Procedure (Set user default application permission using business unit)
Author: James Williams
Date: 15/01/2013 15:16
*/

--
CREATE PROCEDURE [dbo].[uspSetUserDefaultApps]
	@strUsrID VARCHAR(20)
AS
    DECLARE @strAppEnvID CHAR(8)
    DECLARE @strRecCode VARCHAR(20)
    SET NOCOUNT ON

--- Remove all permissions for selected user
	DECLARE curAppEnv CURSOR
		FOR 
		SELECT APE.AE_ID
		FROM   dbo.tblGTY050 APE
		INNER JOIN dbo.tblGTY030 AEV ON ape.AE_ID = AEV.AE_ID
		WHERE  USR_ID = @strUsrID 
		  AND  AEV.APP_ID <> ''APP000''
		
	OPEN curAppEnv
		FETCH curAppEnv INTO @strAppEnvID

		WHILE @@FETCH_STATUS <> -1
			BEGIN
				EXEC uspRemAppPermissions @strAppEnvID,@strUsrID,@strRecCode

				FETCH curAppEnv INTO @strAppEnvID
			END
	CLOSE curAppEnv
	
	DEALLOCATE curAppEnv
	
--- Assign all default permissions for selected user
	DECLARE curAppEnv CURSOR
		FOR
		SELECT DISTINCT AEV.AE_ID
		FROM   dbo.tblGTY030 AS AEV INNER JOIN
               dbo.tblGTY010 AS ABR ON AEV.APP_ID = ABR.APP_ID INNER JOIN
               dbo.tblGTY120 AS BUR ON ABR.BSU_ID = BUR.BSU_ID
		WHERE  (BUR.USR_ID = @strUsrID 
				AND AEV.ENV_ID = ''ENV01'')
			   OR
			   (AEV.APP_ID = ''APP000'' 
			    AND AEV.ENV_ID = ''ENV01'')
		
	OPEN curAppEnv
		FETCH curAppEnv INTO @strAppEnvID

		WHILE @@FETCH_STATUS <> -1
			BEGIN
				EXEC uspAddAppPermissions @strAppEnvID,@strUsrID,@strRecCode

				FETCH curAppEnv INTO @strAppEnvID
			END
	CLOSE curAppEnv
	
	DEALLOCATE curAppEnv
--
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayErrorLog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayErrorLog]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspGatewayErrorLog] 
    @strApiID CHAR(8)
   ,@strUsrID VARCHAR(20)
   ,@strComponent VARCHAR(255)
   ,@strFunction VARCHAR(255)
   ,@intErrNumber INTEGER
   ,@strErrDescription VARCHAR(8000)
   ,@intErrLineNumber INTEGER
AS
   
    SET NOCOUNT ON
    DECLARE @strERID CHAR(11)

	-- Get new AA key
	EXEC dbo.uspSYSKeySequence ''ERL'', @strERID OUTPUT
	
	INSERT INTO dbo.tblGTY920
		  (EL_ID
		  ,AI_ID
		  ,USR_ID
		  ,EL_DT
		  ,EL_CPT
		  ,EL_FCT
		  ,EL_ERR_NO
		  ,EL_ERR_DESC
		  ,EL_ERR_LNE_NO
		  )
	SELECT @strERID
		  ,@strApiID
		  ,@strUsrID
		  ,GETDATE()
		  ,@strComponent
		  ,@strFunction
		  ,@intErrNumber
		  ,@strErrDescription
		  ,@intErrLineNumber

--		
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayActiveDeactiveUsers]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayActiveDeactiveUsers]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
--
CREATE PROCEDURE [dbo].[uspGatewayActiveDeactiveUsers]
	@strReturnCode VARCHAR(20)
   ,@strUserID	VARCHAR(20)
   ,@bitActive	BIT
AS
    
    SET NOCOUNT ON

--- Activate or deactivate users
	UPDATE dbo.tblGTY060
	SET    USR_ACT = @bitActive
	WHERE  USR_ID = @strUserID
	
	IF @bitActive = 1
	    BEGIN
	        EXEC dbo.uspAddAppPermissions ''AEV00001'', @strUserID ,''IGNOREOUTPUT''
	    END
    ELSE
        BEGIN
	        EXEC dbo.uspRemAppPermissions ''AEV00001'', @strUserID ,''IGNOREOUTPUT''
	    END
--

' 
END
GO
/****** Object:  View [dbo].[vwERLog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwERLog]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwERLog]

AS

--- Direct Select of table
	SELECT EL_ID
		  ,AI_ID
		  ,USR_ID
		  ,CONVERT(DATETIME, EL_DT, 120) AS EL_DT
		  ,EL_CPT
		  ,EL_FCT
		  ,EL_ERR_NO
		  ,EL_ERR_DESC
		  ,EL_ERR_LNE_NO
	FROM   dbo.tblGTY920
--
'
GO
/****** Object:  View [dbo].[vwAULog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAULog]'))
EXEC dbo.sp_executesql @statement = N'--
CREATE VIEW [dbo].[vwAULog]

AS

--- Direct Select of table
	SELECT AL_ID
		  ,AI_ID
		  ,USR_ID
		  ,CONVERT(DATETIME, AL_DT, 120) AS AL_DT
		  ,AL_CPT
		  ,AL_MSG
	FROM   dbo.tblGTY910
--
'
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayUserLog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayUserLog]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspGatewayUserLog] 
    @strApiID CHAR(8)
   ,@strUsrID VARCHAR(20)
   ,@strComponent VARCHAR(255)
   ,@strMessage VARCHAR(255)
AS
   
    SET NOCOUNT ON
    DECLARE @strULID CHAR(11)

	-- Get new AA key
	EXEC dbo.uspSYSKeySequence ''AUL'', @strULID OUTPUT
	
	INSERT INTO dbo.tblGTY910
		  (AL_ID
		  ,AI_ID
		  ,USR_ID
		  ,AL_DT
		  ,AL_CPT
		  ,AL_MSG
		  )
	SELECT @strULID
		  ,@strApiID
		  ,@strUsrID
		  ,GETDATE()
		  ,@strComponent
		  ,@strMessage

--		
' 
END
GO
/****** Object:  StoredProcedure [dbo].[uspGatewayLogInOut]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGatewayLogInOut]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'--
CREATE PROCEDURE [dbo].[uspGatewayLogInOut] 
    @strAppID CHAR(8)
   ,@strEnvID CHAR(5)
   ,@strApiID CHAR(8)
   ,@strUsrID VARCHAR(20)
   ,@intPID INTEGER
   ,@strMachineID VARCHAR(7)
   ,@bitLogIn BIT
AS
   
    SET NOCOUNT ON
    DECLARE @strApeID CHAR(8)
    DECLARE @strAAID CHAR(11)
    
--- Get IDs needed for following process
	SET @strApeID = (SELECT PER_ID
				     FROM dbo.tblGTY050 APE INNER JOIN dbo.tblGTY030 AEV ON APE.AE_ID = AEV.AE_ID 
				     WHERE AEV.APP_ID = @strAppID
				       AND AEV.ENV_ID= @strEnvID
				       AND APE.USR_ID= @strUsrID)

    IF @strApeID IS NOT NULL
		BEGIN
			IF @bitLogIn = 1
				BEGIN
					-- Update Permission table with details
					UPDATE dbo.tblGTY050
					SET	   CUR_ATN = 3
						  ,PID = @intPID
						  ,LST_LOG_IN = GETDATE()		
					WHERE  PER_ID = @strApeID
					
					-- Get new AA key
					EXEC dbo.uspSYSKeySequence ''AAL'', @strAAID OUTPUT
					
					-- Update any entries that do not have a log out method
					UPDATE tblGTY900
					SET    LOG_OUT = GETDATE()
						  ,LOG_OUT_MTH = ''UNKNOWN''
					WHERE  AI_ID = @strApiID
					  AND  USR_ID = @strUsrID
					  AND  LOG_OUT IS NULL
					  
					-- Now insert the new log in details
					INSERT INTO tblGTY900
						 ( AA_ID
						  ,AI_ID
						  ,USR_ID
						  ,LOG_IN
						  ,MCE_ID )
					SELECT @strAAID
						  ,@strApiID
						  ,UPPER(@strUsrID)
						  ,GETDATE()
					      ,@strMachineID
					      
					-- Log In Finished
				END 
			ELSE
				BEGIN
					-- Update Permission table with details
					UPDATE dbo.tblGTY050
					SET	   CUR_ATN = 0
						  ,PID = @intPID
						  ,LST_LOG_OUT = GETDATE()		
					WHERE  PER_ID = @strApeID
					
					-- Get existing AA ID
					SET @strAAID = (SELECT AA_ID FROM dbo.tblGTY900 WHERE AI_ID = @strApiID AND USR_ID = @strUsrID AND LOG_OUT IS NULL)
					
					-- Update the existing Log
					IF @strAAID IS NOT NULL
						BEGIN	
							UPDATE tblGTY900
							SET    LOG_OUT = GETDATE()
								  ,LOG_OUT_MTH = ''APP_EXIT''
							WHERE  AA_ID = @strAAID
						END
						
					-- Log Out Finished
				END 
		END
--		
' 
END
GO
/****** Object:  View [dbo].[vwSUPErrorLog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwSUPErrorLog]'))
EXEC dbo.sp_executesql @statement = N'CREATE VIEW [dbo].[vwSUPErrorLog] AS 

SELECT ER.EL_ID AS ErrorSID
      ,CONVERT(VARCHAR(30), ER.EL_DT, 121) AS ErrDate
      ,APP.APP_NME AS AppName
	  ,AEV.ENV_ID AS EnvID
      ,ENV.ENV_NME AS EnvName
	  ,(API.AI_VER_MAJ + ''.'' + API.AI_VER_MIN +  ''.'' + API.AI_VER_REV) AS AppVersion
	  ,ER.USR_ID AS UserID
      ,USR.USR_FNME + '' '' + USR.USR_SNME AS UserName
      ,ER.EL_CPT AS ErrComponent
      ,ER.EL_FCT AS ErrFunction
      ,ER.EL_ERR_NO AS ErrNumber
      ,ER.EL_ERR_DESC AS ErrDescription
      ,ER.EL_ERR_LNE_NO AS ErrLineNo 
	  
FROM  dbo.vwERLog ER
      INNER JOIN dbo.vwAppIteration API ON ER.AI_ID = API.AI_ID 
      INNER JOIN dbo.vwAppEnvironments AEV ON AEV.AE_ID = API.AE_ID
      INNER JOIN dbo.vwEnvironments ENV ON AEV.ENV_ID = ENV.ENV_ID
      INNER JOIN dbo.vwApplications APP ON APP.APP_ID = AEV.APP_ID
      INNER JOIN dbo.vwUsers USR ON ER.USR_ID = USR.USR_ID'
GO
/****** Object:  View [dbo].[vwSUPActivityLog]    Script Date: 07/19/2016 14:43:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwSUPActivityLog]'))
EXEC dbo.sp_executesql @statement = N'
CREATE VIEW [dbo].[vwSUPActivityLog] AS

SELECT APP.APP_NME AS [Application]
      ,ENV.ENV_NME [Environment]
      ,U.USR_FNME + '' '' + U.USR_SNME AS [User]
      ,L.* 

FROM  dbo.vwAALog L 
      INNER JOIN dbo.vwUsers U ON L.USR_ID = U.USR_ID
      INNER JOIN dbo.vwAppIteration API ON L.AI_ID = API.AI_ID
      INNER JOIN dbo.vwAppEnvironments AEV ON AEV.AE_ID = API.AE_ID
      INNER JOIN dbo.vwApplications APP ON App.APP_ID = AEV.APP_ID
      INNER JOIN dbo.vwEnvironments ENV ON ENV.ENV_ID = AEV.ENV_ID

'
GO
/****** Object:  ForeignKey [FK_GTY020To060_1]    Script Date: 07/19/2016 14:43:40 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_1]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020]  WITH CHECK ADD  CONSTRAINT [FK_GTY020To060_1] FOREIGN KEY([APP_BUS_USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_1]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] CHECK CONSTRAINT [FK_GTY020To060_1]
GO
/****** Object:  ForeignKey [FK_GTY020To060_2]    Script Date: 07/19/2016 14:43:40 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_2]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020]  WITH CHECK ADD  CONSTRAINT [FK_GTY020To060_2] FOREIGN KEY([APP_TCH_USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To060_2]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] CHECK CONSTRAINT [FK_GTY020To060_2]
GO
/****** Object:  ForeignKey [FK_GTY020To110]    Script Date: 07/19/2016 14:43:40 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To110]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020]  WITH CHECK ADD  CONSTRAINT [FK_GTY020To110] FOREIGN KEY([CAT_ID])
REFERENCES [dbo].[tblGTY110] ([CAT_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY020To110]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY020]'))
ALTER TABLE [dbo].[tblGTY020] CHECK CONSTRAINT [FK_GTY020To110]
GO
/****** Object:  ForeignKey [FK_GTY120To060]    Script Date: 07/19/2016 14:43:41 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120]  WITH CHECK ADD  CONSTRAINT [FK_GTY120To060] FOREIGN KEY([USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120] CHECK CONSTRAINT [FK_GTY120To060]
GO
/****** Object:  ForeignKey [FK_GTY120To080]    Script Date: 07/19/2016 14:43:41 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120]  WITH CHECK ADD  CONSTRAINT [FK_GTY120To080] FOREIGN KEY([BSU_ID])
REFERENCES [dbo].[tblGTY080] ([BSU_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY120To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY120]'))
ALTER TABLE [dbo].[tblGTY120] CHECK CONSTRAINT [FK_GTY120To080]
GO
/****** Object:  ForeignKey [FK_GTY030To020]    Script Date: 07/19/2016 14:43:41 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030]  WITH CHECK ADD  CONSTRAINT [FK_GTY030To020] FOREIGN KEY([APP_ID])
REFERENCES [dbo].[tblGTY020] ([APP_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030] CHECK CONSTRAINT [FK_GTY030To020]
GO
/****** Object:  ForeignKey [FK_GTY030To040]    Script Date: 07/19/2016 14:43:41 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To040]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030]  WITH CHECK ADD  CONSTRAINT [FK_GTY030To040] FOREIGN KEY([ENV_ID])
REFERENCES [dbo].[tblGTY040] ([ENV_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY030To040]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY030]'))
ALTER TABLE [dbo].[tblGTY030] CHECK CONSTRAINT [FK_GTY030To040]
GO
/****** Object:  ForeignKey [FK_GTY010To020]    Script Date: 07/19/2016 14:43:41 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010]  WITH CHECK ADD  CONSTRAINT [FK_GTY010To020] FOREIGN KEY([APP_ID])
REFERENCES [dbo].[tblGTY020] ([APP_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To020]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010] CHECK CONSTRAINT [FK_GTY010To020]
GO
/****** Object:  ForeignKey [FK_GTY010To080]    Script Date: 07/19/2016 14:43:41 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010]  WITH CHECK ADD  CONSTRAINT [FK_GTY010To080] FOREIGN KEY([BSU_ID])
REFERENCES [dbo].[tblGTY080] ([BSU_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY010To080]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY010]'))
ALTER TABLE [dbo].[tblGTY010] CHECK CONSTRAINT [FK_GTY010To080]
GO
/****** Object:  ForeignKey [FK_GTY090To030]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090]  WITH CHECK ADD  CONSTRAINT [FK_GTY090To030] FOREIGN KEY([AE_ID])
REFERENCES [dbo].[tblGTY030] ([AE_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] CHECK CONSTRAINT [FK_GTY090To030]
GO
/****** Object:  ForeignKey [FK_GTY090To100]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To100]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090]  WITH CHECK ADD  CONSTRAINT [FK_GTY090To100] FOREIGN KEY([PRG_ID])
REFERENCES [dbo].[tblGTY100] ([PRG_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To100]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] CHECK CONSTRAINT [FK_GTY090To100]
GO
/****** Object:  ForeignKey [FK_GTY090To130]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To130]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090]  WITH CHECK ADD  CONSTRAINT [FK_GTY090To130] FOREIGN KEY([FLE_GRP_ID])
REFERENCES [dbo].[tblGTY130] ([FLE_GRP_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To130]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
ALTER TABLE [dbo].[tblGTY090] CHECK CONSTRAINT [FK_GTY090To130]
GO
/****** Object:  ForeignKey [FK_GTY050To030]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050]  WITH CHECK ADD  CONSTRAINT [FK_GTY050To030] FOREIGN KEY([AE_ID])
REFERENCES [dbo].[tblGTY030] ([AE_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050] CHECK CONSTRAINT [FK_GTY050To030]
GO
/****** Object:  ForeignKey [FK_GTY050To060]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050]  WITH CHECK ADD  CONSTRAINT [FK_GTY050To060] FOREIGN KEY([USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY050To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY050]'))
ALTER TABLE [dbo].[tblGTY050] CHECK CONSTRAINT [FK_GTY050To060]
GO
/****** Object:  ForeignKey [FK_GTY070To030]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY070To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY070]'))
ALTER TABLE [dbo].[tblGTY070]  WITH CHECK ADD  CONSTRAINT [FK_GTY070To030] FOREIGN KEY([AE_ID])
REFERENCES [dbo].[tblGTY030] ([AE_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY070To030]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY070]'))
ALTER TABLE [dbo].[tblGTY070] CHECK CONSTRAINT [FK_GTY070To030]
GO
/****** Object:  ForeignKey [FK_GTY920To060]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920]  WITH CHECK ADD  CONSTRAINT [FK_GTY920To060] FOREIGN KEY([USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920] CHECK CONSTRAINT [FK_GTY920To060]
GO
/****** Object:  ForeignKey [FK_GTY920To070]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920]  WITH CHECK ADD  CONSTRAINT [FK_GTY920To070] FOREIGN KEY([AI_ID])
REFERENCES [dbo].[tblGTY070] ([AI_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY920To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY920]'))
ALTER TABLE [dbo].[tblGTY920] CHECK CONSTRAINT [FK_GTY920To070]
GO
/****** Object:  ForeignKey [FK_GTY910To060]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910]  WITH CHECK ADD  CONSTRAINT [FK_GTY910To060] FOREIGN KEY([USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910] CHECK CONSTRAINT [FK_GTY910To060]
GO
/****** Object:  ForeignKey [FK_GTY910To070]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910]  WITH CHECK ADD  CONSTRAINT [FK_GTY910To070] FOREIGN KEY([AI_ID])
REFERENCES [dbo].[tblGTY070] ([AI_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY910To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY910]'))
ALTER TABLE [dbo].[tblGTY910] CHECK CONSTRAINT [FK_GTY910To070]
GO
/****** Object:  ForeignKey [FK_GTY900To060]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900]  WITH CHECK ADD  CONSTRAINT [FK_GTY900To060] FOREIGN KEY([USR_ID])
REFERENCES [dbo].[tblGTY060] ([USR_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To060]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900] CHECK CONSTRAINT [FK_GTY900To060]
GO
/****** Object:  ForeignKey [FK_GTY900To070]    Script Date: 07/19/2016 14:43:42 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900]  WITH CHECK ADD  CONSTRAINT [FK_GTY900To070] FOREIGN KEY([AI_ID])
REFERENCES [dbo].[tblGTY070] ([AI_ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY900To070]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY900]'))
ALTER TABLE [dbo].[tblGTY900] CHECK CONSTRAINT [FK_GTY900To070]
GO
