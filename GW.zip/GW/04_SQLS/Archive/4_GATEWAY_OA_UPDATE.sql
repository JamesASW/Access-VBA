/*
Title: OA Update for Gateway
Dev(s): James Williams (JW)
Creation Date: 2016-08-03 09:15



Index:
1. Table and Data changes
    1.1. DROP all obsolete tables
    1.2. Add New Field(s) to Environment Table and Update (tblGTY040)
    1.3. Add New Field(s) to Application Table and Update (tblGTY020)
    1.4. Delete all data and Add New Field(s) to File Table (tblGTY090)
    1.5. Add New File Storage Table (tblGTY140)
    1.6. Add Foreign key to STR_FLE_ID in tblGTY090 to tblGTY140
    1.7. Remove non-essential fields from User Table (tblGTY060)
    1.8. Update tblGTY070 iterations data
    1.9  Update File Groups (tblGTY130)
    1.10 Add FLE to dbo.tblSYSKeys
    1.11 Add Dev users
    1.12 Global Variables
    1.13 Alter tblGTY900 to change column length for Machine ID
	1.14 Add table for Active Directory list (tblGTY150)
	1.15 Add Log Control table (tblGTY930)
2. View changes
    2.1. vwGateway (Add in new fields needed by apps)
    2.2. vwUsers - Refresh due to table changes
    2.3. vwApplications - Refresh due to table changes
    2.4. vwEnvironments - Refresh due to table changes
    2.5. vwAppFileList - Refresh due to table changes
    2.6. vwAppExecutables - List of the executables for Gateway
    2.7. vwAppFileDownloadList - List of the files to download per app/env
    2.8. vwAppDevCopy - List of the Development Copies for Gateway
    2.9. vwGatewayFileList - File List for Gateway Launcher
	2.10 vwADGroups - Active Directory Groups
	2.11 vwLOGActivity - Activity Log
	2.12 vwLOGUser - User Log
	2.13 vwLOGError - Error Log
	2.14 vwLOGActiveUsersNowPerApp - Active Users Now Per App
	2.15 vwLOGActiveUsersPerDayPerApp - Number Users Per Day Per App
	2.16 vwLOGInActiveUsers - Inactive users
	2.17 vwLogControlTable - Log Control table
	2.18 vwADMNUsersGroups - Treeview output for User Groups unders Admin Users
	2.19 vwADMNUsers - Treeview output for Users unders Admin Users
3. Stored Procedure Changes
    3.1. Add new uspReturnAdminAppSetup (Returns selected apps setup details)
    3.2. Update uspAddApplication
    3.3. Update uspEditApplication
    3.4. Add new uspReturnAdminAppIterations (Returns selected apps iteration details)
    3.5. Add new uspReturnAdminAppIterationPRODandTEST (Returns selected apps iteration details for prod and test only)
    3.6. Update uspAddIteration
    3.7. Update uspEditIteration
    3.8. Add new uspReturnAdminAppIteration (Returns selected iteration detail)
    3.9. Update dbo.tblSYSKeySomething
    3.10.Add uspCleanUpFiles
    3.11.Add uspChangeAppGWIcon
    3.12.Add new uspReturnAdminAppFilesTreeview (Returns build for files treeview in admin)
    3.13 Add new uspReturnAdminAppSelectedFile (Returns details for selected ID)
    3.14 Alter uspDelAppFiles to include file store cleanup
    3.15. Update uspAddAppEnvFile
    3.16. Update uspEditFileList
    3.17. Update User Listing (uspGetUserPermissionsFromAD)
    3.18. Add new uspReturnAppEnvUserRAG (App/Env current RAG for user)... can user access app
    3.19. Add new uspReturnAppPromotionDetails to get promotion details ready
    3.20. Send Email
    3.21. Add new PromoteApplication 
    3.22. Alter procedure [uspGatewayLogInOut] to cover for length of machine ID changes   
	3.23. Add new uspReturnUserListForApp 
*/


USE [IFSLA_Gateway]
GO

---- 1. Table and Data changes
---------------------------------------------------------------------------------------------------------------------------
---- 1.1. DROP all obsolete tables
-------------------------------------------------------
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblBOFood]') AND type in (N'U'))
--        DROP TABLE dbo.tblBOFood -- Legacy
--    GO
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblBOOrder]') AND type in (N'U'))
--        DROP TABLE dbo.tblBOOrder -- Legacy
--    GO   
--    IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFood]'))
--        DROP VIEW dbo.vwFood -- Legacy
--    GO  
--    IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwFoodOrders]'))
--        DROP VIEW dbo.vwFoodOrders -- Legacy
--    GO    
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY010]') AND type in (N'U'))
--        DROP TABLE dbo.tblGTY010 -- Business Unit setup (obsolete)
--    GO     
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY120]') AND type in (N'U'))
--        DROP TABLE dbo.tblGTY120 -- Business Unit setup (obsolete)
--    GO  
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY080]') AND type in (N'U'))
--        DROP TABLE dbo.tblGTY080 -- Business Unit setup (obsolete)
--    GO   
-------------------------------------------------------

---- 1.2. Add New Field(s) to Environment Table (tblGTY040)
-------------------------------------------------------
--    IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY040' AND COLUMN_NAME = 'SRV_NME') 
--        ALTER TABLE dbo.tblGTY040
--            ADD SRV_NME VARCHAR(50) NULL
--        GO
--        UPDATE dbo.tblGTY040 SET SRV_NME = 'SQA-IFS-BSLA-DEV' WHERE ENV_ID = 'ENV03'
--        UPDATE dbo.tblGTY040 SET SRV_NME = 'SQA-IFS-BSLA-TST', ENV_PTH = 'N:\IFSLA\ENV02\' WHERE ENV_ID = 'ENV02'
--        UPDATE dbo.tblGTY040 SET SRV_NME = 'SQA-IFS-BSLA-PRD', ENV_PTH = 'N:\IFSLA\ENV01\' WHERE ENV_ID = 'ENV01'
--    GO
-------------------------------------------------------

---- 1.3. Add New Field(s) to Application Table (tblGTY020)
-------------------------------------------------------
--    IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY020' AND COLUMN_NAME = 'APP_DB_NME') 
--        ALTER TABLE dbo.tblGTY020
--            ADD APP_DB_NME VARCHAR(74) NULL
--        GO
--        ALTER TABLE dbo.tblGTY020
--            ADD ACD_GRP_NME VARCHAR(255) NULL
--        GO
--        UPDATE dbo.tblGTY020 SET APP_DB_NME = 'IFSLA_GATEWAY' WHERE APP_ID = 'APP000'
--    GO
-------------------------------------------------------

---- 1.4. Delete all data and Add New Field(s) to File Table (tblGTY090)
-------------------------------------------------------
--    TRUNCATE TABLE dbo.tblGTY090
--    GO
--    IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY090' AND COLUMN_NAME = 'STR_FLE_ID') 
--        ALTER TABLE dbo.tblGTY090
--            ADD STR_FLE_ID CHAR(8) NULL
--    GO
-------------------------------------------------------

---- 1.5. Add New File Storage Table (tblGTY140)
-------------------------------------------------------
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY140]') AND type in (N'U'))
--        DROP TABLE dbo.tblGTY140 -- Legacy
--    GO
--    CREATE TABLE dbo.tblGTY140
--    (
--        STR_FLE_ID   CHAR(8)        NOT NULL
--       ,STR_FLE_DATA VARBINARY(MAX) NOT NULL
--    )
--    GO
--    ALTER TABLE dbo.tblGTY140 ADD CONSTRAINT
--	       PK_GTY0140 PRIMARY KEY (STR_FLE_ID) ON [PRIMARY]
--	GO
-------------------------------------------------------

---- 1.6. Add Foreign key to STR_FLE_ID in tblGTY090 to tblGTY140
-------------------------------------------------------
--    IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To140]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
--        ALTER TABLE dbo.tblGTY140  WITH CHECK ADD CONSTRAINT FK_GTY090To140 FOREIGN KEY(STR_FLE_ID)
--        REFERENCES dbo.tblGTY140 (STR_FLE_ID)
--    GO
--    IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_GTY090To140]') AND parent_object_id = OBJECT_ID(N'[dbo].[tblGTY090]'))
--        ALTER TABLE dbo.tblGTY140 CHECK CONSTRAINT FK_GTY900To140
--    GO
-------------------------------------------------------

---- 1.7. Remove non-essential fields from User Table (tblGTY060)
-------------------------------------------------------
--    IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY060' AND COLUMN_NAME = 'USR_TEL_NO') 
--        ALTER TABLE dbo.tblGTY060
--            DROP COLUMN USR_TEL_NO
--    GO
--    IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY060' AND COLUMN_NAME = 'USR_JOB_TTL') 
--        ALTER TABLE dbo.tblGTY060
--            DROP COLUMN USR_JOB_TTL
--    GO
--    IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY060' AND COLUMN_NAME = 'USR_PCL_NME')
--        ALTER TABLE dbo.tblGTY060
--            DROP COLUMN USR_PCL_NME
--    GO
--    IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE  TABLE_NAME = 'tblGTY060' AND COLUMN_NAME = 'USR_MGR_ID') 
--        ALTER TABLE dbo.tblGTY060
--            DROP COLUMN USR_MGR_ID
--    GO
-------------------------------------------------------

---- 1.8. Update tblGTY070 iterations data (COMMENT OUT AFTER 1st RUN OF DATA POP!!!)
-------------------------------------------------------
--    IF (SELECT COUNT(1) FROM dbo.tblGTY070 I INNER JOIN dbo.tblGTY030 AE1 ON AE1.AE_ID = I.AE_ID WHERE AE1.ENV_ID IN ('ENV01')) > 100 -- Quick random check to see if this has been run previously
--        BEGIN
--            -- Remove LOG data for DEV and Test
--            DELETE L
--            FROM   dbo.tblGTY900 L
--            INNER JOIN dbo.tblGTY070 G70 ON G70.AI_ID = L.AI_ID
--            INNER JOIN dbo.tblGTY030 AE1 ON AE1.AE_ID = G70.AE_ID
--            WHERE AE1.ENV_ID IN ('ENV02','ENV03')
            
--            DELETE L
--            FROM   dbo.tblGTY910 L
--            INNER JOIN dbo.tblGTY070 G70 ON G70.AI_ID = L.AI_ID
--            INNER JOIN dbo.tblGTY030 AE1 ON AE1.AE_ID = G70.AE_ID
--            WHERE AE1.ENV_ID IN ('ENV02','ENV03')
            
--            DELETE L
--            FROM   dbo.tblGTY920 L
--            INNER JOIN dbo.tblGTY070 G70 ON G70.AI_ID = L.AI_ID
--            INNER JOIN dbo.tblGTY030 AE1 ON AE1.AE_ID = G70.AE_ID
--            WHERE AE1.ENV_ID IN ('ENV02','ENV03')
            
--            -- Remove TEST and DEV
--            DELETE I
--            FROM dbo.tblGTY070 I
--            INNER JOIN dbo.tblGTY030 AE ON AE.AE_ID = I.AE_ID
--            WHERE AE.ENV_ID IN ('ENV02','ENV03')
            
--            -- Apply Prod to dev
--            INSERT INTO dbo.tblGTY070
--            SELECT 'API' + RIGHT('00000' + CONVERT(VARCHAR(50), (SELECT KEY_SEQ_NBR FROM dbo.tblSYSKey WHERE TBL_KEY_ID = 'API') + ROW_NUMBER() OVER(ORDER BY I.AE_ID)),5) AI_ID
--                  ,(SELECT AE_ID FROM dbo.tblGTY030 WHERE APP_ID = AE1.APP_ID AND ENV_ID = 'ENV03') AE_ID
--                  ,I.AI_VER_MAJ
--                  ,I.AI_VER_MIN
--                  ,I.AI_VER_REV
--                  ,I.AI_VER_CMT
--                  ,I.AI_STS
--                  ,I.AI_CRT_DT
--                  ,I.AI_SSD_DT
--            FROM   dbo.tblGTY070 I
--            INNER JOIN dbo.tblGTY030 AE1 ON AE1.AE_ID = I.AE_ID
--            WHERE AE1.ENV_ID IN ('ENV01')
            
--            -- Update key number
--            DECLARE @intTemp INTEGER
--            SET @intTemp = (SELECT MAX(CAST(RIGHT(AI_ID,5) AS INTEGER) + 1) FROM dbo.tblGTY070)
--            UPDATE dbo.tblSYSKey SET KEY_SEQ_NBR = @intTemp WHERE TBL_KEY_ID = 'API'
            
--            -- Delete Prod now for clean start
--            DELETE I
--            FROM dbo.tblGTY070 I
--            INNER JOIN dbo.tblGTY030 AE ON AE.AE_ID = I.AE_ID
--            WHERE AE.ENV_ID IN ('ENV01')
            
--            EXEC dbo.[uspAddAppIteration] 'AEV00054','01','00','00','OA Release version', ''
--            EXEC dbo.uspAddAppPermissions 'AEV00054','jl790',''
--        END
--    GO
-------------------------------------------------------

---- 1.9  Update File Groups (tblGTY130)
-------------------------------------------------------
--    UPDATE dbo.tblGTY130 SET FLE_GRP_NME = 'GW Icon' WHERE FLE_GRP_ID = 'FGP04'
--    UPDATE dbo.tblGTY130 SET FLE_GRP_NME = 'Development Copy', CPY_ACT = 0 WHERE FLE_GRP_ID = 'FGP01'
--    UPDATE dbo.tblGTY130 SET FLE_GRP_NME = 'User Guide', CPY_ACT = 1 WHERE FLE_GRP_ID = 'FGP02'
--    UPDATE dbo.tblGTY130 SET FLE_GRP_NME = 'Eexecutable', CPY_ACT = 1 WHERE FLE_GRP_ID = 'FGP00'
--    INSERT INTO dbo.tblGTY130 SELECT 'FGP05', 'Application file',1
--    INSERT INTO dbo.tblGTY130 SELECT 'FGP06', 'Documents',1
--    UPDATE dbo.tblSYSKey SET KEY_SEQ_NBR = 7 WHERE TBL_KEY_ID = 'FGP'
--    GO
-------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
---- 1.10 Add FLE to dbo.tblSYSKeys
-------------------------------------------------------
--    INSERT INTO dbo.tblSYSKey VALUES ('FLE','tblGTY120',5,0)
--    GO
-------------------------------------------------------

---- 1.11 Add Dev users
-------------------------------------------------------
--    EXEC [uspAddAppPermissions] 'AEV00003', 'HN590', ''
--    EXEC [uspAddAppPermissions] 'AEV00003', 'QM215', ''
--    EXEC [uspAddAppPermissions] 'AEV00003', 'BU730', ''
--    EXEC [uspAddAppPermissions] 'AEV00003', 'QD441', ''
--    EXEC [uspAddAppPermissions] 'AEV00003', 'MF989', ''
--    EXEC [uspAddAppPermissions] 'AEV00002', 'HN590', ''
--    EXEC [uspAddAppPermissions] 'AEV00002', 'QM215', ''
--    EXEC [uspAddAppPermissions] 'AEV00002', 'BU730', ''
--    EXEC [uspAddAppPermissions] 'AEV00002', 'QD441', ''
--    EXEC [uspAddAppPermissions] 'AEV00002', 'MF989', ''
--    GO
-------------------------------------------------------

---- 1.12 Global Variables
-------------------------------------------------------
--    DELETE FROM dbo.tblSYSVarGlobal
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'APP_OverrideKick','TXT','N'
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'GTY_API_ID','TXT','API00520'
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'GTY_APP_ID','TXT','APP000'
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'GTY_ENV_ID','TXT','ENV03'
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'SYS_DevLocation','TXT','\MISC\IFSLocalApps\'
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'SYS_LaunchLocation','TXT','N:\BSLA\'
--    INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP,VAR_TXT) SELECT 'GTY_OVERRIDE','LNG',0
--    GO
-------------------------------------------------------

---- 1.13 Alter tblGTY900 to change column length for Machine ID
-------------------------------------------------------
--    ALTER TABLE dbo.tblGTY900 
--    ALTER COLUMN MCE_ID VARCHAR(50) NOT NULL
--    GO
-------------------------------------------------------

---- 1.14 Add table for Active Directory list (tblGTY150)
-------------------------------------------------------
--    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY150]') AND type in (N'U'))
--        DROP TABLE dbo.tblGTY150
--    GO
--    CREATE TABLE dbo.tblGTY150
--    (
--		GRP_SID   INTEGER        NOT NULL
--       ,GRP_NME   VARCHAR(512)   NOT NULL
--	   ,CRT_DT	  DATETIME		 NOT NULL
--	   ,DEL_DT    DATETIME		 NULL
--    )
--    GO
--    ALTER TABLE dbo.tblGTY150 ADD CONSTRAINT
--	       PK_GTY0150 PRIMARY KEY (GRP_SID) ON [PRIMARY]
--	GO
--    ALTER TABLE dbo.tblGTY150 ADD CONSTRAINT
--	       UQ_GTY0150 UNIQUE (GRP_NME)
--	GO
-------------------------------------------------------

-- 1.15 Add Log Control table (tblGTY930)
-----------------------------------------------------
 --   IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tblGTY930]') AND type in (N'U'))
 --       DROP TABLE dbo.tblGTY930
 --   GO
 --   CREATE TABLE dbo.tblGTY930
 --   (
	--	LOG_SID   INTEGER        NOT NULL IDENTITY(1,1)
 --      ,LOG_NME   VARCHAR(512)   NOT NULL
	--   ,LOG_SQL	  VARCHAR(512)   NOT NULL
	--   ,CRT_DT	  DATETIME		 NOT NULL
	--   ,DEL_DT    DATETIME		 NULL
 --   )
 --   GO
 --   ALTER TABLE dbo.tblGTY930 ADD CONSTRAINT
	--       PK_GTY0930 PRIMARY KEY (LOG_SID) ON [PRIMARY]
	--GO
 --   ALTER TABLE dbo.tblGTY930 ADD CONSTRAINT
	--       UQ_GTY0930 UNIQUE (LOG_NME)
	--GO

	-- Default data
	--INSERT INTO dbo.tblGTY930 (LOG_NME, LOG_SQL, CRT_DT) VALUES ('Number of Active Users Now','SELECT * FROM dbo.vwLOGActiveUsersNowPerApp ORDER BY [No Active Users] DESC',GETDATE())
	--INSERT INTO dbo.tblGTY930 (LOG_NME, LOG_SQL, CRT_DT) VALUES ('Number of Active Users Per Day Per App','SELECT * FROM dbo.vwLOGActiveUsersPerDayPerApp ORDER BY [No Unique logins Users] DESC',GETDATE())
	--INSERT INTO dbo.tblGTY930 (LOG_NME, LOG_SQL, CRT_DT) VALUES ('Activity Log','SELECT * FROM dbo.vwLOGActivity ORDER BY AA_ID DESC',GETDATE())
	--INSERT INTO dbo.tblGTY930 (LOG_NME, LOG_SQL, CRT_DT) VALUES ('User Log','SELECT * FROM dbo.vwLOGUser ORDER BY AL_ID DESC',GETDATE())
	--INSERT INTO dbo.tblGTY930 (LOG_NME, LOG_SQL, CRT_DT) VALUES ('Error Log','SELECT * FROM dbo.vwLOGError ORDER BY [EL_ID] DESC',GETDATE())
	--INSERT INTO dbo.tblGTY930 (LOG_NME, LOG_SQL, CRT_DT) VALUES ('InActive Users','SELECT * FROM dbo.vwLOGInActiveUsers ORDER BY [USR_ID]',GETDATE())
-----------------------------------------------------

-- 2. View changes
-------------------------------------------------------------------------------------------------------------------------
-- 2.1. vwGateway (Add in new fields needed by apps)
-----------------------------------------------------
ALTER VIEW [dbo].[vwGateway]
AS
--- Get application details
	SELECT DISTINCT 
	       APP.APP_ID
		  ,APP.APP_CD
		  ,APP.APP_NME
		  ,APP.APP_NME_LNG
		  ,BUS_USR.USR_FNME + ' ' + BUS_USR.USR_SNME AS BUS_NME
		  ,TCH_USR.USR_FNME + ' ' + TCH_USR.USR_SNME AS TCH_NME
		  ,'IFS Business Solutions' AS APP_BUS_NME
		  ,APP.APP_DESC
		  ,ENV.ENV_ID
		  ,AEV.AE_ID
		  ,API.AI_ID
		  ,(API.AI_VER_MAJ + '.' + API.AI_VER_MIN + '.' + API.AI_VER_REV) AS [VERSION]
		  ,ENV.ENV_NME AS [ENVIRONMENT]
		  ,ENV.ENV_PTH + APP.APP_SUB_FLD AS PATH
		  ,APE.USR_ID AS [USER]
		  ,ACT_USR.USR_FNME + ' ' + ACT_USR.USR_SNME AS [USERS_NAME]
		  ,APE.AE_USR_ACT
		  ,CASE 
			 WHEN API.AI_STS = 1 AND ENV.ENV_ACT = 1 AND APE.AE_USR_ACT = 1 THEN 'G'
			 WHEN API.AI_STS in(2,3) AND ENV.ENV_ACT = 1 AND APE.AE_USR_ACT = 1 THEN 'A'
			 ElSE 'R'
		   END AS [USR_RAG]
		  ,CASE 
			 WHEN API.AI_STS = 1 AND ENV.ENV_ACT = 1 THEN 'G'
			 WHEN API.AI_STS in(2,3) AND ENV.ENV_ACT = 1 THEN 'A'
			 ElSE 'R'
		   END AS [RAG]
		  ,API.AI_SSD_DT AS [SUPERSEEDED_DATE]
		  ,ENV.ENV_PTH + APP.APP_SUB_FLD + UG.FLE_PTH + UG.FLE_NME AS [USER_GUIDE_PATH]
		  ,'ODBC;DRIVER={SQL Server};SERVER=' + ENV.SRV_NME + ';Trusted_Connection=Yes;' + 'DATABASE=' + APP.APP_DB_NME + ';APP=' + API.AI_ID + '_' + ACT_USR.USR_ID AS ConnectionStringObject
		  ,'Provider=SQLOLEDB.1;SERVER=' + ENV.SRV_NME + ';Trusted_Connection=Yes;' + 'DATABASE=' + APP.APP_DB_NME + ';APP=' + API.AI_ID + '_' + ACT_USR.USR_ID AS ConnectionStringADO
		  ,ENV.SRV_NME [ServerName]
		  ,APP.APP_DB_NME [DatabaseName]
		  ,API.AI_ID + '_' + ACT_USR.USR_ID [ConnectApplicationName]
	FROM   dbo.tblGTY020 AS APP INNER JOIN	
		   dbo.tblGTY030 AS AEV ON APP.APP_ID = AEV.APP_ID INNER JOIN
		   dbo.tblGTY040 AS ENV ON AEV.ENV_ID = ENV.ENV_ID INNER JOIN
		   dbo.tblGTY050 AS APE ON AEV.AE_ID = APE.AE_ID INNER JOIN
	 	   dbo.tblGTY060 AS TCH_USR ON APP.APP_TCH_USR_ID = TCH_USR.USR_ID INNER JOIN
		   dbo.tblGTY060 AS BUS_USR ON APP.APP_BUS_USR_ID = BUS_USR.USR_ID INNER JOIN
		   dbo.tblGTY060 AS ACT_USR ON APE.USR_ID = ACT_USR.USR_ID INNER JOIN
	 	   dbo.tblGTY070 AS API ON AEV.AE_ID = API.AE_ID LEFT JOIN
	 	   (SELECT AFL.* FROM dbo.tblGTY090 AS AFL WHERE FLE_GRP_ID = 'FGP02') AS UG ON AEV.AE_ID = UG.AE_ID     
--
GO
-----------------------------------------------------

-- 2.2. vwUsers - Refresh due to table changes
-----------------------------------------------------
ALTER VIEW [dbo].[vwUsers]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY060
--

GO
-----------------------------------------------------

-- 2.3. vwApplications - Refresh due to table changes
-----------------------------------------------------
ALTER VIEW [dbo].[vwApplications]

AS

--- Direct Select of table
	SELECT APP_ID
		  ,APP_CD
		  ,APP_NME
		  ,APP_NME_LNG
		  ,CAT_ID
		  ,APP_BUS_USR_ID
		  ,APP_TCH_USR_ID
		  ,APP_SUB_FLD
		  ,APP_DESC
		  ,a.APP_DB_NME
		  ,a.ACD_GRP_NME
		  ,CONVERT(DATETIME, APP_FROM_DT, 120) AS APP_FROM_DT
		  ,CONVERT(DATETIME, APP_TO_DT, 120) AS APP_TO_DT   
	FROM   dbo.tblGTY020 a
--

GO
-----------------------------------------------------

-- 2.4  vwEnvironments - Refresh due to table changes
-----------------------------------------------------
ALTER VIEW [dbo].[vwEnvironments]

AS

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY040
--

GO
-----------------------------------------------------

-- 2.5  vwAppFileList - Refresh due to table changes
-----------------------------------------------------
ALTER VIEW [dbo].[vwAppFileList]

AS	

--- Direct Select of table
	SELECT *
	FROM   dbo.tblGTY090
--

GO
-----------------------------------------------------

-- 2.6. vwAppExecutables - List of the executables for Gateway
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppExecutables]'))
DROP VIEW [dbo].vwAppExecutables
GO
CREATE VIEW dbo.vwAppExecutables
AS	

--- Get list of executables for each app/env
    SELECT A.APP_ID, E.ENV_ID, E.ENV_PTH + A.APP_SUB_FLD + FL.FLE_PTH +  FL.FLE_NME [Path], P.PRG_EXE
    FROM   dbo.vwApplications A 
    INNER JOIN dbo.vwAppEnvironments AE ON AE.APP_ID = A.APP_ID
    INNER JOIN dbo.vwEnvironments E ON E.ENV_ID = AE.ENV_ID
    INNER JOIN dbo.vwAppFileList FL ON FL.AE_ID = AE.AE_ID
    INNER JOIN dbo.vwPrograms P ON P.PRG_ID = FL.PRG_ID
    WHERE  FL.FLE_GRP_ID = 'FGP00'
GO
GRANT SELECT ON dbo.vwAppExecutables TO vw_Select
GO
-----------------------------------------------------

-- 2.7. vwAppFileDownloadList - List of the files to download per app/env
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppFileDownloadList]'))
DROP VIEW [dbo].vwAppFileDownloadList
GO
CREATE VIEW dbo.vwAppFileDownloadList
AS	

--- Get list of executables for each app/env
    SELECT DISTINCT A.APP_ID, E.ENV_ID, E.ENV_PTH + A.APP_SUB_FLD + FL.FLE_PTH + FL.FLE_NME [FilePath], FL.STR_FLE_ID, FG.FLE_GRP_ID
    FROM   dbo.vwApplications A 
    INNER JOIN dbo.vwAppEnvironments AE ON AE.APP_ID = A.APP_ID
    INNER JOIN dbo.vwEnvironments E ON E.ENV_ID = AE.ENV_ID
    INNER JOIN dbo.vwAppFileList FL ON FL.AE_ID = AE.AE_ID
    INNER JOIN dbo.vwFileGroups FG ON FG.FLE_GRP_ID = FL.FLE_GRP_ID
    WHERE FL.STR_FLE_ID IS NOT NULL AND FG.CPY_ACT = 1
GO
GRANT SELECT ON dbo.vwAppFileDownloadList TO vw_Select
GO
-----------------------------------------------------

-- 2.8. vwAppDevCopy - List of the Development Copies for Gateway
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwAppDevCopy]'))
DROP VIEW [dbo].vwAppDevCopy
GO
CREATE VIEW dbo.vwAppDevCopy
AS	

--- Get list of executables for each app/env
    SELECT A.APP_ID, E.ENV_ID, E.ENV_PTH + A.APP_SUB_FLD + FL.FLE_PTH + FL.FLE_NME [Path], E.ENV_PTH + A.APP_SUB_FLD + FL.FLE_PTH [folder], FL.FLE_NME [FileName], P.PRG_EXE, I.AI_VER_MAJ + '.' + I.AI_VER_MIN + '.' + I.AI_VER_REV [Version]
    FROM   dbo.vwApplications A 
    INNER JOIN dbo.vwAppEnvironments AE ON AE.APP_ID = A.APP_ID
    INNER JOIN dbo.vwAppIteration I ON I.AE_ID = AE.AE_ID
    INNER JOIN dbo.vwEnvironments E ON E.ENV_ID = AE.ENV_ID
    INNER JOIN dbo.vwAppFileList FL ON FL.AE_ID = AE.AE_ID
    INNER JOIN dbo.vwPrograms P ON P.PRG_ID = FL.PRG_ID
    WHERE  FL.FLE_GRP_ID = 'FGP01'
      AND  I.AI_SSD_DT IS NULL
GO
GRANT SELECT ON dbo.vwAppFileDownloadList TO vw_Select
GO
-----------------------------------------------------

-- 2.9. vwGatewayFileList - File List for Gateway Launcher
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwGatewayFileList]'))
DROP VIEW [dbo].vwGatewayFileList
GO
CREATE VIEW dbo.vwGatewayFileList
AS	

--- Get list of Gateway files for launcher
    SELECT *
    FROM   vwAppFileDownloadList
    WHERE  APP_ID = 'APP000'
	  AND  ENV_ID = (SELECT VAR_TXT FROM tblSYSVarGlobal WHERE VAR_NME  = 'GTY_ENV_ID')
GO
GRANT SELECT ON dbo.vwGatewayFileList TO vw_Select
GO
-----------------------------------------------------

-- 2.10. vwADGroups - Active Directory Groups
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwADGroups]'))
DROP VIEW [dbo].vwADGroups
GO
CREATE VIEW dbo.vwADGroups
AS	

--- Get list of Gateway files for launcher
    SELECT *
    FROM   dbo.tblGTY150
	WHERE  DEL_DT IS NULL
GO
GRANT SELECT ON dbo.vwADGroups TO vw_Select
GO
-----------------------------------------------------

-- 2.11 vwLOGActivity - Activity Log
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLOGActivity]'))
DROP VIEW [dbo].vwLOGActivity
GO
CREATE VIEW dbo.vwLOGActivity
AS	

--- Activity log
SELECT APP.APP_NME AS Application
      ,ENV.ENV_NME AS Environment
	  ,U.USR_FNME + ' ' + U.USR_SNME AS [User]
	  ,L.*
	  ,APP.APP_ID
	  ,ENV.ENV_ID
	  --,U.USR_ID
FROM vwAALog L
INNER JOIN dbo.vwAppIteration AS API ON L.AI_ID = API.AI_ID
INNER JOIN dbo.vwAppEnvironments AS AEV ON API.AE_ID = AEV.AE_ID
INNER JOIN dbo.vwEnvironments AS ENV ON ENV.ENV_ID = AEV.ENV_ID
INNER JOIN dbo.vwApplications AS APP ON APP.APP_ID = AEV.APP_ID
INNER JOIN dbo.vwUsers AS U ON L.USR_ID = U.USR_ID
GO
GRANT SELECT ON dbo.vwLOGActivity TO vw_Select
GO
-----------------------------------------------------

-- 2.12 vwLOGUser - User Log
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLOGUser]'))
DROP VIEW [dbo].vwLOGUser
GO
CREATE VIEW dbo.vwLOGUser
AS	

--- User Log
SELECT APP.APP_NME AS Application
      ,ENV.ENV_NME AS Environment
	  ,U.USR_FNME + ' ' + U.USR_SNME AS [User]
	  ,L.*
	  ,APP.APP_ID
	  ,ENV.ENV_ID
	  --,U.USR_ID
FROM vwAULog L
INNER JOIN vwAppIteration AS API ON L.AI_ID = API.AI_ID
INNER JOIN vwAppEnvironments AS AEV ON API.AE_ID = AEV.AE_ID
INNER JOIN dbo.vwEnvironments AS ENV ON ENV.ENV_ID = AEV.ENV_ID
INNER JOIN vwApplications AS APP ON APP.APP_ID = AEV.APP_ID
INNER JOIN vwUsers AS U ON L.USR_ID = U.USR_ID 
GO
GRANT SELECT ON dbo.vwLOGUser TO vw_Select
GO
-----------------------------------------------------

-- 2.13 vwLOGError - Error Log
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLOGError]'))
DROP VIEW [dbo].vwLOGError
GO
CREATE VIEW dbo.vwLOGError
AS	

--- Error log
SELECT APP.APP_NME AS Application
      ,ENV.ENV_NME AS Environment
	  ,U.USR_FNME + ' ' + U.USR_SNME AS [User]
	  ,L.*
	  ,APP.APP_ID
	  ,ENV.ENV_ID
	  --,U.USR_ID
FROM dbo.vwERLog L
INNER JOIN vwAppIteration AS API ON L.AI_ID = API.AI_ID
INNER JOIN vwAppEnvironments AS AEV ON API.AE_ID = AEV.AE_ID
INNER JOIN dbo.vwEnvironments AS ENV ON ENV.ENV_ID = AEV.ENV_ID
INNER JOIN vwApplications AS APP ON APP.APP_ID = AEV.APP_ID
INNER JOIN vwUsers AS U ON L.USR_ID = U.USR_ID 
GO
GRANT SELECT ON dbo.vwLOGError TO vw_Select
GO
-----------------------------------------------------

-- 2.14 vwLOGActiveUsersNowPerApp - Active Users Now Per App
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLOGActiveUsersNowPerApp]'))
DROP VIEW [dbo].vwLOGActiveUsersNowPerApp
GO
CREATE VIEW dbo.vwLOGActiveUsersNowPerApp
AS	

--- Get list of users per app currently logged in
SELECT LST.[Application]
	  ,LST.Environment
	  ,LST.APP_ID
      ,LST.ENV_ID
	  ,Count(1) AS [No Active Users]
FROM  (
		SELECT DISTINCT APP.APP_NME AS Application
			  ,ENV.ENV_NME AS Environment
			  ,APP.APP_ID
			  ,ENV.ENV_ID
			  ,U.USR_ID,U.USR_ADMIN, L.LOG_IN, L.LOG_OUT
		FROM vwEnvironments AS ENV 
		INNER JOIN (vwApplications AS APP 
		INNER JOIN (((vwAALog AS L 
		INNER JOIN vwUsers AS U ON L.USR_ID = U.USR_ID) 
		INNER JOIN vwAppIteration AS API ON L.AI_ID = API.AI_ID) 
		INNER JOIN vwAppEnvironments AS AEV ON API.AE_ID = AEV.AE_ID) ON APP.APP_ID = AEV.APP_ID) ON ENV.ENV_ID = AEV.ENV_ID
		WHERE L.LOG_OUT IS NULL
		  AND CAST(GETDATE() AS DATE) =  CAST(L.[LOG_IN] AS DATE)
		  AND U.USR_ADMIN = 0
	  )  AS LST
GROUP BY LST.[Application]
	  ,LST.Environment
	  ,LST.APP_ID
      ,LST.ENV_ID
GO
GRANT SELECT ON dbo.vwLOGActiveUsersNowPerApp TO vw_Select
GO
-----------------------------------------------------

-- 2.15 vwLOGActiveUsersPerDayPerApp - Number Users Per Day Per App
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLOGActiveUsersPerDayPerApp]'))
DROP VIEW [dbo].vwLOGActiveUsersPerDayPerApp
GO
CREATE VIEW dbo.vwLOGActiveUsersPerDayPerApp
AS	

--- Number Users Per Day Per App
SELECT LST.Application
	  ,LST.Environment
	  ,LST.APP_ID
      ,LST.ENV_ID
	  ,DayDate AS LogDate
	  ,Count(1) AS [No Unique logins Users]
FROM (
	  SELECT DISTINCT APP.APP_NME AS [Application]
					 ,ENV.ENV_NME AS [Environment]
					 ,U.USR_FNME + ' ' + U.USR_SNME AS [User]
					 ,U.USR_ADMIN AS Admin
					 ,CAST(L.LOG_IN AS DATE) [DayDate]
					 ,APP.APP_ID
					 ,ENV.ENV_ID
	  FROM vwEnvironments AS ENV
	  INNER JOIN (vwApplications AS APP 
		  INNER JOIN (((vwAALog AS L 
			  INNER JOIN vwUsers AS U ON L.USR_ID = U.USR_ID) 
			  INNER JOIN vwAppIteration AS API ON L.AI_ID = API.AI_ID) 
			  INNER JOIN vwAppEnvironments AS AEV ON API.AE_ID = AEV.AE_ID) 
			  ON APP.APP_ID = AEV.APP_ID) 
			  ON ENV.ENV_ID = AEV.ENV_ID
	  WHERE U.USR_ADMIN = 0
	 ) AS LST
GROUP BY LST.Application
	  ,LST.Environment
	  ,LST.APP_ID
      ,LST.ENV_ID
	  ,DayDate
HAVING daydate >= DATEADD(WW,-1,GETDATE())
GO
GRANT SELECT ON dbo.vwLOGActiveUsersPerDayPerApp TO vw_Select
GO
-----------------------------------------------------

-- 2.16 vwLOGInActiveUsers - Inactive users
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLOGInActiveUsers]'))
DROP VIEW [dbo].vwLOGInActiveUsers
GO
CREATE VIEW dbo.vwLOGInActiveUsers
AS	

--- Inactive users
SELECT L.USR_ID
	  ,U.USR_FNME + ' ' + U.USR_SNME AS [User]
	  ,MAX(L.LOG_IN) [Last Login Date] 
FROM  dbo.vwAALog L
INNER JOIN vwAppIteration AS API ON L.AI_ID = API.AI_ID
INNER JOIN vwAppEnvironments AS AEV ON API.AE_ID = AEV.AE_ID
INNER JOIN dbo.vwEnvironments AS ENV ON ENV.ENV_ID = AEV.ENV_ID
INNER JOIN vwApplications AS APP ON APP.APP_ID = AEV.APP_ID
INNER JOIN vwUsers AS U ON L.USR_ID = U.USR_ID 
GROUP BY L.USR_ID
	  ,U.USR_FNME + ' ' + U.USR_SNME
HAVING MAX(L.LOG_IN) < DATEADD(MM,-3,GETDATE())
GO
GRANT SELECT ON dbo.vwLOGInActiveUsers TO vw_Select
GO
-----------------------------------------------------

-- 2.17 vwLogControlTable - Log Control table
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwLogControlTable]'))
DROP VIEW [dbo].vwLogControlTable
GO
CREATE VIEW dbo.vwLogControlTable
AS	

SELECT *
FROM   dbo.tblGTY930
GO
GRANT SELECT ON dbo.vwLogControlTable TO vw_Select
GO
-----------------------------------------------------

-- 2.18 vwADMNUsersGroups - Treeview output for User Groups unders Admin Users
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwADMNUsersGroups]'))
DROP VIEW [dbo].vwADMNUsersGroups
GO
CREATE VIEW dbo.vwADMNUsersGroups
AS	
	SELECT UPPER(T.TreeID) AS [TreeID]
		  ,T.TreeName
		  ,UPPER(T.ParentID) AS [ParentID]
		  ,T.IconID
		  ,T.[Order]
	FROM 
		(
		SELECT 'GRP' + RIGHT('000' + CAST(G.GRP_SID AS VARCHAR(3)),3) AS TreeID
			  ,G.GRP_NME TreeName
			  ,NULL AS ParentID
			  ,'UserGroups16x16' IconID
			  ,'01-' + 'GRP' + RIGHT('000' + CAST(G.GRP_SID AS VARCHAR(3)),3) AS [Order]
		FROM   IFSLA_CENTRAL.adr.tblREF0010 G
		UNION
		SELECT A.APP_ID   AS TreeID
			  ,A.APP_NME TreeName
			  ,'GRP' + RIGHT('000' + CAST(G.GRP_SID AS VARCHAR(3)),3) AS ParentID
			  ,'SMALLARROW' IconID
			  ,'02-' + APP_ID AS [Order]
		FROM   dbo.tblGTY020 A
		INNER JOIN IFSLA_CENTRAL.adr.tblREF0010 G ON G.GRP_NME = A.ACD_GRP_NME
		WHERE  A.APP_TO_DT IS NULL
		) T
GO
GRANT SELECT ON dbo.vwADMNUsersGroups TO vw_Select
GO
-----------------------------------------------------

---- 2.19 vwADMNUsers - Treeview output for Users unders Admin Users
-------------------------------------------------------
--IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vwADMNUsers]'))
--DROP VIEW [dbo].vwADMNUsers
--GO
--CREATE VIEW dbo.vwADMNUsers
--AS	
--SELECT UPPER(T.TreeID) AS TreeID
--	  ,T.TreeName
--	  ,UPPER(T.ParentID) AS ParentID
--	  ,T.IconID
--	  ,T.[Order]
--FROM 
--	(
--	SELECT U.USR_ID AS [TreeID]
--		  ,ISNULL(U.USR_LNME,'') + ISNULL(', ' + U.USR_FNME,'') + ISNULL(' (' + U.USR_ID + ')','') AS TreeName
--		  ,NULL AS [ParentID]
--		  ,'ADMUSERS_USER' AS [IconID]
--		  ,'01-' + ISNULL(U.USR_LNME,'') + ISNULL(', ' + U.USR_FNME,'') + ISNULL(' (' + U.USR_ID + ')','') AS [Order]
--	FROM   IFSLA_CENTRAL.adr.tblUSR0010 U
--	WHERE EXISTS (SELECT 1 FROM IFSLA_CENTRAL.adr.tblUGX0010 X WHERE X.USR_SID = u.USR_SID)
--	UNION
--	SELECT 'G-' + U.USR_ID  AS TreeID
--		  ,'Groups' TreeName
--	      ,U.USR_ID AS ParentID
--		  ,NULL IconID
--		,'02-G' + ISNULL(U.USR_LNME,'') + ISNULL(', ' + U.USR_FNME,'') + ISNULL(' (' + U.USR_ID + ')','') AS [Order]
--	FROM   IFSLA_CENTRAL.adr.tblUSR0010 U
--	WHERE EXISTS (SELECT 1 FROM IFSLA_CENTRAL.adr.tblUGX0010 X WHERE X.USR_SID = u.USR_SID)
--	UNION
--	SELECT 'G-' + U.USR_ID + '-GRP' + RIGHT('000' + CAST(G.GRP_SID AS VARCHAR(3)),3)  AS TreeID
--		  ,G.GRP_NME TreeName
--	      ,'G-' + U.USR_ID AS ParentID
--		  ,'ADMUSERS_ADGroup' IconID
--		,'03-GRP' + CAST(G.GRP_SID AS VARCHAR(3)) AS [Order]
--	FROM   IFSLA_CENTRAL.adr.tblUGX0010 X
--	INNER JOIN IFSLA_CENTRAL.adr.tblUSR0010 U ON U.USR_SID = X.USR_SID
--	INNER JOIN IFSLA_CENTRAL.adr.tblREF0010 G ON G.GRP_SID = X.GRP_SID
--	UNION
--	SELECT 'A-' + U.USR_ID  AS TreeID
--		  ,'Applications' TreeName
--	      ,U.USR_ID AS ParentID
--		  ,NULL IconID
--		,'04-A' + ISNULL(U.USR_LNME,'') + ISNULL(', ' + U.USR_FNME,'') + ISNULL(' (' + U.USR_ID + ')','') AS [Order]
--	FROM   IFSLA_CENTRAL.adr.tblUSR0010 U
--	WHERE EXISTS (SELECT 1 FROM IFSLA_CENTRAL.adr.tblUGX0010 X WHERE X.USR_SID = u.USR_SID)
--	UNION
--	SELECT 'A-' + APE.USR_ID + '-' + APP.APP_ID  AS TreeID
--		  ,APP.APP_NME TreeName
--	      ,'A-' + APE.USR_ID AS ParentID
--		  ,NULL IconID
--		,'05-' + APP.APP_NME AS [Order]
--	FROM   dbo.vwAppPermissions APE
--	INNER JOIN dbo.vwAppEnvironments AEV ON AEV.AE_ID = APE.AE_ID
--	INNER JOIN dbo.vwApplications APP ON APP.APP_ID = AEV.APP_ID
--	INNER JOIN dbo.vwUsers USR ON USR.USR_ID = APE.USR_ID
--	INNER JOIN IFSLA_CENTRAL.adr.tblUSR0010 U ON U.USR_ID = USR.USR_ID
--	WHERE APE.AE_USR_ACT = 1
--	  AND USR.USR_ACT = 1
--	) T
--GO
--GRANT SELECT ON dbo.vwADMNUsers TO vw_Select
--GO
-----------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------

-- 3. Stored Procedure changes
-------------------------------------------------------------------------------------------------------------------------

-- 3.1. Add new uspReturnAdminAppSetup (Returns selected apps setup details)
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAdminAppSetup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAdminAppSetup
--
GO
--
CREATE PROCEDURE dbo.uspReturnAdminAppSetup
    @strAppID VARCHAR(10)
AS
    SET NOCOUNT ON

    SELECT APP.APP_ID
          ,APP.APP_CD
          ,APP.APP_NME
          ,APP.APP_NME_LNG
          ,vwAppCategory.CAT_NME
          ,[BUS_USR].[USR_FNME] + ' ' + [BUS_USR].[USR_SNME] AS BUS_USR_NME
          ,[TCH_USR].[USR_FNME] + ' ' + [TCH_USR].[USR_SNME] AS TCH_USR_NME
          ,APP.APP_SUB_FLD
          ,APP.APP_DB_NME
          ,APP.ACD_GRP_NME
          ,APP.APP_DESC
          ,APP.APP_FROM_DT
          ,APP.APP_TO_DT
    FROM   dbo.vwApplications AS APP 
    INNER JOIN vwUsers AS BUS_USR ON APP.APP_BUS_USR_ID = BUS_USR.USR_ID 
    INNER JOIN vwUsers AS TCH_USR ON APP.APP_TCH_USR_ID = TCH_USR.USR_ID
    INNER JOIN vwAppCategory ON APP.CAT_ID = vwAppCategory.CAT_ID
    WHERE  APP.APP_ID = @strAppID
--
GO
--
GRANT EXECUTE ON [dbo].uspReturnAdminAppSetup TO [sp_Exec]
--
GO
-----------------------------------------------------

-- 3.2. Update uspAddApplication
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspAddApplication]
    @strAppCD           VARCHAR(8)
   ,@strAppName         VARCHAR(255)
   ,@strAppNameLong		VARCHAR(255) = NULL
   ,@strCategory        VARCHAR(255)
   ,@strBusiUserID      VARCHAR(20)
   ,@strTechUserID      VARCHAR(20)
   ,@strAppSubDir       VARCHAR(500)
   ,@strAppDesc			VARCHAR(255)
   ,@strDBName	        VARCHAR(255) = NULL
   ,@strADGroup		    VARCHAR(255) = NULL
   ,@strAppID			VARCHAR(10) OUTPUT
AS
--- Define Variables
    DECLARE @strCatID CHAR(5)
    DECLARE @strAppEnvID CHAR(8)
    DECLARE @strEnvID CHAR(5)
    
    SET NOCOUNT ON
    
--- Run usp for Category that will add if it does not exist and return the ID
    EXEC dbo.uspAddCategory @strCategory, @strCatID OUTPUT

--- If Application number isn't in use then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY020 WHERE APP_CD = @strAppCD) = 0
        -- Insert into Table
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence 'APP', @strAppID OUTPUT
			
			-- Insert new Application details
            INSERT INTO dbo.tblGTY020
            VALUES
            (
			  @strAppID
             ,@strAppCD
             ,@strAppName
             ,@strCatID
             ,@strBusiUserID
             ,@strTechUserID
             ,@strAppSubDir
             ,@strAppDesc
             ,GETDATE()
             ,NULL
			 ,@strAppNameLong
			 ,@strDBName
			 ,@strADGroup
            )
          
            -- Assign all environments to the application
			DECLARE curEnv CURSOR
				FOR 
				SELECT ENV_ID
				FROM   dbo.tblGTY040
				
			OPEN curEnv
				FETCH curEnv INTO @strEnvID

				WHILE @@FETCH_STATUS <> -1
					BEGIN
						EXEC dbo.uspSYSKeySequence 'AEV', @strAppEnvID OUTPUT
						
						INSERT INTO dbo.tblGTY030
						VALUES
						(
						  @strAppEnvID
						 ,@strAppID
						 ,@strEnvID
					    )
						FETCH curEnv INTO @strEnvID
					END
			CLOSE curEnv
			DEALLOCATE curEnv
        END    
    ELSE
        BEGIN
            SET @strAppID = (SELECT APP_ID FROM dbo.tblGTY020 WHERE APP_CD = @strAppCD) 
        END 

    SELECT @strAppID APP_ID
GO
-----------------------------------------------------

-- 3.3. Update uspEditApplication
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspEditApplication]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAppID           CHAR(6)
   ,@strAppCD			VARCHAR(8) = NULL
   ,@strAppName         VARCHAR(255) = NULL
   ,@strAppNameLong		VARCHAR(255) = NULL
   ,@strCategory        VARCHAR(255) = NULL
   ,@strBusiUserID      VARCHAR(20) = NULL	
   ,@strTechUserID      VARCHAR(20) = NULL
   ,@strAppSubDir       VARCHAR(500) = NULL
   ,@strAppDesc			VARCHAR(255) = NULL
   ,@dteCreate			DATETIME = NULL
   ,@dteDecom			DATETIME = NULL
   ,@strDBName	        VARCHAR(255) = NULL
   ,@strADGroup		    VARCHAR(255) = NULL
AS	
--- Define Variables
    DECLARE @strCatID CHAR(5)
        
    SET NOCOUNT ON

--- Get the Category ID if needed
	IF @strCategory IS NOT NULL AND @strCategory <> ''
		EXEC dbo.uspAddCategory @strCategory, @strCatID OUTPUT
		
--- If Application ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY020 APP WHERE APP.APP_ID = @strAppID) = 1
		BEGIN
		-- IF Application code supplied is not in use or if supplied, hasn't changed continue
		IF (SELECT COUNT(1) FROM dbo.tblGTY020 WHERE APP_CD = @strAppCD AND APP_ID <> @strAppID) = 0 
			-- Edit required details table
			BEGIN
				UPDATE dbo.tblGTY020
				SET    APP_CD = 
								CASE WHEN @strAppCD IS NOT NULL AND @strAppCD <> ''
								  THEN @strAppCD
								  ELSE APP_CD
								END
					  ,APP_NME = 
								CASE WHEN @strAppName IS NOT NULL AND @strAppName <> ''
								  THEN @strAppName
								  ELSE APP_NME
								END
					  ,CAT_ID = 
								CASE WHEN @strCategory IS NOT NULL AND @strCategory <> ''
								  THEN @strCatID
								  ELSE CAT_ID
								END
					  ,APP_BUS_USR_ID = 
								CASE WHEN @strBusiUserID IS NOT NULL AND @strBusiUserID <> ''
								  THEN @strBusiUserID
								  ELSE APP_BUS_USR_ID
								END
					  ,APP_TCH_USR_ID = 
								CASE WHEN @strTechUserID IS NOT NULL AND @strTechUserID <> ''
								  THEN @strTechUserID
								  ELSE APP_TCH_USR_ID
								END						
					  ,APP_SUB_FLD = 
								CASE WHEN @strAppSubDir IS NOT NULL AND @strAppSubDir <> ''
								  THEN @strAppSubDir
								  ELSE APP_SUB_FLD
								END
					  ,APP_FROM_DT = 
								CASE WHEN @dteCreate IS NOT NULL AND @dteCreate <> ''
								  THEN @dteCreate
								  ELSE APP_FROM_DT
								END
					  ,APP_TO_DT = 
								CASE WHEN @dteDecom IS NOT NULL AND @dteDecom <> ''
								  THEN @dteDecom
								  ELSE APP_TO_DT
								END
					  ,APP_DESC = 
								CASE WHEN @strAppDesc IS NOT NULL AND @strAppDesc <> ''
								  THEN @strAppDesc
								  ELSE APP_DESC
								END
					  ,APP_NME_LNG = 
								CASE WHEN @strAppNameLong IS NOT NULL AND @strAppNameLong <> ''
								  THEN @strAppNameLong
								  ELSE ''
								END
					  ,APP_DB_NME = 
								CASE WHEN @strDBName IS NOT NULL AND @strDBName <> ''
								  THEN @strDBName
								  ELSE ''
								END
					  ,ACD_GRP_NME = 
								CASE WHEN @strADGroup IS NOT NULL AND @strADGroup <> ''
								  THEN @strADGroup
								  ELSE ''
								END
				WHERE  APP_ID = @strAppID
				
				SET @strReturnCode = 'EDITED'
				
				SELECT @strAppID 
			END
		ELSE
			BEGIN
				SET @strReturnCode = 'ERROR (APPLICATION CODE ALREADY EXISTS)'
				SELECT @strReturnCode
			END
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = 'ERROR (RECORD NOT FOUND)'
            SELECT @strReturnCode
        END 
--
GO
-----------------------------------------------------

-- 3.4. Add new uspReturnAdminAppIterations (Returns selected apps iteration details (DEV only))
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAdminAppIterations]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAdminAppIterations
--
GO
--
CREATE PROCEDURE dbo.uspReturnAdminAppIterations
    @strAppID VARCHAR(10)
AS
    SET NOCOUNT ON

    SELECT I.AI_ID [Iteration ID]
          ,I.[AI_VER_MAJ] + '.' + I.[AI_VER_MIN] + '.' + I.[AI_VER_REV] AS [Version]
          ,CASE I.[AI_STS]
            WHEN 1 THEN 'Active'
            WHEN 2 THEN 'Maintenance'
            ELSE 'Offline'
           END AS [Status]
          ,I.AI_VER_CMT [Comment]
          ,I.AI_CRT_DT AS [Create Date]
          ,I.AI_SSD_DT AS [Superseeded Date]
    FROM   vwAppIteration I 
    INNER JOIN vwAppEnvironments E ON I.AE_ID = E.AE_ID
    WHERE  E.APP_ID = @strAppID 
      AND  E.ENV_ID = 'ENV03'
    ORDER BY I.[AI_VER_MAJ] + '.' + I.[AI_VER_MIN] + '.' + I.[AI_VER_REV] DESC
          ,I.AI_CRT_DT DESC
--
GO
GRANT EXECUTE ON [dbo].uspReturnAdminAppIterations TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.5. Add new uspReturnAdminAppIterationPRODandTEST (Returns selected apps iteration details for prod and test only)
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAdminAppIterationPRODandTEST]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAdminAppIterationPRODandTEST
--
GO
--
CREATE PROCEDURE dbo.uspReturnAdminAppIterationPRODandTEST
    @strAppID VARCHAR(10)
AS
    SET NOCOUNT ON

    SELECT I.AI_ID [Iteration ID]
          ,I.[AI_VER_MAJ] + '.' + I.[AI_VER_MIN] + '.' + I.[AI_VER_REV] AS [Version]
          ,CASE I.[AI_STS]
            WHEN 1 THEN 'Active'
            WHEN 2 THEN 'Maintenance'
            ELSE 'Offline'
           END AS [Status]
          ,I.AI_STS
          ,E.ENV_ID 
          ,I.AI_VER_CMT [Comment]
          ,I.AI_CRT_DT AS [Create Date]
          ,I.AI_SSD_DT AS [Superseeded Date]
    FROM   vwAppIteration I 
    INNER JOIN vwAppEnvironments E ON I.AE_ID = E.AE_ID
    WHERE  E.APP_ID = @strAppID 
      AND  E.ENV_ID IN('ENV01','ENV02')
      AND  I.AI_SSD_DT IS NULL
    ORDER BY E.ENV_ID
          ,I.[AI_VER_MAJ] + '.' + I.[AI_VER_MIN] + '.' + I.[AI_VER_REV] DESC
          ,I.AI_CRT_DT DESC
--
GO
GRANT EXECUTE ON [dbo].uspReturnAdminAppIterationPRODandTEST TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.5. Update uspAddIteration
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspAddAppIteration] 
    @strAppEnvID CHAR(8)
   ,@strVerMaj CHAR(2)
   ,@strVerMin CHAR(2)
   ,@strVerRev CHAR(2)
   ,@strComment VARCHAR(255)
   ,@strAppIterID CHAR(8) OUTPUT
AS
	
    SET NOCOUNT ON
        
--- If Application Iteration doesn't exists, then add and retrieve the ID
    IF (SELECT COUNT(1) 
		FROM   dbo.tblGTY070
		WHERE  AE_ID = @strAppEnvID 
		  AND  AI_VER_MAJ = @strVerMaj
		  AND  AI_VER_MIN = @strVerMin
		  AND  AI_VER_REV = @strVerRev) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence 'API', @strAppIterID OUTPUT
            
            INSERT INTO dbo.tblGTY070
            VALUES
            (
              @strAppIterID
             ,@strAppEnvID
             ,@strVerMaj
             ,@strVerMin
             ,@strVerRev
             ,@strComment
             ,0
             ,GETDATE()
             ,NULL
            )
        END
    ELSE
        BEGIN
            SET @strAppIterID = (SELECT AI_ID 
								 FROM   dbo.tblGTY070 
								 WHERE  AE_ID = @strAppEnvID 
							 	   AND  AI_VER_MAJ = @strVerMaj 
							 	   AND  AI_VER_MIN = @strVerMin
							  	   AND  AI_VER_REV = @strVerRev)
        END
    
    SELECT @strAppIterID
GO
-----------------------------------------------------

-- 3.7. Update uspEditIteration
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspEditIteration]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAPIid           CHAR(8)
   ,@strVerMaj			CHAR(2) = NULL
   ,@strVerMin			CHAR(2) = NULL
   ,@strVerRev			CHAR(2) = NULL
   ,@strComment 		VARCHAR(255) = NULL
   ,@intStatusID		INT = -1

AS	
--- Define Variables
    DECLARE @strAppEnvID CHAR(8)	
    
    SET NOCOUNT ON
		
--- If Iteration ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY070 WHERE AI_ID = @strAPIid) = 1
		BEGIN
			-- Update table with new values
			UPDATE dbo.tblGTY070
			SET    AI_VER_MAJ = 
						   CASE WHEN @strVerMaj IS NOT NULL AND @strVerMaj <> ''
						     THEN @strVerMaj
							 ELSE AI_VER_MAJ
						   END
			      ,AI_VER_MIN = 
						   CASE WHEN @strVerMin IS NOT NULL AND @strVerMin <> ''
						     THEN @strVerMin
							 ELSE AI_VER_MIN
						   END
			      ,AI_VER_REV = 
						   CASE WHEN @strVerRev IS NOT NULL AND @strVerRev <> ''
						     THEN @strVerRev
							 ELSE AI_VER_REV
						   END
			      ,AI_VER_CMT = 
						   CASE WHEN @strComment IS NOT NULL AND @strComment <> ''
						     THEN @strComment
							 ELSE AI_VER_CMT
						   END		
			      ,AI_STS = 
						   CASE WHEN @intStatusID IS NOT NULL AND @intStatusID <> -1
						     THEN @intStatusID
							 ELSE AI_STS
						   END
				  ,AI_SSD_DT =
						   CASE WHEN @intStatusID > 0
						     THEN NULL
							 ELSE AI_SSD_DT
						   END				   						
			WHERE  AI_ID = @strAPIid
			
			-- If this iteration has been activated, then all others for this app/env need to be disabled
			IF @intStatusID > 0
				BEGIN
					-- Get App/Env ID
					SET @strAppEnvID = (SELECT AE_ID FROM dbo.tblGTY070 WHERE AI_ID = @strAPIid)
					
					-- Change all other iterations for app/env to offline and make sure it has a superseeded date
					SET @strAppEnvID = (SELECT AE_ID FROM dbo.tblGTY070 WHERE AI_ID = @strAPIid)
					UPDATE dbo.tblGTY070
					SET    AI_STS = 0
						  ,AI_SSD_DT = GETDATE()
					
					WHERE  AE_ID = @strAppEnvID	
					  AND  AI_ID <> @strAPIid
                      AND  AI_SSD_DT IS NULL     -- Added on 16/01/2013 11:10
				END
			SET @strReturnCode = 'EDITED'
			SELECT @strAPIid
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = 'ERROR (RECORD NOT FOUND)'
            SELECT @strReturnCode
        END 
GO
-----------------------------------------------------

-- 3.8. Add new uspReturnAdminAppIteration (Returns selected iteration detail)
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAdminSelectIteration]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAdminSelectIteration
--
GO
--
CREATE PROCEDURE dbo.uspReturnAdminSelectIteration
    @strAPI_ID VARCHAR(10)
AS
    SET NOCOUNT ON

    SELECT I.AI_ID [Iteration ID]
          ,I.[AI_VER_MAJ] + '.' + I.[AI_VER_MIN] + '.' + I.[AI_VER_REV] AS [Version]
          ,I.[AI_VER_MAJ]
          ,I.[AI_VER_MIN]
          ,I.[AI_VER_REV]
          ,CASE I.[AI_STS]
            WHEN 1 THEN 'Active'
            WHEN 2 THEN 'Maintenance'
            ELSE 'Offline'
           END AS [Status]
          ,I.AI_VER_CMT [Comment]
          ,I.AI_CRT_DT AS [Create Date]
          ,I.AI_SSD_DT AS [Superseeded Date]
    FROM   vwAppIteration I 
    INNER JOIN vwAppEnvironments E ON I.AE_ID = E.AE_ID
    WHERE  I.AI_ID = @strAPI_ID
    ORDER BY I.[AI_VER_MAJ] + '.' + I.[AI_VER_MIN] + '.' + I.[AI_VER_REV] DESC
          ,I.AI_CRT_DT DESC
--
GO
GRANT EXECUTE ON [dbo].uspReturnAdminSelectIteration TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.9. Add new uspSYSKeySequence 
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspSYSKeySequence] 
    @strKeyID CHAR(3)
   ,@strNewKey VARCHAR(15) OUTPUT
AS

--- DECLARE VARIABLES
	DECLARE @intKeyLen INTEGER
	
    SET NOCOUNT ON
    
    SET @strNewKey = 'ERROR'
        
--- GET THE NEW KEY
	SET @intKeyLen = (SELECT TBL_KEY_LEN FROM dbo.tblSYSKey WHERE TBL_KEY_ID = @strKeyID)
	
    IF @intKeyLen > 0
        BEGIN		
            -- Generate a new ID
			SELECT @strNewKey = TBL_KEY_ID + RIGHT('000000000000' + CONVERT(VARCHAR(12), KEY_SEQ_NBR), @intKeyLen)
			FROM   dbo.tblSYSKey
			WHERE  TBL_KEY_ID = @strKeyID
			
			-- Roll on key ID to next
			UPDATE dbo.tblSYSKey
			SET    KEY_SEQ_NBR = KEY_SEQ_NBR + 1
			WHERE  TBL_KEY_ID = @strKeyID
			
			SELECT @strNewKey
        END
GO
-----------------------------------------------------

-- 3.10. Add uspCleanUpFiles
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspCleanUpFiles]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspCleanUpFiles
--
GO
--
CREATE PROCEDURE dbo.uspCleanUpFiles

AS
    SET NOCOUNT ON
    
    -- Delete any stored file which is not link
    DELETE F
    FROM dbo.tblGTY140 F
    WHERE  NOT EXISTS (SELECT 1 FROM dbo.tblGTY090 WHERE STR_FLE_ID = F.STR_FLE_ID)
GO
GRANT EXECUTE ON [dbo].uspCleanUpFiles TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.11. Add uspChangeAppGWIcon
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspChangeAppGWIcon]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspChangeAppGWIcon
--
GO
--
CREATE PROCEDURE dbo.uspChangeAppGWIcon
    @strAPP_ID      VARCHAR(6)
   ,@strFilePath    VARCHAR(255)
   ,@strFileName    VARCHAR(255)
   ,@strSTR_FLE_ID  VARCHAR(8)
AS
    SET NOCOUNT ON
    DECLARE @strAE_ID CHAR(8)
    DECLARE @strAppEnvFileID CHAR(8)
    
    -- Get AE ID
    SET @strAE_ID = (SELECT AE_ID FROM dbo.tblGTY030 WHERE APP_ID = @strAPP_ID AND ENV_ID = 'ENV03')
    
    -- Has AE Been found?
    IF @strAE_ID <> '' AND @strAE_ID IS NOT NULL
        BEGIN
            -- Does a record exists for the GW Icon? If so, update, otherwise insert
            IF (SELECT 1 FROM dbo.tblGTY090 WHERE AE_ID = @strAE_ID AND FLE_GRP_ID = 'FGP04') = 1
                BEGIN
                    -- Update
                    UPDATE dbo.tblGTY090
                    SET    FLE_PTH = @strFilePath
                          ,FLE_NME = @strFileName
                          ,STR_FLE_ID = @strSTR_FLE_ID
                    WHERE  AE_ID = @strAE_ID
                      AND  FLE_GRP_ID = 'FGP04'
                END
            ELSE
                BEGIN
                    -- Insert new
                    EXEC dbo.uspSYSKeySequence 'AEF', @strAppEnvFileID OUTPUT
                    
                    INSERT INTO dbo.tblGTY090
                    VALUES
                    (
                      @strAppEnvFileID
                     ,@strAE_ID
                     ,@strFilePath
                     ,@strFileName
                     ,'GW Icon'
                     ,'FGP04'
                     ,'PRG04'
                     ,@strSTR_FLE_ID
                    )
                END
            
            -- Clean up Files
            EXEC dbo.uspCleanUpFiles
        END    
GO
GRANT EXECUTE ON [dbo].uspChangeAppGWIcon TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.12. Add new uspReturnAdminAppFilesTreeview (Returns build for files treeview in admin)
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAdminAppFilesTreeview]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAdminAppFilesTreeview
--
GO
--
CREATE PROCEDURE dbo.uspReturnAdminAppFilesTreeview
    @strAPP_ID  VARCHAR(6)
   ,@strENV_ID  VARCHAR(5)
AS
    SET NOCOUNT ON
    
    SELECT AFL.APP_FLE_ID 
          ,[FLE_PTH] + [FLE_NME] AS FilePath
          ,P.PRG_ID AS [IconID]
    FROM   vwFileGroups AS FG 
    INNER JOIN vwAppFileList AS AFL ON FG.FLE_GRP_ID = AFL.FLE_GRP_ID 
    INNER JOIN vwAppEnvironments AS AE ON AFL.AE_ID = AE.AE_ID
    INNER JOIN vwPrograms AS P ON AFL.PRG_ID = P.PRG_ID
    INNER JOIN vwEnvironments AS ENV ON AE.ENV_ID = ENV.ENV_ID
    WHERE AE.APP_ID = @strAPP_ID 
      AND ENV.ENV_ID = @strENV_ID
      AND FG.FLE_GRP_ID NOT IN ('FGP04')
    ORDER BY [FLE_PTH] + [FLE_NME]
GO
GRANT EXECUTE ON [dbo].uspReturnAdminAppFilesTreeview TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.13 Add new uspReturnAdminAppSelectedFile (Returns details for selected ID)
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAdminAppSelectedFile]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAdminAppSelectedFile
--
GO
--
CREATE PROCEDURE dbo.uspReturnAdminAppSelectedFile
    @strAEF_ID VARCHAR(8)
AS
    SET NOCOUNT ON
    
    SELECT AFL.APP_FLE_ID
          ,AFL.FLE_PTH + AFL.FLE_NME [FilePath]
          ,FG.FLE_GRP_NME [Group]
          ,AFL.FLE_DESC [Description]
          ,P.PRG_NME [Program]
    FROM   dbo.vwAppFileList AS AFL
    INNER JOIN dbo.vwFileGroups FG ON FG.FLE_GRP_ID = AFL.FLE_GRP_ID
    INNER JOIN dbo.vwPrograms P ON P.PRG_ID = AFL.PRG_ID
    WHERE  AFL.APP_FLE_ID = @strAEF_ID
    
GO
GRANT EXECUTE ON [dbo].uspReturnAdminAppSelectedFile TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.14 Alter uspDelAppFiles to include file store cleanup
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspDelAppFiles] 
    @strReturnCode VARCHAR(10) OUTPUT
   ,@strAppFileID CHAR(8)
AS    
    SET NOCOUNT ON
    
--- If the App file exists, then delete it
    IF (SELECT COUNT(1) FROM dbo.tblGTY090 WHERE APP_FLE_ID = @strAppFileID) = 1
        BEGIN           
            DELETE
            FROM  dbo.tblGTY090
            WHERE APP_FLE_ID = @strAppFileID

            SET @strReturnCode = 'DELETED'
        END
    ELSE
        BEGIN
            SET @strReturnCode = 'DOES NOT EXISTS'
        END
    
    -- Clean up Files
    EXEC dbo.uspCleanUpFiles
GO
-----------------------------------------------------

-- 3.15. Update uspAddAppEnvFile
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspAddAppEnvFile]
    @AppEnvID           CHAR(8)	
   ,@strFilePath        VARCHAR(255)
   ,@strFileName		VARCHAR(255)
   ,@strFileDesc        VARCHAR(255)
   ,@strProgramID       CHAR(5)
   ,@strFileGrpID		CHAR(5)
   ,@strAppEnvFileID	CHAR(8) OUTPUT
   ,@strSTR_FLE_ID      CHAR(8)
AS
    SET NOCOUNT ON

--- If file hasn't already been added, then add and retrieve ID
    IF (SELECT COUNT(1) FROM dbo.tblGTY090 AEF WHERE AEF.AE_ID = @AppEnvID AND AEF.FLE_PTH = @strFilePath AND AEF.FLE_NME = @strFileName) = 0
        BEGIN
            -- Generate a new ID
			EXEC dbo.uspSYSKeySequence 'AEF', @strAppEnvFileID OUTPUT
            
            INSERT INTO dbo.tblGTY090
            VALUES
            (
              @strAppEnvFileID
             ,@AppEnvID
             ,@strFilePath
             ,@strFileName
             ,@strFileDesc
             ,@strFileGrpID
             ,@strProgramID
             ,NULLIF(@strSTR_FLE_ID,'')
            )

			SELECT @strAppEnvFileID
        END
    ELSE
        BEGIN
            SELECT 'File Already Exists'
        END
        
    -- Clean up Files
    EXEC dbo.uspCleanUpFiles
GO
-----------------------------------------------------

-- 3.16 Update uspEditFileList
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspEditFileList]
	@strReturnCode      VARCHAR(25) OUTPUT
   ,@strAppFileID       CHAR(8)
   ,@strFilePath        VARCHAR(500) = NULL
   ,@strFileName        VARCHAR(255) = NULL
   ,@strFileDesc		VARCHAR(255) = NULL
   ,@strFileGrpID		CHAR(5) = NULL
   ,@strProgramID		CHAR(5) = NULL
   ,@strSTR_FLE_ID      CHAR(8) = NULL
AS	
--- Define Variables
    DECLARE @strAppEnvID CHAR(8)	
    
    SET NOCOUNT ON
		
--- If Iteration ID exists then continue
    IF (SELECT COUNT(1) FROM dbo.tblGTY090 WHERE APP_FLE_ID = @strAppFileID) = 1
		BEGIN
			-- Update table with new values
			UPDATE dbo.tblGTY090
			SET    FLE_PTH = 
						   CASE WHEN @strFilePath IS NOT NULL AND @strFilePath <> ''
						     THEN @strFilePath
							 ELSE FLE_PTH
						   END			   						
			      ,FLE_NME = 
						   CASE WHEN @strFileName IS NOT NULL AND @strFileName <> ''
						     THEN @strFileName
							 ELSE FLE_NME
						   END	
			      ,FLE_DESC = 
						   CASE WHEN @strFileDesc IS NOT NULL AND @strFileDesc <> ''
						     THEN @strFileDesc
							 ELSE FLE_DESC
						   END	
			      ,FLE_GRP_ID = 
						   CASE WHEN @strFileGrpID IS NOT NULL AND @strFileGrpID <> ''
						     THEN @strFileGrpID
							 ELSE FLE_GRP_ID
						   END	
			      ,PRG_ID = 
						   CASE WHEN @strProgramID IS NOT NULL AND @strProgramID <> ''
						     THEN @strProgramID
							 ELSE PRG_ID
						   END
			      ,STR_FLE_ID = 
						   CASE WHEN @strSTR_FLE_ID IS NOT NULL AND @strSTR_FLE_ID <> ''
						     THEN @strSTR_FLE_ID
							 ELSE NULL
						   END
			WHERE  APP_FLE_ID = @strAppFileID

            -- Clean up Files
            EXEC dbo.uspCleanUpFiles
            
			SET @strReturnCode = 'EDITED'
			SELECT @strAppFileID
		END
    ELSE
        -- Raise an Error
        BEGIN
            SET @strReturnCode = 'ERROR (RECORD NOT FOUND)'
            SELECT @strReturnCode
        END 

GO
-----------------------------------------------------

-- 3.17. Update User Listing
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGetUserPermissionsFromAD]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspGetUserPermissionsFromAD
--
GO
--
CREATE PROCEDURE dbo.uspGetUserPermissionsFromAD
AS
    SET NOCOUNT ON
    DECLARE @intPER_ID INTEGER
    DECLARE @strMsg VARCHAR(255)
    DECLARE @intRowCount INTEGER
    SET @strMsg = ''
    
    BEGIN TRY
        BEGIN TRANSACTION
        -- Add and remove users based upon latest Active Directory in CENTRAL
        ---------------------------------     
			-- Add New user Groups
			MERGE INTO dbo.tblGTY150 as T
				  USING IFSLA_CENTRAL.adr.tblREF0010 S
				  ON T.GRP_SID = S.GRP_SID
			WHEN MATCHED THEN
				UPDATE SET GRP_NME = S.GRP_NME
							  ,CRT_DT = S.CRT_DT
						      ,DEL_DT = S.DEL_DT
			WHEN NOT MATCHED THEN
				INSERT (
						GRP_SID
					   ,GRP_NME
					   ,CRT_DT
					   ,DEL_DT
					   )
				VALUES (
						S.GRP_SID
					   ,S.GRP_NME
					   ,S.CRT_DT
					   ,S.DEL_DT
					   )
			;
			          
            -- Add new users into tblGTY060
            INSERT INTO dbo.tblGTY060
            (
                   USR_ID
                  ,USR_FNME
                  ,USR_SNME
                  ,USR_ACT
                  ,USR_ADMIN
                  ,USR_EMAIL
                  ,USR_INACT_DT
            )
            SELECT U.USR_ID
                  ,ISNULL(U.USR_FNME,'')
                  ,ISNULL(U.USR_LNME,'')
                  ,1
                  ,0
                  ,ISNULL(U.USR_EMAIL,'')
                  ,NULL
            FROM IFSLA_CENTRAL.adr.vwUserGroups G
            INNER JOIN IFSLA_CENTRAL.adr.vwUser U ON U.USR_ID = G.USR_ID
            WHERE NOT EXISTS (SELECT 1 FROM dbo.tblGTY060 t WHERE U.USR_ID = t.USR_ID)
              AND G.GRP_SID = 1
            
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0 
            BEGIN
                SET @strMsg = @strMsg + 'Number of Users Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Update Users
            UPDATE dbo.tblGTY060
            SET    USR_FNME = ISNULL(U.USR_FNME,'')
                  ,USR_SNME = ISNULL(U.USR_LNME,'')
                  ,USR_ACT = 1
                  ,USR_EMAIL = ISNULL(U.USR_EMAIL,'')
                  ,USR_INACT_DT = NULL
            FROM   dbo.tblGTY060 G60
            INNER JOIN IFSLA_CENTRAL.adr.vwUserGroups G ON G.USR_ID = G60.USR_ID
            INNER JOIN IFSLA_CENTRAL.adr.vwUser U ON U.USR_ID = G.USR_ID
              AND G.GRP_SID = 1
              AND (
                   G60.USR_FNME <> U.USR_FNME
                   OR G60.USR_SNME <> U.USR_LNME
                   OR G60.USR_ACT <> 1
                   OR G60.USR_EMAIL <> U.USR_EMAIL
                   OR USR_INACT_DT IS NOT NULL)
                   
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0 
            BEGIN
                SET @strMsg = @strMsg + 'Number of Users Updated: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Mark users hwo have disappeared
            UPDATE dbo.tblGTY060
            SET    USR_ACT = 0
                  ,USR_ADMIN = 0
                  ,USR_INACT_DT = GETDATE()
            FROM   dbo.tblGTY060 G60
            WHERE  USR_ACT = 1
              AND  NOT EXISTS (SELECT 1 
                               FROM   IFSLA_CENTRAL.adr.vwUserGroups G
                               INNER JOIN IFSLA_CENTRAL.adr.vwUser U ON U.USR_ID = G.USR_ID
                               WHERE  G.GRP_SID = 1 
                                 AND  U.USR_ID = G60.USR_ID)
            
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0 
            BEGIN
                SET @strMsg = @strMsg + 'Number of Users Removed: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
        ---------------------------------   
        
        -- For developers
        ---------------------------------   
            -- Get list of devs (Users who have access to IFSLOCALAPPS
            SELECT U.USR_ID
                  ,G.USR_FNME + ' ' + G.USR_SNME [USER]
            INTO   #tmpDevs
            FROM   IFSLA_CENTRAL.adr.vwUserGroups U
            INNER JOIN IFSLA_GATEWAY.dbo.tblGTY060 G ON G.USR_ID = U.USR_ID
            WHERE  U.GRP_SID = 5
            
            -- Remove permissions to all apps for Admin users who aren't in the list (Exception being BU730 and JL790 incase it breaks)
            UPDATE dbo.tblGTY050 
            SET    AE_USR_ACT = 0
            FROM   dbo.tblGTY050 G50
            INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
            WHERE  G60.USR_ADMIN = 1
			  AND  G60.USR_ID NOT IN('BU730', 'JL790')
              AND  NOT EXISTS (SELECT 1 FROM #tmpDevs D WHERE D.USR_ID = USR_ID)

            -- Remove dev permissions for users not in this list (Exception being BU730 and JL790 incase it breaks)
            UPDATE dbo.tblGTY060
            SET    USR_ADMIN = 0
            FROM   dbo.tblGTY060 G
            WHERE NOT EXISTS (SELECT 1 FROM #tmpDevs D WHERE D.USR_ID = G.USR_ID)
              AND  USR_ID NOT IN('BU730', 'JL790')
              AND  USR_ADMIN = 1
            
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Removed: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Add in New Admins
            UPDATE dbo.tblGTY060
            SET    USR_ADMIN = 1
            FROM   dbo.tblGTY060 G
            WHERE  EXISTS (SELECT 1 FROM #tmpDevs D WHERE D.USR_ID = G.USR_ID)
              AND  USR_ADMIN = 0
              
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Generate all data ready
            SELECT G30.AE_ID
                  ,D.USR_ID
            INTO   #tmpDevAssign
            FROM   dbo.tblGTY030 G30 
                  ,#tmpDevs D
                  
            -- Assign full permissions to all apps for admin
            SET @intPER_ID = (SELECT KEY_SEQ_NBR FROM dbo.tblSYSKey WHERE TBL_KEY_ID = 'APE')
            INSERT INTO dbo.tblGTY050
            (
                   PER_ID
                  ,AE_ID
                  ,USR_ID
                  ,AE_USR_ACT
                  ,CUR_ATN
                  ,FAV
            )
            SELECT 'APE' + RIGHT('00000' + CAST(@intPER_ID + ROW_NUMBER() OVER(ORDER BY DA.AE_ID) AS VARCHAR(25)),5)
                  ,DA.AE_ID
                  ,DA.USR_ID
                  ,1
                  ,0
                  ,0
            FROM   #tmpDevAssign DA
            WHERE NOT EXISTS (SELECT 1 FROM dbo.tblGTY050 t WHERE t.AE_ID = DA.AE_ID AND t.USR_ID = DA.USR_ID)
            
            -- Update Key table
            SET @intRowCount = @@ROWCOUNT
                
            UPDATE dbo.tblSYSKey
            SET    KEY_SEQ_NBR = @intPER_ID + @intRowCount + 1
            WHERE  TBL_KEY_ID = 'APE'
            
			-- Log
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Permissions Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END

			-- Update Permissions
			UPDATE dbo.tblGTY050
			SET    AE_USR_ACT = 1
			FROM   dbo.tblGTY050 G50
			INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
			WHERE  AE_USR_ACT = 0
			  AND  G60.USR_ACT = 1
			  AND  EXISTS (SELECT 1 FROM #tmpDevAssign DA WHERE DA.AE_ID = G50.AE_ID AND DA.USR_ID = G50.USR_ID)

			-- Log
			SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Permissions Updated: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END

            -- Clear Memory
            DROP TABLE #tmpDevs
            DROP TABLE #tmpDevAssign
        ---------------------------------
        
        -- Apply the rest of the permissions for standard users
        ---------------------------------
            -- Get full permissions based upon current setup
            SELECT AE.AE_ID
                  ,UG.USR_ID
            INTO   #tmpUserPerms
            FROM   dbo.tblGTY020 APP
            INNER JOIN dbo.tblGTY030 AE ON AE.APP_ID = APP.APP_ID
            INNER JOIN IFSLA_CENTRAL.adr.vwUserGroups UG ON UG.GRP_NME = APP.ACD_GRP_NME
            WHERE  AE.ENV_ID IN ('ENV01','ENV02')
			  AND  UG.GRP_SID <> 5

           -- full permissions to all apps/user combos that don't exist
            SET @intPER_ID = (SELECT KEY_SEQ_NBR FROM dbo.tblSYSKey WHERE TBL_KEY_ID = 'APE')
            INSERT INTO dbo.tblGTY050
            (
                   PER_ID
                  ,AE_ID
                  ,USR_ID
                  ,AE_USR_ACT
                  ,CUR_ATN
                  ,FAV
            )
            SELECT 'APE' + RIGHT('00000' + CAST(@intPER_ID + ROW_NUMBER() OVER(ORDER BY UP.AE_ID) AS VARCHAR(25)),5)
                  ,UP.AE_ID
                  ,UP.USR_ID
                  ,1
                  ,0
                  ,0
            FROM   #tmpUserPerms UP
            WHERE NOT EXISTS (SELECT 1 FROM dbo.tblGTY050 t WHERE t.AE_ID = UP.AE_ID AND t.USR_ID = UP.USR_ID)

            -- Update Key table
            SET @intRowCount = @@ROWCOUNT
                
            UPDATE dbo.tblSYSKey
            SET    KEY_SEQ_NBR = @intPER_ID + @intRowCount + 1
            WHERE  TBL_KEY_ID = 'APE'

            -- Log
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of User Permissions Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            --  Update permissions
            UPDATE dbo.tblGTY050 
            SET    AE_USR_ACT = 1
            FROM   dbo.tblGTY050 G50
            INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
            WHERE  G60.USR_ADMIN = 0
              AND  EXISTS (SELECT 1 FROM #tmpUserPerms UP WHERE UP.USR_ID = G50.USR_ID AND UP.AE_ID = G50.AE_ID)
			  AND  G50.AE_USR_ACT = 0
              
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of User Permissions Updated: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END

            -- Remove permissions to all apps for users who aren't in the list (except admins)
            UPDATE dbo.tblGTY050 
            SET    AE_USR_ACT = 0
            FROM   dbo.tblGTY050 G50
            INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
            WHERE  G60.USR_ADMIN = 0
              AND  G50.AE_USR_ACT = 1
			  AND  NOT EXISTS (SELECT 1 FROM #tmpUserPerms UP WHERE UP.USR_ID = G50.USR_ID AND UP.AE_ID = G50.AE_ID)
			  AND  G60.USR_ACT	= 1
              
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of User Permissions Deleted: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            PRINT @strMsg
            
            -- Clear Memory
            DROP TABLE #tmpUserPerms
        COMMIT TRANSACTION
    END TRY
    
    BEGIN CATCH
            --/ Capture the error                
        DECLARE @ERR_Severity INTEGER
        DECLARE @ERR_State INTEGER
        DECLARE @ERR_Number INTEGER
        DECLARE @ERR_Line INTEGER
        DECLARE @ERR_Message VARCHAR(255)
            
        SET @ERR_Severity = ERROR_SEVERITY()
        SET @ERR_State = ERROR_STATE()
	    SET @ERR_Number = ERROR_NUMBER()
	    SET @ERR_Line = ERROR_LINE()
	    SET @ERR_Message = ERROR_MESSAGE()
        
        -- LOG ERROR HERE
        PRINT '-- Current log'
        PRINT @strMsg
        
        PRINT '-- ERROR: ' + @ERR_Message
        ROLLBACK TRANSACTION
        RAISERROR ('Msg %d, Line %d: %s',@ERR_Severity,@ERR_State,@ERR_Number,@ERR_Line,@ERR_Message)
    END CATCH
    ---------------------------------    
GO
GRANT EXECUTE ON [dbo].uspGetUserPermissionsFromAD TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.18. Add new uspReturnCanUserOpenApp (App/Env current RAG for user)... can user access app
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnCanUserOpenApp]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnCanUserOpenApp
--
GO
--
CREATE PROCEDURE dbo.uspReturnCanUserOpenApp
    @strAPP_ID  VARCHAR(6)
   ,@strENV_ID  VARCHAR(5)
   ,@strUSR_ID  VARCHAR(25)
AS
    SET NOCOUNT ON
    DECLARE @bitAdmin BIT
    DECLARE @intSTS INTEGER
    DECLARE @intCUR_ATN INTEGER
    DECLARE @intPID INTEGER
    DECLARE @intOutput INTEGER
    DECLARE @strMsg VARCHAR(50)
    DECLARE @intExe INTEGER
    
    -- Is user an admin
    IF (SELECT 1 FROM dbo.vwUsers WHERE USR_ID = @strUSR_ID AND USR_ADMIN = 1) = 1 
        BEGIN
            SET @bitAdmin = 1
        END
    ELSE
        BEGIN
            SET @bitAdmin = 0
        END

    -- What is apps status?
    SET @intSTS = ISNULL((SELECT I.AI_STS 
                          FROM   dbo.vwAppIteration I INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = I.AE_ID 
                          WHERE  E.APP_ID = @strAPP_ID AND E.ENV_ID = @strENV_ID AND I.AI_SSD_DT IS NULL),0)
    
    -- What is Current Action?
    SET @intCUR_ATN = ISNULL((SELECT P.CUR_ATN 
                              FROM   dbo.vwAppPermissions P INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = P.AE_ID 
                              WHERE  E.APP_ID = @strAPP_ID AND E.ENV_ID = @strENV_ID AND P.USR_ID = @strUSR_ID),-1)

    -- Is there a PID
    SET @intPID = ISNULL((SELECT P.PID 
                          FROM   dbo.vwAppPermissions P INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = P.AE_ID 
                          WHERE  E.APP_ID = @strAPP_ID AND E.ENV_ID = @strENV_ID AND P.USR_ID = @strUSR_ID),0)
    
    -- Is there an executeable available?
    SET @intExe = ISNULL((SELECT 1 FROM dbo.vwAppExecutables E WHERE E.APP_ID = @strAPP_ID AND E.ENV_ID = @strENV_ID),0)
    
    -- Now we have all the variables, output results
    SET @intOutput = (CASE 
                        WHEN @intExe = 0 THEN 7 -- No Executeable
                        WHEN @intCUR_ATN < 0 THEN -1 -- User could not be found for app/env
                        WHEN @intCUR_ATN = 0 AND (@bitAdmin = 1 OR @intSTS = 1) THEN 1 -- Passed
                        WHEN @intCUR_ATN < 3 AND (@bitAdmin = 1 OR @intSTS = 1) THEN 2 -- Inform that an error may have occurred previosuly
                        WHEN @intCUR_ATN = 3 AND (@bitAdmin = 1 OR @intSTS = 1) THEN 3 -- Confirm
                        WHEN @intCUR_ATN > 3 THEN 4 -- Application may be open, need to check if PID still exists
                        WHEN @intSTS = 2 AND @bitAdmin = 0 THEN 5 -- Maintenance
                        WHEN @intSTS = 0 AND @bitAdmin = 0 THEN 6 -- Offline
                        ELSE 0 -- Unknown
                      END)
                      
    SELECT @intOutput [Result], @intPID [PID]
GO
GRANT EXECUTE ON [dbo].uspReturnCanUserOpenApp TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.19. Add new uspReturnAppPromotionDetails to get promotion details ready
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnAppPromotionDetails]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnAppPromotionDetails
--
GO
--
CREATE PROCEDURE dbo.uspReturnAppPromotionDetails
    @strAPP_ID  VARCHAR(6)
   ,@strPRM_ENV_ID  VARCHAR(5)
AS
    SET NOCOUNT ON
    
    -- Get latest dev version
    SELECT A.APP_ID, A.APP_NME, I.*
    INTO   #tmpDev
    FROM   dbo.vwAppIteration I
    INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = I.AE_ID
    INNER JOIN dbo.vwApplications A ON A.APP_ID = E.APP_ID
    WHERE  E.APP_ID = @strAPP_ID
      AND  E.ENV_ID = 'ENV03'
      AND  I.AI_SSD_DT IS NULL
      
    SELECT I.*
    INTO   #tmpProm
    FROM   dbo.vwAppIteration I
    INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = I.AE_ID
    WHERE  E.APP_ID = @strAPP_ID
      AND  E.ENV_ID = @strPRM_ENV_ID
      AND  I.AI_VER_MAJ + '.' + I.AI_VER_MIN + '.' + I.AI_VER_REV = (SELECT t.AI_VER_MAJ + '.' + t.AI_VER_MIN + '.' + t.AI_VER_REV FROM #tmpDev t)
      
    -- Output
    SELECT D.APP_ID
          ,D.APP_NME
          ,D.AI_ID [DEV_API_ID]
          ,D.AI_VER_MAJ + '.' + D.AI_VER_MIN + '.' + D.AI_VER_REV [Version]
          ,T.AI_ID [PRM_API_ID]
    FROM   #tmpDev D
    LEFT JOIN #tmpProm T ON D.AI_VER_MAJ + '.' + D.AI_VER_MIN + '.' + D.AI_VER_REV = T.AI_VER_MAJ + '.' + T.AI_VER_MIN + '.' + T.AI_VER_REV
    
    -- Clear
    DROP TABLE #tmpDev
    DROP TABLE #tmpProm 
GO
GRANT EXECUTE ON [dbo].uspReturnAppPromotionDetails TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.20. Send Email
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspGTYSendEmail]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspGTYSendEmail
--
GO
--
CREATE PROCEDURE dbo.uspGTYSendEmail
    @strRecipientList VARCHAR(512) = NULL
   ,@strCCList VARCHAR(512) = NULL
   ,@strSubject VARCHAR(255)
   ,@strBody VARCHAR(2000)
   ,@strApplicationName VARCHAR(128) 
AS
    SET NOCOUNT ON
    
    EXEC IFSLA_SYS.dbo.uspSYSQueueEmail @strRecipientList, @strCCList, @strSubject, @strBody, @strApplicationName
GO
GRANT EXECUTE ON [dbo].uspGTYSendEmail TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.21. Add new uspPromoteApplicationAPISetup
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspPromoteApplicationAPISetup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspPromoteApplicationAPISetup
GO
CREATE PROCEDURE dbo.uspPromoteApplicationAPISetup
    @strAPP_ID CHAR(6)
   ,@strPRM_ENV_ID CHAR(5)
AS
    SET NOCOUNT ON
    DECLARE @strAI_ID VARCHAR(8)
    DECLARE @strAE_ID CHAR(8)
    DECLARE @strAI_VER_MAJ CHAR(2)
    DECLARE @strAI_VER_MIN CHAR(2)
    DECLARE @strAI_VER_REV CHAR(2)
    DECLARE @strAI_VER_CMT VARCHAR(255)
    DECLARE @strCUR_AI_ID CHAR(8)
    
    BEGIN TRY
        BEGIN TRANSACTION
        -- Create AI_ID (API_ID, Iteration ID) if needed for new environment
        ----------------------------------------
        -- Get Current AI_ID (if there is one) for environment
        SELECT @strCUR_AI_ID = I.AI_ID
        FROM   dbo.vwAppIteration I
        INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = I.AE_ID
        INNER JOIN dbo.vwApplications A ON A.APP_ID = E.APP_ID
        WHERE  E.APP_ID = @strAPP_ID
          AND  E.ENV_ID = @strPRM_ENV_ID
          AND  I.AI_SSD_DT IS NULL
                  
        -- Get latest dev version
        SELECT A.APP_ID, A.APP_NME, I.*
        INTO   #tmpDev
        FROM   dbo.vwAppIteration I
        INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = I.AE_ID
        INNER JOIN dbo.vwApplications A ON A.APP_ID = E.APP_ID
        WHERE  E.APP_ID = @strAPP_ID
          AND  E.ENV_ID = 'ENV03'
          AND  I.AI_SSD_DT IS NULL
        
        -- Get verison variables
        SELECT @strAI_VER_MAJ = D.AI_VER_MAJ
              ,@strAI_VER_MIN = D.AI_VER_MIN
              ,@strAI_VER_REV = D.AI_VER_REV
              ,@strAI_VER_CMT = D.AI_VER_CMT
        FROM   #tmpDev D
        
        -- Find if version already exists for Prmoted Environment  
        SELECT I.*
        INTO   #tmpProm
        FROM   dbo.vwAppIteration I
        INNER JOIN dbo.vwAppEnvironments E ON E.AE_ID = I.AE_ID
        WHERE  E.APP_ID = @strAPP_ID
          AND  E.ENV_ID = @strPRM_ENV_ID
          AND  I.AI_VER_MAJ + '.' + I.AI_VER_MIN + '.' + I.AI_VER_REV = (@strAI_VER_MAJ + '.' + @strAI_VER_MIN + '.' + @strAI_VER_REV)
        
        -- If AI exists for new environment then skip, otherwise create it
        SET @strAE_ID = (SELECT AE_ID FROM dbo.vwAppEnvironments AE WHERE AE.APP_ID = @strAPP_ID AND AE.ENV_ID = @strPRM_ENV_ID)
        SET @strAI_ID = (SELECT AI_ID FROM #tmpProm)
        IF @strAI_ID IS NULL
            BEGIN
                EXEC dbo.uspAddAppIteration @strAE_ID, @strAI_VER_MAJ, @strAI_VER_MIN, @strAI_VER_REV, @strAI_VER_CMT, @strAI_ID OUTPUT
            END
        ----------------------------------------
        
        -- Set CURRENT AI_ID to Maintenance while setup runs
        ----------------------------------------
        IF @strCUR_AI_ID IS NOT NULL
            BEGIN
                EXEC dbo.uspEditIteration '', @strAPIid = @strCUR_AI_ID, @intStatusID = 2
            END
        ----------------------------------------
        
        -- Output AI_ID
        ----------------------------------------
        SELECT @strAI_ID AI_ID
        ----------------------------------------
        
        COMMIT TRANSACTION
    END TRY
    
    BEGIN CATCH
            --/ Capture the error                
        DECLARE @ERR_Severity INTEGER
        DECLARE @ERR_State INTEGER
        DECLARE @ERR_Number INTEGER
        DECLARE @ERR_Line INTEGER
        DECLARE @ERR_Message VARCHAR(255)
            
        SET @ERR_Severity = ERROR_SEVERITY()
        SET @ERR_State = ERROR_STATE()
	    SET @ERR_Number = ERROR_NUMBER()
	    SET @ERR_Line = ERROR_LINE()
	    SET @ERR_Message = ERROR_MESSAGE()
        
        PRINT '-- ERROR: ' + @ERR_Message
        ROLLBACK TRANSACTION
        RAISERROR ('Msg %d, Line %d: %s',@ERR_Severity,@ERR_State,@ERR_Number,@ERR_Line,@ERR_Message)
    END CATCH
GO
GRANT EXECUTE ON [dbo].uspPromoteApplicationAPISetup TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.21. Add new uspPromoteApplicationFileSetup
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspPromoteApplicationFileSetup]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspPromoteApplicationFileSetup
GO
CREATE PROCEDURE dbo.uspPromoteApplicationFileSetup
    @strAPP_ID CHAR(6)
   ,@strPRM_ENV_ID CHAR(5)
   ,@strEXE_STR_FLE_ID CHAR(8)
AS
    SET NOCOUNT ON
    DECLARE @strAE_ID CHAR(8)
    DECLARE @intAPP_FLE_ID INTEGER
    DECLARE @intRowCount INTEGER
    DECLARE @strEXE_FLE_PTH VARCHAR(255)
    DECLARE @strEXE_FLE_NME VARCHAR(255)
    DECLARE @strAEF_ID VARCHAR(10)

    BEGIN TRY
        BEGIN TRANSACTION
                
        -- Apply files from dev to new environment (override/delete old and excluding GW Icon and Executeable)
        ----------------------------------------
        SET @strAE_ID = (SELECT AE_ID FROM dbo.vwAppEnvironments AE WHERE AE.APP_ID = @strAPP_ID AND AE.ENV_ID = @strPRM_ENV_ID)
        
        -- Get list of files
        SELECT FL.*
        INTO   #tmpFileList
        FROM   dbo.vwAppFileList FL
        INNER JOIN dbo.vwAppEnvironments AE ON AE.AE_ID = FL.AE_ID
        WHERE  AE.APP_ID = @strAPP_ID 
          AND  AE.ENV_ID = 'ENV03'
          AND  FL.FLE_GRP_ID NOT IN ('FGP00','FGP01','FGP04')
          
        -- Get dev copy details
        SELECT @strEXE_FLE_PTH = FL.FLE_PTH
              ,@strEXE_FLE_NME = LEFT(FL.FLE_NME, CHARINDEX('.',FL.FLE_NME,1)) + 'accde'
        FROM   dbo.vwAppFileList FL
        INNER JOIN dbo.vwAppEnvironments AE ON AE.AE_ID = FL.AE_ID
        WHERE  AE.APP_ID = @strAPP_ID 
          AND  AE.ENV_ID = 'ENV03'
          AND  FL.FLE_GRP_ID  = 'FGP01'
           
        -- Update files
        UPDATE dbo.tblGTY090
        SET    STR_FLE_ID = FL.STR_FLE_ID
              ,FLE_GRP_ID = FL.FLE_GRP_ID
              ,PRG_ID = FL.PRG_ID
              ,FLE_DESC = FL.FLE_DESC
        FROM   dbo.tblGTY090 G90
        INNER JOIN #tmpFileList FL ON G90.FLE_NME = FL.FLE_NME
                                  AND G90.FLE_PTH = FL.FLE_PTH
        
        -- Delete missing files
        DELETE G90 
        FROM   dbo.tblGTY090 G90
        WHERE  AE_ID = @strAE_ID
          AND  G90.FLE_GRP_ID NOT IN ('FGP00','FGP01','FGP04')
          AND NOT EXISTS (SELECT 1 FROM #tmpFileList FL WHERE FL.FLE_NME = G90.FLE_NME AND FL.FLE_PTH = G90.FLE_PTH)
          
        -- Add new files
        SET @intAPP_FLE_ID = (SELECT KEY_SEQ_NBR FROM dbo.tblSYSKey K WHERE K.TBL_KEY_ID = 'AEF')
        INSERT INTO dbo.tblGTY090
        (
               APP_FLE_ID
              ,AE_ID
              ,FLE_PTH
              ,FLE_NME
              ,FLE_DESC
              ,FLE_GRP_ID
              ,PRG_ID
              ,STR_FLE_ID
        )
        SELECT 'AEF' + RIGHT('00000' + CONVERT(VARCHAR(50), @intAPP_FLE_ID + ROW_NUMBER() OVER(ORDER BY FL.AE_ID)),5) APP_FLE_ID
              ,@strAE_ID
              ,FL.FLE_PTH
              ,FL.FLE_NME
              ,FL.FLE_DESC
              ,FL.FLE_GRP_ID
              ,FL.PRG_ID
              ,FL.STR_FLE_ID
        FROM   #tmpFileList FL
        WHERE  NOT EXISTS (SELECT 1 FROM dbo.tblGTY090 G90 WHERE AE_ID = @strAE_ID AND G90.FLE_NME = FL.FLE_NME AND G90.FLE_PTH = FL.FLE_PTH)
        
        -- Update Key table
        SET @intRowCount = @@ROWCOUNT
        
        UPDATE dbo.tblSYSKey
        SET    KEY_SEQ_NBR = @intAPP_FLE_ID + @intRowCount + 1
        WHERE  TBL_KEY_ID = 'AEF'
        ----------------------------------------
        
        -- Apply exe file and cleanup stored files
        ----------------------------------------  
        IF (SELECT 1 FROM dbo.tblGTY090 G90 WHERE G90.AE_ID = @strAE_ID AND g90.FLE_GRP_ID = 'FGP00') = 1
            BEGIN -- Update
                UPDATE dbo.tblGTY090
                SET    STR_FLE_ID = @strEXE_STR_FLE_ID
                      ,FLE_PTH = @strEXE_FLE_PTH
                      ,FLE_NME = @strEXE_FLE_NME
                WHERE  AE_ID = @strAE_ID
                  AND  FLE_GRP_ID = 'FGP00'
            END 
        ELSE
            BEGIN -- Add New
                EXEC dbo.uspAddAppEnvFile @strAE_ID, @strEXE_FLE_PTH, @strEXE_FLE_NME,'Release EXE','PRG01','FGP00','',@strEXE_STR_FLE_ID
            END 
        
        -- Clean up 
        EXEC dbo.uspCleanUpFiles 
        ----------------------------------------
        
        SELECT 'SUCCESS' AS [Result]
        COMMIT TRANSACTION
    END TRY
    
    BEGIN CATCH
            --/ Capture the error                
        DECLARE @ERR_Severity INTEGER
        DECLARE @ERR_State INTEGER
        DECLARE @ERR_Number INTEGER
        DECLARE @ERR_Line INTEGER
        DECLARE @ERR_Message VARCHAR(255)
            
        SET @ERR_Severity = ERROR_SEVERITY()
        SET @ERR_State = ERROR_STATE()
	    SET @ERR_Number = ERROR_NUMBER()
	    SET @ERR_Line = ERROR_LINE()
	    SET @ERR_Message = ERROR_MESSAGE()
        
        PRINT '-- ERROR: ' + @ERR_Message
        ROLLBACK TRANSACTION
        RAISERROR ('Msg %d, Line %d: %s',@ERR_Severity,@ERR_State,@ERR_Number,@ERR_Line,@ERR_Message)
    END CATCH
GO
GRANT EXECUTE ON [dbo].uspPromoteApplicationFileSetup TO [sp_Exec]
GO
-----------------------------------------------------

-- 3.22. Alter procedure [uspGatewayLogInOut] to cover for length of machine ID changes
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspGatewayLogInOut] 
    @strAppID CHAR(8)
   ,@strEnvID CHAR(5)
   ,@strApiID CHAR(8)
   ,@strUsrID VARCHAR(20)
   ,@intPID INTEGER
   ,@strMachineID VARCHAR(100)
   ,@bitLogIn BIT
AS
   
    SET NOCOUNT ON
    DECLARE @strApeID CHAR(8)
    DECLARE @strAAID CHAR(11)
    
--- Get IDs needed for following process
	SET @strApeID = (SELECT PER_ID
				     FROM dbo.tblGTY050 APE INNER JOIN dbo.tblGTY030 AEV ON APE.AE_ID = AEV.AE_ID 
				     WHERE AEV.APP_ID = @strAppID
				       AND AEV.ENV_ID= @strEnvID
				       AND APE.USR_ID= @strUsrID)

    IF @strApeID IS NOT NULL
		BEGIN
			IF @bitLogIn = 1
				BEGIN
					-- Update Permission table with details
					UPDATE dbo.tblGTY050
					SET	   CUR_ATN = 3
						  ,PID = @intPID
						  ,LST_LOG_IN = GETDATE()		
					WHERE  PER_ID = @strApeID
					
					-- Get new AA key
					EXEC dbo.uspSYSKeySequence 'AAL', @strAAID OUTPUT
					
					-- Update any entries that do not have a log out method
					UPDATE tblGTY900
					SET    LOG_OUT = GETDATE()
						  ,LOG_OUT_MTH = 'UNKNOWN'
					WHERE  AI_ID = @strApiID
					  AND  USR_ID = @strUsrID
					  AND  LOG_OUT IS NULL
					  
					-- Now insert the new log in details
					INSERT INTO tblGTY900
						 ( AA_ID
						  ,AI_ID
						  ,USR_ID
						  ,LOG_IN
						  ,MCE_ID )
					SELECT @strAAID
						  ,@strApiID
						  ,UPPER(@strUsrID)
						  ,GETDATE()
					      ,@strMachineID
					      
					-- Log In Finished
				END 
			ELSE
				BEGIN
					-- Update Permission table with details
					UPDATE dbo.tblGTY050
					SET	   CUR_ATN = 0
						  ,PID = @intPID
						  ,LST_LOG_OUT = GETDATE()		
					WHERE  PER_ID = @strApeID
					
					-- Get existing AA ID
					SET @strAAID = (SELECT AA_ID FROM dbo.tblGTY900 WHERE AI_ID = @strApiID AND USR_ID = @strUsrID AND LOG_OUT IS NULL)
					
					-- Update the existing Log
					IF @strAAID IS NOT NULL
						BEGIN	
							UPDATE tblGTY900
							SET    LOG_OUT = GETDATE()
								  ,LOG_OUT_MTH = 'APP_EXIT'
							WHERE  AA_ID = @strAAID
						END
						
					-- Log Out Finished
				END 
		END
--		
GO
-----------------------------------------------------

-- 3.23. Add new uspReturnUserListForApp 
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspReturnUserListForApp]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspReturnUserListForApp
--
GO
--
CREATE PROCEDURE dbo.uspReturnUserListForApp
    @strAPP_ID  VARCHAR(6)
AS
    SET NOCOUNT ON
    
	SELECT USR.USR_ID [User ID]
		  ,USR.USR_FNME	+ ' ' + USR.USR_SNME [User Name]
		  ,USR.USR_EMAIL [User EMail]
		  ,APP.ACD_GRP_NME [Active Directory Group]
	FROM   dbo.vwApplications APP
	INNER JOIN dbo.vwAppEnvironments ENV ON ENV.APP_ID = APP.APP_ID
	INNER JOIN dbo.vwAppPermissions PER ON PER.AE_ID = ENV.AE_ID
	INNER JOIN dbo.vwUsers USR ON USR.USR_ID = PER.USR_ID
	WHERE  ENV.ENV_ID = 'ENV01'
	  AND  APP.APP_ID = @strAPP_ID
	  AND  PER.AE_USR_ACT = 1
	  AND  USR.USR_ACT = 1
	ORDER BY [User Name]
GO
GRANT EXECUTE ON [dbo].uspReturnUserListForApp TO [sp_Exec]
GO
-----------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------

