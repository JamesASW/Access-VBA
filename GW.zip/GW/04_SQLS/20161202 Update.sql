/*
Title: OA Update for Gateway
Dev(s): James Williams (JW)
Update Date: 2016-12-02 09:15



Index:
1. Stored Procedures
    1.1. Add uspADMUsersList
	1.2. Update [uspGetUserPermissionsFromAD]
*/


-- Set DB
USE [IFSLA_Gateway]
GO

-- 1. Stored Procedures
-------------------------------------------------------------------------------------------------------------------------

-- 1.1. Add new uspADMUsersList
-----------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspADMUsersList]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [dbo].uspADMUsersList
--
GO
--
CREATE PROCEDURE dbo.uspADMUsersList
    @strGRP_CD VARCHAR(6)
   ,@strAPP_ID VARCHAR(6) = NULL
AS
    SET NOCOUNT ON
	DECLARE @intGRP_SID INTEGER

	-- Strip out group SID from Code
	SET @intGRP_SID = CAST(RIGHT(@strGRP_CD,3) AS INTEGER)

	-- Depending on if @strAPP_ID is supplied, return a recordset
	IF @strAPP_ID IS NULL
		BEGIN
			SELECT CASE WHEN GWU.USR_ADMIN = 1 THEN 'UserDevs16x16' ELSE 'User16x16' END AS [IconID]
				  ,U.USR_ID		AS [User ID]
				  ,U.USR_FNME	AS [First Name]
				  ,U.USR_LNME	AS [Surname]
				  ,U.USR_TTL	AS [Title]
				  ,U.USR_DEPT	AS [Department]
				  ,U.USR_EMAIL	AS [Email]
				  ,U.USR_TEL_NO AS [Tel No.]
				  ,CASE WHEN GWU.USR_ADMIN = 1 THEN 'Yes' ELSE 'No' END AS [Is Dev]
				  ,U.INS_DT		AS [Date User Added]
				  ,U.DEL_DT		AS [Date User Deleted]
			FROM   IFSLA_CENTRAL.adr.tblUSR0010 U
			INNER JOIN IFSLA_CENTRAL.adr.tblUGX0010 G ON G.USR_SID = U.USR_SID
			LEFT JOIN dbo.tblGTY060 GWU ON GWU.USR_ID = U.USR_ID
			WHERE  G.GRP_SID = @intGRP_SID
			ORDER BY U.USR_ID
		END
	ELSE
		BEGIN 
			SELECT CASE 
					WHEN GWU.USR_ADMIN = 1 THEN 'UserDevs16x16' 
					WHEN P.AE_USR_ACT = 1 THEN 'User16x16'
					ELSE 'UserNo16x16' END AS [IconID]
			      ,U.USR_ID		AS [User ID]
				  ,U.USR_FNME	AS [First Name]
				  ,U.USR_LNME	AS [Surname]
				  ,U.USR_TTL	AS [Title]
				  ,U.USR_DEPT	AS [Department]
				  ,U.USR_EMAIL	AS [Email]
				  ,U.USR_TEL_NO AS [Tel No.]
				  ,CASE WHEN GWU.USR_ADMIN = 1 THEN 'Yes' ELSE 'No' END AS [Is Dev]
				  ,CASE WHEN P.AE_USR_ACT = 1 THEN 'Yes' ELSE 'No' END AS [App Access]
				  ,U.INS_DT		AS [Date User Added]
				  ,U.DEL_DT		AS [Date User Deleted]
			FROM   IFSLA_CENTRAL.adr.tblUSR0010 U
			INNER JOIN IFSLA_CENTRAL.adr.tblUGX0010 G ON G.USR_SID = U.USR_SID
			INNER JOIN IFSLA_CENTRAL.adr.tblREF0010 R ON R.GRP_SID = G.GRP_SID
			LEFT JOIN  dbo.tblGTY020 A ON A.ACD_GRP_NME = R.GRP_NME
									  AND A.APP_ID = @strAPP_ID
			LEFT JOIN  dbo.tblGTY030 AE ON AE.APP_ID = A.APP_ID
									   AND AE.ENV_ID = 'ENV01'
			LEFT JOIN  dbo.tblGTY050 P ON P.AE_ID = AE.AE_ID
									  AND P.USR_ID = U.USR_ID
			LEFT JOIN dbo.tblGTY060 GWU ON GWU.USR_ID = P.USR_ID
			WHERE  G.GRP_SID = @intGRP_SID
			ORDER BY U.USR_ID
		END
--
GO
--
GRANT EXECUTE ON [dbo].uspADMUsersList TO [sp_Exec]
--
GO

-- 1.2. Update [uspGetUserPermissionsFromAD]
-----------------------------------------------------
ALTER PROCEDURE [dbo].[uspGetUserPermissionsFromAD]
AS
    SET NOCOUNT ON
    DECLARE @intPER_ID INTEGER
    DECLARE @strMsg VARCHAR(255)
    DECLARE @intRowCount INTEGER
    SET @strMsg = ''
    
    BEGIN TRY
        BEGIN TRANSACTION
        -- Add and remove users based upon latest Active Directory in CENTRAL
        ---------------------------------     
			-- Add New user Groups
			MERGE INTO dbo.tblGTY150 as T
				  USING IFSLA_CENTRAL.adr.tblREF0010 S
				  ON T.GRP_SID = S.GRP_SID
			WHEN MATCHED THEN
				UPDATE SET GRP_NME = S.GRP_NME
							  ,CRT_DT = S.CRT_DT
						      ,DEL_DT = S.DEL_DT
			WHEN NOT MATCHED THEN
				INSERT (
						GRP_SID
					   ,GRP_NME
					   ,CRT_DT
					   ,DEL_DT
					   )
				VALUES (
						S.GRP_SID
					   ,S.GRP_NME
					   ,S.CRT_DT
					   ,S.DEL_DT
					   )
			;
			          
            -- Add new users into tblGTY060
            INSERT INTO dbo.tblGTY060
            (
                   USR_ID
                  ,USR_FNME
                  ,USR_SNME
                  ,USR_ACT
                  ,USR_ADMIN
                  ,USR_EMAIL
                  ,USR_INACT_DT
            )
            SELECT U.USR_ID
                  ,ISNULL(U.USR_FNME,'')
                  ,ISNULL(U.USR_LNME,'')
                  ,1
                  ,0
                  ,ISNULL(U.USR_EMAIL,'')
                  ,NULL
            FROM IFSLA_CENTRAL.adr.vwUserGroups G
            INNER JOIN IFSLA_CENTRAL.adr.vwUser U ON U.USR_ID = G.USR_ID
            WHERE NOT EXISTS (SELECT 1 FROM dbo.tblGTY060 t WHERE U.USR_ID = t.USR_ID)
              AND G.GRP_SID = 1
            
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0 
            BEGIN
                SET @strMsg = @strMsg + 'Number of Users Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Update Users
            UPDATE dbo.tblGTY060
            SET    USR_FNME = ISNULL(U.USR_FNME,'')
                  ,USR_SNME = ISNULL(U.USR_LNME,'')
                  ,USR_ACT = 1
                  ,USR_EMAIL = ISNULL(U.USR_EMAIL,'')
                  ,USR_INACT_DT = NULL
            FROM   dbo.tblGTY060 G60
            INNER JOIN IFSLA_CENTRAL.adr.vwUserGroups G ON G.USR_ID = G60.USR_ID
            INNER JOIN IFSLA_CENTRAL.adr.vwUser U ON U.USR_ID = G.USR_ID
              AND G.GRP_SID = 1
              AND (
                   G60.USR_FNME <> U.USR_FNME
                   OR G60.USR_SNME <> U.USR_LNME
                   OR G60.USR_ACT <> 1
                   OR G60.USR_EMAIL <> U.USR_EMAIL
                   OR USR_INACT_DT IS NOT NULL)
                   
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0 
            BEGIN
                SET @strMsg = @strMsg + 'Number of Users Updated: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Mark users hwo have disappeared
            UPDATE dbo.tblGTY060
            SET    USR_ACT = 0
                  ,USR_ADMIN = 0
                  ,USR_INACT_DT = GETDATE()
            FROM   dbo.tblGTY060 G60
            WHERE  USR_ACT = 1
              AND  NOT EXISTS (SELECT 1 
                               FROM   IFSLA_CENTRAL.adr.vwUserGroups G
                               INNER JOIN IFSLA_CENTRAL.adr.vwUser U ON U.USR_ID = G.USR_ID
                               WHERE  G.GRP_SID = 1 
                                 AND  U.USR_ID = G60.USR_ID)
            
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0 
            BEGIN
                SET @strMsg = @strMsg + 'Number of Users Removed: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
        ---------------------------------   
        
        -- For developers
        ---------------------------------   
            -- Get list of devs (Users who have access to IFSLOCALAPPS
            SELECT U.USR_ID
                  ,G.USR_FNME + ' ' + G.USR_SNME [USER]
            INTO   #tmpDevs
            FROM   IFSLA_CENTRAL.adr.vwUserGroups U
            INNER JOIN IFSLA_GATEWAY.dbo.tblGTY060 G ON G.USR_ID = U.USR_ID
            WHERE  U.GRP_SID = 5
            
            -- Remove permissions to all apps for Admin users who aren't in the list (Exception being BU730 and JL790 incase it breaks)
            UPDATE dbo.tblGTY050 
            SET    AE_USR_ACT = 0
            FROM   dbo.tblGTY050 G50
            INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
            WHERE  G60.USR_ADMIN = 1
			--  AND  G60.USR_ID NOT IN('BU730', 'JL790')
              AND  NOT EXISTS (SELECT 1 FROM #tmpDevs D WHERE D.USR_ID = USR_ID)

            -- Remove dev permissions for users not in this list (Exception being BU730 and JL790 incase it breaks)
            UPDATE dbo.tblGTY060
            SET    USR_ADMIN = 0
            FROM   dbo.tblGTY060 G
            WHERE NOT EXISTS (SELECT 1 FROM #tmpDevs D WHERE D.USR_ID = G.USR_ID)
            --  AND  USR_ID NOT IN('BU730', 'JL790')
              AND  USR_ADMIN = 1
            
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Removed: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Add in New Admins
            UPDATE dbo.tblGTY060
            SET    USR_ADMIN = 1
            FROM   dbo.tblGTY060 G
            WHERE  EXISTS (SELECT 1 FROM #tmpDevs D WHERE D.USR_ID = G.USR_ID)
              AND  USR_ADMIN = 0
              
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            -- Generate all data ready
            SELECT G30.AE_ID
                  ,D.USR_ID
            INTO   #tmpDevAssign
            FROM   dbo.tblGTY030 G30 
                  ,#tmpDevs D
                  
            -- Assign full permissions to all apps for admin
            SET @intPER_ID = (SELECT KEY_SEQ_NBR FROM dbo.tblSYSKey WHERE TBL_KEY_ID = 'APE')
            INSERT INTO dbo.tblGTY050
            (
                   PER_ID
                  ,AE_ID
                  ,USR_ID
                  ,AE_USR_ACT
                  ,CUR_ATN
                  ,FAV
            )
            SELECT 'APE' + RIGHT('00000' + CAST(@intPER_ID + ROW_NUMBER() OVER(ORDER BY DA.AE_ID) AS VARCHAR(25)),5)
                  ,DA.AE_ID
                  ,DA.USR_ID
                  ,1
                  ,0
                  ,0
            FROM   #tmpDevAssign DA
            WHERE NOT EXISTS (SELECT 1 FROM dbo.tblGTY050 t WHERE t.AE_ID = DA.AE_ID AND t.USR_ID = DA.USR_ID)
            
            -- Update Key table
            SET @intRowCount = @@ROWCOUNT
                
            UPDATE dbo.tblSYSKey
            SET    KEY_SEQ_NBR = @intPER_ID + @intRowCount + 1
            WHERE  TBL_KEY_ID = 'APE'
            
			-- Log
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Permissions Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END

			-- Update Permissions
			UPDATE dbo.tblGTY050
			SET    AE_USR_ACT = 1
			FROM   dbo.tblGTY050 G50
			INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
			WHERE  AE_USR_ACT = 0
			  AND  G60.USR_ACT = 1
			  AND  EXISTS (SELECT 1 FROM #tmpDevAssign DA WHERE DA.AE_ID = G50.AE_ID AND DA.USR_ID = G50.USR_ID)

			-- Log
			SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of Admins Permissions Updated: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END

            -- Clear Memory
            DROP TABLE #tmpDevs
            DROP TABLE #tmpDevAssign
        ---------------------------------
        
        -- Apply the rest of the permissions for standard users
        ---------------------------------
            -- Get full permissions based upon current setup
            SELECT AE.AE_ID
                  ,UG.USR_ID
            INTO   #tmpUserPerms
            FROM   dbo.tblGTY020 APP
            INNER JOIN dbo.tblGTY030 AE ON AE.APP_ID = APP.APP_ID
            INNER JOIN IFSLA_CENTRAL.adr.vwUserGroups UG ON UG.GRP_NME = APP.ACD_GRP_NME
            WHERE  AE.ENV_ID IN ('ENV01','ENV02')
			  AND  UG.GRP_SID <> 5

           -- full permissions to all apps/user combos that don't exist
            SET @intPER_ID = (SELECT KEY_SEQ_NBR FROM dbo.tblSYSKey WHERE TBL_KEY_ID = 'APE')
            INSERT INTO dbo.tblGTY050
            (
                   PER_ID
                  ,AE_ID
                  ,USR_ID
                  ,AE_USR_ACT
                  ,CUR_ATN
                  ,FAV
            )
            SELECT 'APE' + RIGHT('00000' + CAST(@intPER_ID + ROW_NUMBER() OVER(ORDER BY UP.AE_ID) AS VARCHAR(25)),5)
                  ,UP.AE_ID
                  ,UP.USR_ID
                  ,1
                  ,0
                  ,0
            FROM   #tmpUserPerms UP
            WHERE NOT EXISTS (SELECT 1 FROM dbo.tblGTY050 t WHERE t.AE_ID = UP.AE_ID AND t.USR_ID = UP.USR_ID)

            -- Update Key table
            SET @intRowCount = @@ROWCOUNT
                
            UPDATE dbo.tblSYSKey
            SET    KEY_SEQ_NBR = @intPER_ID + @intRowCount + 1
            WHERE  TBL_KEY_ID = 'APE'

            -- Log
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of User Permissions Added: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            
            --  Update permissions
            UPDATE dbo.tblGTY050 
            SET    AE_USR_ACT = 1
            FROM   dbo.tblGTY050 G50
            INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
            WHERE  G60.USR_ADMIN = 0
              AND  EXISTS (SELECT 1 FROM #tmpUserPerms UP WHERE UP.USR_ID = G50.USR_ID AND UP.AE_ID = G50.AE_ID)
			  AND  G50.AE_USR_ACT = 0
              
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of User Permissions Updated: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END

            -- Remove permissions to all apps for users who aren't in the list (except admins)
            UPDATE dbo.tblGTY050 
            SET    AE_USR_ACT = 0
            FROM   dbo.tblGTY050 G50
            INNER JOIN dbo.tblGTY060 G60 ON G60.USR_ID = G50.USR_ID
            WHERE  G60.USR_ADMIN = 0
              AND  G50.AE_USR_ACT = 1
			  AND  NOT EXISTS (SELECT 1 FROM #tmpUserPerms UP WHERE UP.USR_ID = G50.USR_ID AND UP.AE_ID = G50.AE_ID)
			  AND  G60.USR_ACT	= 1
              
            -- Log
            SET @intRowCount = @@ROWCOUNT
            IF @intRowCount > 0
            BEGIN
                SET @strMsg = @strMsg + 'Number of User Permissions Deleted: ' + CAST(@intRowCount AS VARCHAR(5)) + CHAR(13) + CHAR(10)
            END
            PRINT @strMsg
            
            -- Clear Memory
            DROP TABLE #tmpUserPerms

			-- Update Global variable with latest refresh date
			IF (SELECT 1 FROM dbo.tblSYSVarGlobal G WHERE G.VAR_NME = 'APP_ADLatestRefresh') = 1
				BEGIN
					UPDATE dbo.tblSYSVarGlobal SET VAR_DTE = GETDATE() WHERE VAR_NME = 'APP_ADLatestRefresh'
				END
			ELSE
				BEGIN
					INSERT INTO dbo.tblSYSVarGlobal (VAR_NME, VAR_TYP, VAR_DTE) SELECT 'APP_ADLatestRefresh','DTE',GETDATE()
				END
			PRINT 'SUCCESS'
        COMMIT TRANSACTION
    END TRY
    
    BEGIN CATCH
            --/ Capture the error                
        DECLARE @ERR_Severity INTEGER
        DECLARE @ERR_State INTEGER
        DECLARE @ERR_Number INTEGER
        DECLARE @ERR_Line INTEGER
        DECLARE @ERR_Message VARCHAR(255)
            
        SET @ERR_Severity = ERROR_SEVERITY()
        SET @ERR_State = ERROR_STATE()
	    SET @ERR_Number = ERROR_NUMBER()
	    SET @ERR_Line = ERROR_LINE()
	    SET @ERR_Message = ERROR_MESSAGE()
        
        -- LOG ERROR HERE
        PRINT '-- Current log'
        PRINT @strMsg
        
        PRINT '-- ERROR: ' + @ERR_Message
        ROLLBACK TRANSACTION
        RAISERROR ('Msg %d, Line %d: %s',@ERR_Severity,@ERR_State,@ERR_Number,@ERR_Line,@ERR_Message)
    END CATCH
    ---------------------------------    


GO